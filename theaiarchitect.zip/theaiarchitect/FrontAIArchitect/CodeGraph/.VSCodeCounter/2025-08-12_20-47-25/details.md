# Details

Date : 2025-08-12 20:47:25

Directory e:\\WorkSpace\\Netease\\theaiarchitect\\FrontAIArchitect\\CodeGraph\\micro-index\\tools

Total : 25 files,  1827 codes, 605 comments, 347 blanks, all 2779 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/icons.svg](/micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/icons.svg) | XML | 1 | 0 | 0 | 1 |
| [micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/jsonTree.css](/micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/jsonTree.css) | PostCSS | 90 | 15 | 7 | 112 |
| [micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/jsonTree.js](/micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/jsonTree.js) | JavaScript | 391 | 314 | 107 | 812 |
| [micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/recorder.css](/micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/recorder.css) | PostCSS | 90 | 1 | 22 | 113 |
| [micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/recorder.html](/micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/recorder.html) | HTML | 16 | 3 | 1 | 20 |
| [micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/recorder.js](/micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/recorder.js) | JavaScript | 82 | 6 | 10 | 98 |
| [micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/recorderServer.js](/micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/recorderServer.js) | JavaScript | 19 | 0 | 4 | 23 |
| [micro-index/tools/SubmoduleReferencedStatisticsPlugin/index.js](/micro-index/tools/SubmoduleReferencedStatisticsPlugin/index.js) | JavaScript | 124 | 22 | 17 | 163 |
| [micro-index/tools/analyzeBundle.js](/micro-index/tools/analyzeBundle.js) | JavaScript | 12 | 0 | 6 | 18 |
| [micro-index/tools/assetsTransformer.js](/micro-index/tools/assetsTransformer.js) | JavaScript | 6 | 7 | 2 | 15 |
| [micro-index/tools/build.dll.js](/micro-index/tools/build.dll.js) | JavaScript | 84 | 13 | 16 | 113 |
| [micro-index/tools/build.js](/micro-index/tools/build.js) | JavaScript | 72 | 11 | 14 | 97 |
| [micro-index/tools/chalkConfig.js](/micro-index/tools/chalkConfig.js) | JavaScript | 5 | 1 | 1 | 7 |
| [micro-index/tools/config.d.ts](/micro-index/tools/config.d.ts) | TypeScript | 81 | 91 | 11 | 183 |
| [micro-index/tools/distServer.js](/micro-index/tools/distServer.js) | JavaScript | 50 | 4 | 10 | 64 |
| [micro-index/tools/helps.js](/micro-index/tools/helps.js) | JavaScript | 275 | 56 | 35 | 366 |
| [micro-index/tools/loader/debug-loader.js](/micro-index/tools/loader/debug-loader.js) | JavaScript | 12 | 0 | 5 | 17 |
| [micro-index/tools/loader/freemarker-Readme.md](/micro-index/tools/loader/freemarker-Readme.md) | Markdown | 60 | 0 | 29 | 89 |
| [micro-index/tools/loader/ftl-loader-prod.js](/micro-index/tools/loader/ftl-loader-prod.js) | JavaScript | 8 | 0 | 3 | 11 |
| [micro-index/tools/loader/ftl-loader.js](/micro-index/tools/loader/ftl-loader.js) | JavaScript | 51 | 3 | 10 | 64 |
| [micro-index/tools/mock.js](/micro-index/tools/mock.js) | JavaScript | 38 | 5 | 5 | 48 |
| [micro-index/tools/neiPatch.js](/micro-index/tools/neiPatch.js) | JavaScript | 59 | 4 | 4 | 67 |
| [micro-index/tools/srcServer.js](/micro-index/tools/srcServer.js) | JavaScript | 187 | 47 | 21 | 255 |
| [micro-index/tools/startMessage.js](/micro-index/tools/startMessage.js) | JavaScript | 2 | 1 | 3 | 6 |
| [micro-index/tools/testCi.js](/micro-index/tools/testCi.js) | JavaScript | 12 | 1 | 4 | 17 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)