# Diff Details

Date : 2025-08-12 20:47:25

Directory e:\\WorkSpace\\Netease\\theaiarchitect\\FrontAIArchitect\\CodeGraph\\micro-index\\tools

Total : 135 files,  -4782 codes, 187 comments, -304 blanks, all -4899 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [micro-index/source/\_\_mock\_\_/localStorage.js](/micro-index/source/__mock__/localStorage.js) | JavaScript | -20 | 0 | -2 | -22 |
| [micro-index/source/\_\_mock\_\_/rAF.js](/micro-index/source/__mock__/rAF.js) | JavaScript | -14 | -5 | -7 | -26 |
| [micro-index/source/actions/actionTypes.js](/micro-index/source/actions/actionTypes.js) | JavaScript | -1 | 0 | -1 | -2 |
| [micro-index/source/actions/actions.js](/micro-index/source/actions/actions.js) | JavaScript | -7 | -2 | -2 | -11 |
| [micro-index/source/app.js](/micro-index/source/app.js) | JavaScript | -22 | -2 | -4 | -28 |
| [micro-index/source/appRoutes.js](/micro-index/source/appRoutes.js) | JavaScript | -5 | -24 | -3 | -32 |
| [micro-index/source/assets/css/common/color.less](/micro-index/source/assets/css/common/color.less) | Less | -15 | 0 | -6 | -21 |
| [micro-index/source/assets/css/common/index.less](/micro-index/source/assets/css/common/index.less) | Less | -4 | -1 | -1 | -6 |
| [micro-index/source/assets/css/common/main.less](/micro-index/source/assets/css/common/main.less) | Less | -44 | -4 | -11 | -59 |
| [micro-index/source/assets/css/common/mixin.less](/micro-index/source/assets/css/common/mixin.less) | Less | -107 | -17 | -24 | -148 |
| [micro-index/source/assets/css/common/reset.less](/micro-index/source/assets/css/common/reset.less) | Less | -313 | -8 | -4 | -325 |
| [micro-index/source/assets/css/lib/ppfish-theme-vars.less](/micro-index/source/assets/css/lib/ppfish-theme-vars.less) | Less | 0 | -1 | -1 | -2 |
| [micro-index/source/config/constants.js](/micro-index/source/config/constants.js) | JavaScript | -13 | -28 | -6 | -47 |
| [micro-index/source/config/dev.js](/micro-index/source/config/dev.js) | JavaScript | -9 | -4 | -1 | -14 |
| [micro-index/source/config/envConfig.js](/micro-index/source/config/envConfig.js) | JavaScript | -133 | -1 | -2 | -136 |
| [micro-index/source/config/index.js](/micro-index/source/config/index.js) | JavaScript | -39 | -3 | -3 | -45 |
| [micro-index/source/config/prod.js](/micro-index/source/config/prod.js) | JavaScript | -8 | -3 | -1 | -12 |
| [micro-index/source/constants/default.js](/micro-index/source/constants/default.js) | JavaScript | 0 | 0 | -1 | -1 |
| [micro-index/source/constants/index.js](/micro-index/source/constants/index.js) | JavaScript | -2 | -5 | -1 | -8 |
| [micro-index/source/constants/limit.js](/micro-index/source/constants/limit.js) | JavaScript | -28 | -3 | -1 | -32 |
| [micro-index/source/constants/map.js](/micro-index/source/constants/map.js) | JavaScript | -5 | -4 | -2 | -11 |
| [micro-index/source/middleware/promise.js](/micro-index/source/middleware/promise.js) | JavaScript | -69 | -8 | -18 | -95 |
| [micro-index/source/pages/Root.dev.js](/micro-index/source/pages/Root.dev.js) | JavaScript | -26 | 0 | -4 | -30 |
| [micro-index/source/pages/Root.js](/micro-index/source/pages/Root.js) | JavaScript | -5 | 0 | -1 | -6 |
| [micro-index/source/pages/Root.prod.js](/micro-index/source/pages/Root.prod.js) | JavaScript | -22 | 0 | -3 | -25 |
| [micro-index/source/pages/index/App.js](/micro-index/source/pages/index/App.js) | JavaScript | -17 | 0 | -6 | -23 |
| [micro-index/source/pages/index/App.less](/micro-index/source/pages/index/App.less) | Less | -14 | 0 | -2 | -16 |
| [micro-index/source/pages/index/actions/actionTypes.js](/micro-index/source/pages/index/actions/actionTypes.js) | JavaScript | -7 | 0 | -1 | -8 |
| [micro-index/source/pages/index/actions/index.js](/micro-index/source/pages/index/actions/index.js) | JavaScript | -111 | 0 | -3 | -114 |
| [micro-index/source/pages/index/components/AppBox/index.js](/micro-index/source/pages/index/components/AppBox/index.js) | JavaScript | -163 | -14 | -15 | -192 |
| [micro-index/source/pages/index/components/AppList/index.js](/micro-index/source/pages/index/components/AppList/index.js) | JavaScript | -94 | -2 | -9 | -105 |
| [micro-index/source/pages/index/components/Banner/index.js](/micro-index/source/pages/index/components/Banner/index.js) | JavaScript | -46 | -1 | -6 | -53 |
| [micro-index/source/pages/index/components/ErrorBoundary.js](/micro-index/source/pages/index/components/ErrorBoundary.js) | JavaScript | -14 | -1 | -5 | -20 |
| [micro-index/source/pages/index/components/Experience/index.less](/micro-index/source/pages/index/components/Experience/index.less) | Less | -35 | 0 | -7 | -42 |
| [micro-index/source/pages/index/components/Experience/index.tsx](/micro-index/source/pages/index/components/Experience/index.tsx) | TypeScript JSX | -65 | 0 | -11 | -76 |
| [micro-index/source/pages/index/components/FeatsIntro/index.less](/micro-index/source/pages/index/components/FeatsIntro/index.less) | Less | -37 | 0 | -6 | -43 |
| [micro-index/source/pages/index/components/FeatsIntro/index.tsx](/micro-index/source/pages/index/components/FeatsIntro/index.tsx) | TypeScript JSX | -58 | 0 | -12 | -70 |
| [micro-index/source/pages/index/components/Home/index.js](/micro-index/source/pages/index/components/Home/index.js) | JavaScript | -331 | -30 | -26 | -387 |
| [micro-index/source/pages/index/components/Home/index.less](/micro-index/source/pages/index/components/Home/index.less) | Less | -360 | -6 | -64 | -430 |
| [micro-index/source/pages/index/components/NotFound/doc.md](/micro-index/source/pages/index/components/NotFound/doc.md) | Markdown | -34 | 0 | -6 | -40 |
| [micro-index/source/pages/index/components/NotFound/index.js](/micro-index/source/pages/index/components/NotFound/index.js) | JavaScript | -17 | 0 | -4 | -21 |
| [micro-index/source/pages/index/components/NotFound/index.less](/micro-index/source/pages/index/components/NotFound/index.less) | Less | -28 | 0 | -1 | -29 |
| [micro-index/source/pages/index/components/Notice/index.js](/micro-index/source/pages/index/components/Notice/index.js) | JavaScript | -91 | -4 | -11 | -106 |
| [micro-index/source/pages/index/components/QuickStart/index.less](/micro-index/source/pages/index/components/QuickStart/index.less) | Less | -21 | 0 | -4 | -25 |
| [micro-index/source/pages/index/components/QuickStart/index.tsx](/micro-index/source/pages/index/components/QuickStart/index.tsx) | TypeScript JSX | -58 | -1 | -11 | -70 |
| [micro-index/source/pages/index/container/AppList/index.js](/micro-index/source/pages/index/container/AppList/index.js) | JavaScript | -13 | 0 | -4 | -17 |
| [micro-index/source/pages/index/container/Guide/components/GuideCard/index.jsx](/micro-index/source/pages/index/container/Guide/components/GuideCard/index.jsx) | JavaScript JSX | -114 | -2 | -4 | -120 |
| [micro-index/source/pages/index/container/Guide/components/GuideCard/index.less](/micro-index/source/pages/index/container/Guide/components/GuideCard/index.less) | Less | -83 | 0 | -1 | -84 |
| [micro-index/source/pages/index/container/Guide/components/ToolBox/index.jsx](/micro-index/source/pages/index/container/Guide/components/ToolBox/index.jsx) | JavaScript JSX | -60 | 0 | -6 | -66 |
| [micro-index/source/pages/index/container/Guide/components/ToolBox/index.less](/micro-index/source/pages/index/container/Guide/components/ToolBox/index.less) | Less | -92 | 0 | -1 | -93 |
| [micro-index/source/pages/index/container/Guide/config.js](/micro-index/source/pages/index/container/Guide/config.js) | JavaScript | -242 | 0 | -1 | -243 |
| [micro-index/source/pages/index/container/Guide/index.jsx](/micro-index/source/pages/index/container/Guide/index.jsx) | JavaScript JSX | -68 | -1 | -3 | -72 |
| [micro-index/source/pages/index/container/Guide/index.less](/micro-index/source/pages/index/container/Guide/index.less) | Less | -71 | 0 | -1 | -72 |
| [micro-index/source/pages/index/container/Home/index.js](/micro-index/source/pages/index/container/Home/index.js) | JavaScript | -13 | 0 | -4 | -17 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverCC/index.less](/micro-index/source/pages/index/container/TrialGuide/DiscoverCC/index.less) | Less | -3 | 0 | -1 | -4 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverCC/index.tsx](/micro-index/source/pages/index/container/TrialGuide/DiscoverCC/index.tsx) | TypeScript JSX | -36 | 0 | -6 | -42 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverOnline/index.less](/micro-index/source/pages/index/container/TrialGuide/DiscoverOnline/index.less) | Less | -3 | 0 | -1 | -4 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverOnline/index.tsx](/micro-index/source/pages/index/container/TrialGuide/DiscoverOnline/index.tsx) | TypeScript JSX | -36 | 0 | -6 | -42 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverQiyu/index.less](/micro-index/source/pages/index/container/TrialGuide/DiscoverQiyu/index.less) | Less | -3 | 0 | -1 | -4 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverQiyu/index.tsx](/micro-index/source/pages/index/container/TrialGuide/DiscoverQiyu/index.tsx) | TypeScript JSX | -34 | 0 | -7 | -41 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverRobot/index.less](/micro-index/source/pages/index/container/TrialGuide/DiscoverRobot/index.less) | Less | -3 | 0 | -1 | -4 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverRobot/index.tsx](/micro-index/source/pages/index/container/TrialGuide/DiscoverRobot/index.tsx) | TypeScript JSX | -36 | 0 | -6 | -42 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverWorksheet/index.less](/micro-index/source/pages/index/container/TrialGuide/DiscoverWorksheet/index.less) | Less | -3 | 0 | -1 | -4 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverWorksheet/index.tsx](/micro-index/source/pages/index/container/TrialGuide/DiscoverWorksheet/index.tsx) | TypeScript JSX | -35 | 0 | -6 | -41 |
| [micro-index/source/pages/index/container/TrialGuide/ExperienceCall/index.less](/micro-index/source/pages/index/container/TrialGuide/ExperienceCall/index.less) | Less | -3 | 0 | -1 | -4 |
| [micro-index/source/pages/index/container/TrialGuide/ExperienceCall/index.tsx](/micro-index/source/pages/index/container/TrialGuide/ExperienceCall/index.tsx) | TypeScript JSX | -35 | 0 | -5 | -40 |
| [micro-index/source/pages/index/container/TrialGuide/ExperienceRobot/index.less](/micro-index/source/pages/index/container/TrialGuide/ExperienceRobot/index.less) | Less | -36 | 0 | -7 | -43 |
| [micro-index/source/pages/index/container/TrialGuide/ExperienceRobot/index.tsx](/micro-index/source/pages/index/container/TrialGuide/ExperienceRobot/index.tsx) | TypeScript JSX | -83 | 0 | -11 | -94 |
| [micro-index/source/pages/index/container/TrialGuide/ExperienceSession/index.less](/micro-index/source/pages/index/container/TrialGuide/ExperienceSession/index.less) | Less | -3 | 0 | -1 | -4 |
| [micro-index/source/pages/index/container/TrialGuide/ExperienceSession/index.tsx](/micro-index/source/pages/index/container/TrialGuide/ExperienceSession/index.tsx) | TypeScript JSX | -47 | 0 | -7 | -54 |
| [micro-index/source/pages/index/container/TrialGuide/MoreCC/index.less](/micro-index/source/pages/index/container/TrialGuide/MoreCC/index.less) | Less | -4 | 0 | -1 | -5 |
| [micro-index/source/pages/index/container/TrialGuide/MoreCC/index.tsx](/micro-index/source/pages/index/container/TrialGuide/MoreCC/index.tsx) | TypeScript JSX | -68 | 0 | -8 | -76 |
| [micro-index/source/pages/index/container/TrialGuide/MoreOnline/index.less](/micro-index/source/pages/index/container/TrialGuide/MoreOnline/index.less) | Less | -4 | 0 | -1 | -5 |
| [micro-index/source/pages/index/container/TrialGuide/MoreOnline/index.tsx](/micro-index/source/pages/index/container/TrialGuide/MoreOnline/index.tsx) | TypeScript JSX | -59 | 0 | -8 | -67 |
| [micro-index/source/pages/index/container/TrialGuide/MoreRobot/index.less](/micro-index/source/pages/index/container/TrialGuide/MoreRobot/index.less) | Less | -4 | 0 | -1 | -5 |
| [micro-index/source/pages/index/container/TrialGuide/MoreRobot/index.tsx](/micro-index/source/pages/index/container/TrialGuide/MoreRobot/index.tsx) | TypeScript JSX | -59 | 0 | -8 | -67 |
| [micro-index/source/pages/index/container/TrialGuide/index.less](/micro-index/source/pages/index/container/TrialGuide/index.less) | Less | -52 | -1 | -9 | -62 |
| [micro-index/source/pages/index/container/TrialGuide/index.tsx](/micro-index/source/pages/index/container/TrialGuide/index.tsx) | TypeScript JSX | -385 | -9 | -25 | -419 |
| [micro-index/source/pages/index/entry.js](/micro-index/source/pages/index/entry.js) | JavaScript | -26 | -5 | -6 | -37 |
| [micro-index/source/pages/index/index.js](/micro-index/source/pages/index/index.js) | JavaScript | -5 | 0 | -2 | -7 |
| [micro-index/source/pages/index/qxy/components/VideoList/index.less](/micro-index/source/pages/index/qxy/components/VideoList/index.less) | Less | -70 | 0 | -10 | -80 |
| [micro-index/source/pages/index/qxy/components/VideoList/index.tsx](/micro-index/source/pages/index/qxy/components/VideoList/index.tsx) | TypeScript JSX | -43 | 0 | -6 | -49 |
| [micro-index/source/pages/index/qxy/components/VideoModal/index.less](/micro-index/source/pages/index/qxy/components/VideoModal/index.less) | Less | -54 | -1 | -7 | -62 |
| [micro-index/source/pages/index/qxy/components/VideoModal/index.tsx](/micro-index/source/pages/index/qxy/components/VideoModal/index.tsx) | TypeScript JSX | -42 | 0 | -7 | -49 |
| [micro-index/source/pages/index/qxy/data/course.json](/micro-index/source/pages/index/qxy/data/course.json) | JSON | -1,122 | 0 | 0 | -1,122 |
| [micro-index/source/pages/index/qxy/index.less](/micro-index/source/pages/index/qxy/index.less) | Less | -86 | -1 | -16 | -103 |
| [micro-index/source/pages/index/qxy/index.tsx](/micro-index/source/pages/index/qxy/index.tsx) | TypeScript JSX | -88 | -1 | -11 | -100 |
| [micro-index/source/pages/index/qxy/store/index.ts](/micro-index/source/pages/index/qxy/store/index.ts) | TypeScript | -46 | 0 | -6 | -52 |
| [micro-index/source/pages/index/reducers/initialState.js](/micro-index/source/pages/index/reducers/initialState.js) | JavaScript | -9 | -4 | -1 | -14 |
| [micro-index/source/pages/index/reducers/reducer.js](/micro-index/source/pages/index/reducers/reducer.js) | JavaScript | -51 | 0 | -9 | -60 |
| [micro-index/source/pages/index/reducers/rootReducer.js](/micro-index/source/pages/index/reducers/rootReducer.js) | JavaScript | -10 | 0 | -3 | -13 |
| [micro-index/source/pages/index/routes.js](/micro-index/source/pages/index/routes.js) | JavaScript | -46 | -1 | -4 | -51 |
| [micro-index/source/pages/index/services.js](/micro-index/source/pages/index/services.js) | JavaScript | -50 | 0 | -4 | -54 |
| [micro-index/source/pages/index/view.js](/micro-index/source/pages/index/view.js) | JavaScript | -13 | 0 | -4 | -17 |
| [micro-index/source/reducers/initialState.js](/micro-index/source/reducers/initialState.js) | JavaScript | -11 | -7 | -2 | -20 |
| [micro-index/source/reducers/reducer.js](/micro-index/source/reducers/reducer.js) | JavaScript | -12 | -2 | -2 | -16 |
| [micro-index/source/store/configureStore.dev.js](/micro-index/source/store/configureStore.dev.js) | JavaScript | -16 | -8 | -6 | -30 |
| [micro-index/source/store/configureStore.js](/micro-index/source/store/configureStore.js) | JavaScript | -5 | 0 | -1 | -6 |
| [micro-index/source/store/configureStore.prod.js](/micro-index/source/store/configureStore.prod.js) | JavaScript | -10 | 0 | -2 | -12 |
| [micro-index/source/typings/index.d.ts](/micro-index/source/typings/index.d.ts) | TypeScript | -7 | 0 | -1 | -8 |
| [micro-index/source/utils/DevTools.js](/micro-index/source/utils/DevTools.js) | JavaScript | -9 | -1 | -2 | -12 |
| [micro-index/source/utils/ajax.js](/micro-index/source/utils/ajax.js) | JavaScript | -124 | -27 | -8 | -159 |
| [micro-index/source/utils/cli.js](/micro-index/source/utils/cli.js) | JavaScript | -80 | -23 | -9 | -112 |
| [micro-index/source/utils/getWindowVar.js](/micro-index/source/utils/getWindowVar.js) | JavaScript | -90 | -39 | -20 | -149 |
| [micro-index/source/utils/iframeWrapper.js](/micro-index/source/utils/iframeWrapper.js) | JavaScript | -67 | -44 | -8 | -119 |
| [micro-index/source/utils/index.js](/micro-index/source/utils/index.js) | JavaScript | -31 | -6 | -2 | -39 |
| [micro-index/source/utils/publicPath.js](/micro-index/source/utils/publicPath.js) | JavaScript | -52 | -28 | -9 | -89 |
| [micro-index/source/utils/type2type.js](/micro-index/source/utils/type2type.js) | JavaScript | -26 | -21 | -7 | -54 |
| [micro-index/source/utils/webpackPublicPath.js](/micro-index/source/utils/webpackPublicPath.js) | JavaScript | -5 | -4 | -2 | -11 |
| [micro-index/source/vendor/js/lib/napm-web-min-1.1.6.js](/micro-index/source/vendor/js/lib/napm-web-min-1.1.6.js) | JavaScript | -1 | 0 | 0 | -1 |
| [micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/icons.svg](/micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/icons.svg) | XML | 1 | 0 | 0 | 1 |
| [micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/jsonTree.css](/micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/jsonTree.css) | PostCSS | 90 | 15 | 7 | 112 |
| [micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/jsonTree.js](/micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/jsonTree.js) | JavaScript | 391 | 314 | 107 | 812 |
| [micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/recorder.css](/micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/recorder.css) | PostCSS | 90 | 1 | 22 | 113 |
| [micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/recorder.html](/micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/recorder.html) | HTML | 16 | 3 | 1 | 20 |
| [micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/recorder.js](/micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/recorder.js) | JavaScript | 82 | 6 | 10 | 98 |
| [micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/recorderServer.js](/micro-index/tools/SubmoduleReferencedStatisticsPlugin/contents/recorderServer.js) | JavaScript | 19 | 0 | 4 | 23 |
| [micro-index/tools/SubmoduleReferencedStatisticsPlugin/index.js](/micro-index/tools/SubmoduleReferencedStatisticsPlugin/index.js) | JavaScript | 124 | 22 | 17 | 163 |
| [micro-index/tools/analyzeBundle.js](/micro-index/tools/analyzeBundle.js) | JavaScript | 12 | 0 | 6 | 18 |
| [micro-index/tools/assetsTransformer.js](/micro-index/tools/assetsTransformer.js) | JavaScript | 6 | 7 | 2 | 15 |
| [micro-index/tools/build.dll.js](/micro-index/tools/build.dll.js) | JavaScript | 84 | 13 | 16 | 113 |
| [micro-index/tools/build.js](/micro-index/tools/build.js) | JavaScript | 72 | 11 | 14 | 97 |
| [micro-index/tools/chalkConfig.js](/micro-index/tools/chalkConfig.js) | JavaScript | 5 | 1 | 1 | 7 |
| [micro-index/tools/config.d.ts](/micro-index/tools/config.d.ts) | TypeScript | 81 | 91 | 11 | 183 |
| [micro-index/tools/distServer.js](/micro-index/tools/distServer.js) | JavaScript | 50 | 4 | 10 | 64 |
| [micro-index/tools/helps.js](/micro-index/tools/helps.js) | JavaScript | 275 | 56 | 35 | 366 |
| [micro-index/tools/loader/debug-loader.js](/micro-index/tools/loader/debug-loader.js) | JavaScript | 12 | 0 | 5 | 17 |
| [micro-index/tools/loader/freemarker-Readme.md](/micro-index/tools/loader/freemarker-Readme.md) | Markdown | 60 | 0 | 29 | 89 |
| [micro-index/tools/loader/ftl-loader-prod.js](/micro-index/tools/loader/ftl-loader-prod.js) | JavaScript | 8 | 0 | 3 | 11 |
| [micro-index/tools/loader/ftl-loader.js](/micro-index/tools/loader/ftl-loader.js) | JavaScript | 51 | 3 | 10 | 64 |
| [micro-index/tools/mock.js](/micro-index/tools/mock.js) | JavaScript | 38 | 5 | 5 | 48 |
| [micro-index/tools/neiPatch.js](/micro-index/tools/neiPatch.js) | JavaScript | 59 | 4 | 4 | 67 |
| [micro-index/tools/srcServer.js](/micro-index/tools/srcServer.js) | JavaScript | 187 | 47 | 21 | 255 |
| [micro-index/tools/startMessage.js](/micro-index/tools/startMessage.js) | JavaScript | 2 | 1 | 3 | 6 |
| [micro-index/tools/testCi.js](/micro-index/tools/testCi.js) | JavaScript | 12 | 1 | 4 | 17 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details