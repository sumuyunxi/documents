# Diff Summary

Date : 2025-08-12 20:47:25

Directory e:\\WorkSpace\\Netease\\theaiarchitect\\FrontAIArchitect\\CodeGraph\\micro-index\\tools

Total : 135 files,  -4782 codes, 187 comments, -304 blanks, all -4899 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| PostCSS | 2 | 180 | 16 | 29 | 225 |
| TypeScript | 3 | 28 | 91 | 4 | 123 |
| Markdown | 2 | 26 | 0 | 23 | 49 |
| HTML | 1 | 16 | 3 | 1 | 20 |
| XML | 1 | 1 | 0 | 0 | 1 |
| JavaScript JSX | 3 | -242 | -3 | -13 | -258 |
| JavaScript | 74 | -847 | 131 | 6 | -710 |
| JSON | 1 | -1,122 | 0 | 0 | -1,122 |
| TypeScript JSX | 18 | -1,267 | -11 | -161 | -1,439 |
| Less | 30 | -1,555 | -40 | -193 | -1,788 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 135 | -4,782 | 187 | -304 | -4,899 |
| . (Files) | 13 | 883 | 241 | 132 | 1,256 |
| .. | 110 | -6,609 | -418 | -651 | -7,678 |
| ..\\source | 110 | -6,609 | -418 | -651 | -7,678 |
| ..\\source (Files) | 2 | -27 | -26 | -7 | -60 |
| ..\\source\\__mock__ | 2 | -34 | -5 | -9 | -48 |
| ..\\source\\actions | 2 | -8 | -2 | -3 | -13 |
| ..\\source\\assets | 6 | -483 | -31 | -47 | -561 |
| ..\\source\\assets\\css | 6 | -483 | -31 | -47 | -561 |
| ..\\source\\assets\\css\\common | 5 | -483 | -30 | -46 | -559 |
| ..\\source\\assets\\css\\lib | 1 | 0 | -1 | -1 | -2 |
| ..\\source\\config | 5 | -202 | -39 | -13 | -254 |
| ..\\source\\constants | 4 | -35 | -12 | -5 | -52 |
| ..\\source\\middleware | 1 | -69 | -8 | -18 | -95 |
| ..\\source\\pages | 72 | -5,205 | -85 | -468 | -5,758 |
| ..\\source\\pages (Files) | 3 | -53 | 0 | -8 | -61 |
| ..\\source\\pages\\index | 69 | -5,152 | -85 | -460 | -5,697 |
| ..\\source\\pages\\index (Files) | 7 | -171 | -6 | -28 | -205 |
| ..\\source\\pages\\index\\actions | 2 | -118 | 0 | -4 | -122 |
| ..\\source\\pages\\index\\components | 16 | -1,452 | -59 | -198 | -1,709 |
| ..\\source\\pages\\index\\components (Files) | 1 | -14 | -1 | -5 | -20 |
| ..\\source\\pages\\index\\components\\AppBox | 1 | -163 | -14 | -15 | -192 |
| ..\\source\\pages\\index\\components\\AppList | 1 | -94 | -2 | -9 | -105 |
| ..\\source\\pages\\index\\components\\Banner | 1 | -46 | -1 | -6 | -53 |
| ..\\source\\pages\\index\\components\\Experience | 2 | -100 | 0 | -18 | -118 |
| ..\\source\\pages\\index\\components\\FeatsIntro | 2 | -95 | 0 | -18 | -113 |
| ..\\source\\pages\\index\\components\\Home | 2 | -691 | -36 | -90 | -817 |
| ..\\source\\pages\\index\\components\\NotFound | 3 | -79 | 0 | -11 | -90 |
| ..\\source\\pages\\index\\components\\Notice | 1 | -91 | -4 | -11 | -106 |
| ..\\source\\pages\\index\\components\\QuickStart | 2 | -79 | -1 | -15 | -95 |
| ..\\source\\pages\\index\\container | 33 | -1,790 | -13 | -154 | -1,957 |
| ..\\source\\pages\\index\\container\\AppList | 1 | -13 | 0 | -4 | -17 |
| ..\\source\\pages\\index\\container\\Guide | 7 | -730 | -3 | -17 | -750 |
| ..\\source\\pages\\index\\container\\Guide (Files) | 3 | -381 | -1 | -5 | -387 |
| ..\\source\\pages\\index\\container\\Guide\\components | 4 | -349 | -2 | -12 | -363 |
| ..\\source\\pages\\index\\container\\Guide\\components\\GuideCard | 2 | -197 | -2 | -5 | -204 |
| ..\\source\\pages\\index\\container\\Guide\\components\\ToolBox | 2 | -152 | 0 | -7 | -159 |
| ..\\source\\pages\\index\\container\\Home | 1 | -13 | 0 | -4 | -17 |
| ..\\source\\pages\\index\\container\\TrialGuide | 24 | -1,034 | -10 | -129 | -1,173 |
| ..\\source\\pages\\index\\container\\TrialGuide (Files) | 2 | -437 | -10 | -34 | -481 |
| ..\\source\\pages\\index\\container\\TrialGuide\\DiscoverCC | 2 | -39 | 0 | -7 | -46 |
| ..\\source\\pages\\index\\container\\TrialGuide\\DiscoverOnline | 2 | -39 | 0 | -7 | -46 |
| ..\\source\\pages\\index\\container\\TrialGuide\\DiscoverQiyu | 2 | -37 | 0 | -8 | -45 |
| ..\\source\\pages\\index\\container\\TrialGuide\\DiscoverRobot | 2 | -39 | 0 | -7 | -46 |
| ..\\source\\pages\\index\\container\\TrialGuide\\DiscoverWorksheet | 2 | -38 | 0 | -7 | -45 |
| ..\\source\\pages\\index\\container\\TrialGuide\\ExperienceCall | 2 | -38 | 0 | -6 | -44 |
| ..\\source\\pages\\index\\container\\TrialGuide\\ExperienceRobot | 2 | -119 | 0 | -18 | -137 |
| ..\\source\\pages\\index\\container\\TrialGuide\\ExperienceSession | 2 | -50 | 0 | -8 | -58 |
| ..\\source\\pages\\index\\container\\TrialGuide\\MoreCC | 2 | -72 | 0 | -9 | -81 |
| ..\\source\\pages\\index\\container\\TrialGuide\\MoreOnline | 2 | -63 | 0 | -9 | -72 |
| ..\\source\\pages\\index\\container\\TrialGuide\\MoreRobot | 2 | -63 | 0 | -9 | -72 |
| ..\\source\\pages\\index\\qxy | 8 | -1,551 | -3 | -63 | -1,617 |
| ..\\source\\pages\\index\\qxy (Files) | 2 | -174 | -2 | -27 | -203 |
| ..\\source\\pages\\index\\qxy\\components | 4 | -209 | -1 | -30 | -240 |
| ..\\source\\pages\\index\\qxy\\components\\VideoList | 2 | -113 | 0 | -16 | -129 |
| ..\\source\\pages\\index\\qxy\\components\\VideoModal | 2 | -96 | -1 | -14 | -111 |
| ..\\source\\pages\\index\\qxy\\data | 1 | -1,122 | 0 | 0 | -1,122 |
| ..\\source\\pages\\index\\qxy\\store | 1 | -46 | 0 | -6 | -52 |
| ..\\source\\pages\\index\\reducers | 3 | -70 | -4 | -13 | -87 |
| ..\\source\\reducers | 2 | -23 | -9 | -4 | -36 |
| ..\\source\\store | 3 | -31 | -8 | -9 | -48 |
| ..\\source\\typings | 1 | -7 | 0 | -1 | -8 |
| ..\\source\\utils | 9 | -484 | -193 | -67 | -744 |
| ..\\source\\vendor | 1 | -1 | 0 | 0 | -1 |
| ..\\source\\vendor\\js | 1 | -1 | 0 | 0 | -1 |
| ..\\source\\vendor\\js\\lib | 1 | -1 | 0 | 0 | -1 |
| SubmoduleReferencedStatisticsPlugin | 8 | 813 | 361 | 168 | 1,342 |
| SubmoduleReferencedStatisticsPlugin (Files) | 1 | 124 | 22 | 17 | 163 |
| SubmoduleReferencedStatisticsPlugin\\contents | 7 | 689 | 339 | 151 | 1,179 |
| loader | 4 | 131 | 3 | 47 | 181 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)