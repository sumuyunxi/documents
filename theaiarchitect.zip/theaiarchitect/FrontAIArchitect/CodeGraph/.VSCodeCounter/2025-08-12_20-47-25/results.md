# Summary

Date : 2025-08-12 20:47:25

Directory e:\\WorkSpace\\Netease\\theaiarchitect\\FrontAIArchitect\\CodeGraph\\micro-index\\tools

Total : 25 files,  1827 codes, 605 comments, 347 blanks, all 2779 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JavaScript | 19 | 1,489 | 495 | 277 | 2,261 |
| PostCSS | 2 | 180 | 16 | 29 | 225 |
| TypeScript | 1 | 81 | 91 | 11 | 183 |
| Markdown | 1 | 60 | 0 | 29 | 89 |
| HTML | 1 | 16 | 3 | 1 | 20 |
| XML | 1 | 1 | 0 | 0 | 1 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 25 | 1,827 | 605 | 347 | 2,779 |
| . (Files) | 13 | 883 | 241 | 132 | 1,256 |
| SubmoduleReferencedStatisticsPlugin | 8 | 813 | 361 | 168 | 1,342 |
| SubmoduleReferencedStatisticsPlugin (Files) | 1 | 124 | 22 | 17 | 163 |
| SubmoduleReferencedStatisticsPlugin\\contents | 7 | 689 | 339 | 151 | 1,179 |
| loader | 4 | 131 | 3 | 47 | 181 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)