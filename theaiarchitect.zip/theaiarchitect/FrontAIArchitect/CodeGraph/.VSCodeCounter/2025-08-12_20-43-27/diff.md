# Diff Summary

Date : 2025-08-12 20:43:27

Directory e:\\WorkSpace\\Netease\\theaiarchitect\\FrontAIArchitect\\CodeGraph\\micro-index\\source

Total : 321 files,  -47509 codes, -1140 comments, -1738 blanks, all -50387 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Less | 60 | 0 | 0 | 0 | 0 |
| TypeScript JSX | 36 | 0 | 0 | 0 | 0 |
| JavaScript JSX | 6 | 0 | 0 | 0 | 0 |
| Docker | 1 | -5 | 0 | -5 | -10 |
| MS SQL | 1 | -11 | 0 | -1 | -12 |
| HTML | 2 | -26 | -3 | -2 | -31 |
| JSON with Comments | 1 | -40 | 0 | -1 | -41 |
| TypeScript | 5 | -81 | -91 | -11 | -183 |
| YAML | 2 | -86 | 0 | -4 | -90 |
| Java Properties | 20 | -126 | -28 | -33 | -187 |
| Markdown | 6 | -205 | 0 | -55 | -260 |
| XML | 14 | -1,228 | -102 | -302 | -1,632 |
| CSS | 3 | -2,020 | -16 | -641 | -2,677 |
| Java | 16 | -2,127 | -137 | -277 | -2,541 |
| JavaScript | 143 | -2,784 | -763 | -404 | -3,951 |
| JSON | 5 | -38,770 | 0 | -2 | -38,772 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 321 | -47,509 | -1,140 | -1,738 | -50,387 |
| . (Files) | 2 | 27 | 26 | 7 | 60 |
| .. | 211 | -54,118 | -1,558 | -2,389 | -58,065 |
| ..\\.. | 211 | -54,118 | -1,558 | -2,389 | -58,065 |
| ..\\..\\.. | 211 | -54,118 | -1,558 | -2,389 | -58,065 |
| ..\\..\\..\\.. | 211 | -54,118 | -1,558 | -2,389 | -58,065 |
| ..\\..\\..\\..\\.. | 211 | -54,118 | -1,558 | -2,389 | -58,065 |
| ..\\..\\..\\..\\..\\.. | 211 | -54,118 | -1,558 | -2,389 | -58,065 |
| ..\\..\\..\\..\\..\\..\\other | 211 | -54,118 | -1,558 | -2,389 | -58,065 |
| ..\\..\\..\\..\\..\\..\\other\\ragData | 211 | -54,118 | -1,558 | -2,389 | -58,065 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index | 211 | -54,118 | -1,558 | -2,389 | -58,065 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index (Files) | 22 | -40,634 | -237 | -172 | -41,043 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\buildScripts | 4 | -2,161 | -48 | -847 | -3,056 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\docs | 2 | -15 | 0 | -2 | -17 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\docs (Files) | 1 | -4 | 0 | -1 | -5 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\docs\\backend | 1 | -11 | 0 | -1 | -12 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\misc | 5 | -379 | -68 | -35 | -482 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source | 110 | -6,609 | -418 | -651 | -7,678 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source (Files) | 2 | -27 | -26 | -7 | -60 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\__mock__ | 2 | -34 | -5 | -9 | -48 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\actions | 2 | -8 | -2 | -3 | -13 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\assets | 6 | -483 | -31 | -47 | -561 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\assets\\css | 6 | -483 | -31 | -47 | -561 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\assets\\css\\common | 5 | -483 | -30 | -46 | -559 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\assets\\css\\lib | 1 | 0 | -1 | -1 | -2 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\config | 5 | -202 | -39 | -13 | -254 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\constants | 4 | -35 | -12 | -5 | -52 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\middleware | 1 | -69 | -8 | -18 | -95 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages | 72 | -5,205 | -85 | -468 | -5,758 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages (Files) | 3 | -53 | 0 | -8 | -61 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index | 69 | -5,152 | -85 | -460 | -5,697 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index (Files) | 7 | -171 | -6 | -28 | -205 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\actions | 2 | -118 | 0 | -4 | -122 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\components | 16 | -1,452 | -59 | -198 | -1,709 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\components (Files) | 1 | -14 | -1 | -5 | -20 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\components\\AppBox | 1 | -163 | -14 | -15 | -192 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\components\\AppList | 1 | -94 | -2 | -9 | -105 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\components\\Banner | 1 | -46 | -1 | -6 | -53 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\components\\Experience | 2 | -100 | 0 | -18 | -118 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\components\\FeatsIntro | 2 | -95 | 0 | -18 | -113 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\components\\Home | 2 | -691 | -36 | -90 | -817 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\components\\NotFound | 3 | -79 | 0 | -11 | -90 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\components\\Notice | 1 | -91 | -4 | -11 | -106 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\components\\QuickStart | 2 | -79 | -1 | -15 | -95 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container | 33 | -1,790 | -13 | -154 | -1,957 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\AppList | 1 | -13 | 0 | -4 | -17 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\Guide | 7 | -730 | -3 | -17 | -750 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\Guide (Files) | 3 | -381 | -1 | -5 | -387 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\Guide\\components | 4 | -349 | -2 | -12 | -363 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\Guide\\components\\GuideCard | 2 | -197 | -2 | -5 | -204 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\Guide\\components\\ToolBox | 2 | -152 | 0 | -7 | -159 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\Home | 1 | -13 | 0 | -4 | -17 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide | 24 | -1,034 | -10 | -129 | -1,173 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide (Files) | 2 | -437 | -10 | -34 | -481 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\DiscoverCC | 2 | -39 | 0 | -7 | -46 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\DiscoverOnline | 2 | -39 | 0 | -7 | -46 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\DiscoverQiyu | 2 | -37 | 0 | -8 | -45 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\DiscoverRobot | 2 | -39 | 0 | -7 | -46 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\DiscoverWorksheet | 2 | -38 | 0 | -7 | -45 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\ExperienceCall | 2 | -38 | 0 | -6 | -44 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\ExperienceRobot | 2 | -119 | 0 | -18 | -137 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\ExperienceSession | 2 | -50 | 0 | -8 | -58 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\MoreCC | 2 | -72 | 0 | -9 | -81 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\MoreOnline | 2 | -63 | 0 | -9 | -72 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\MoreRobot | 2 | -63 | 0 | -9 | -72 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\qxy | 8 | -1,551 | -3 | -63 | -1,617 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\qxy (Files) | 2 | -174 | -2 | -27 | -203 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\qxy\\components | 4 | -209 | -1 | -30 | -240 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\qxy\\components\\VideoList | 2 | -113 | 0 | -16 | -129 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\qxy\\components\\VideoModal | 2 | -96 | -1 | -14 | -111 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\qxy\\data | 1 | -1,122 | 0 | 0 | -1,122 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\qxy\\store | 1 | -46 | 0 | -6 | -52 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\pages\\index\\reducers | 3 | -70 | -4 | -13 | -87 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\reducers | 2 | -23 | -9 | -4 | -36 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\store | 3 | -31 | -8 | -9 | -48 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\typings | 1 | -7 | 0 | -1 | -8 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\utils | 9 | -484 | -193 | -67 | -744 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\vendor | 1 | -1 | 0 | 0 | -1 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\vendor\\js | 1 | -1 | 0 | 0 | -1 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\source\\vendor\\js\\lib | 1 | -1 | 0 | 0 | -1 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src | 43 | -2,493 | -182 | -335 | -3,010 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main | 43 | -2,493 | -182 | -335 | -3,010 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\filters | 13 | -82 | 0 | -14 | -96 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java | 16 | -2,127 | -137 | -277 | -2,541 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java\\com | 16 | -2,127 | -137 | -277 | -2,541 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease | 16 | -2,127 | -137 | -277 | -2,541 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf | 16 | -2,127 | -137 | -277 | -2,541 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\device | 2 | -57 | 0 | -22 | -79 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\device\\dao | 1 | -22 | 0 | -8 | -30 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\device\\model | 1 | -35 | 0 | -14 | -49 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro | 14 | -2,070 | -137 | -255 | -2,462 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index | 14 | -2,070 | -137 | -255 | -2,462 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index (Files) | 1 | -40 | 0 | -4 | -44 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\cdn | 1 | -167 | -5 | -43 | -215 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\config | 1 | -42 | 0 | -9 | -51 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\controller | 2 | -256 | -15 | -25 | -296 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\instance | 1 | -69 | -4 | -20 | -93 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\intercepter | 5 | -1,400 | -104 | -134 | -1,638 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\model | 2 | -18 | 0 | -6 | -24 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\nos | 1 | -78 | -9 | -14 | -101 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\resources | 14 | -284 | -45 | -44 | -373 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\resources (Files) | 2 | -185 | -14 | -13 | -212 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\resources\\config | 7 | -53 | -8 | -10 | -71 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\resources\\mapper | 1 | -28 | 0 | -7 | -35 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\resources\\sentry-javaagent-home | 3 | -8 | -23 | -13 | -44 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\src\\main\\resources\\static | 1 | -10 | 0 | -1 | -11 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\tools | 25 | -1,827 | -605 | -347 | -2,779 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\tools (Files) | 13 | -883 | -241 | -132 | -1,256 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\tools\\SubmoduleReferencedStatisticsPlugin | 8 | -813 | -361 | -168 | -1,342 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\tools\\SubmoduleReferencedStatisticsPlugin (Files) | 1 | -124 | -22 | -17 | -163 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\tools\\SubmoduleReferencedStatisticsPlugin\\contents | 7 | -689 | -339 | -151 | -1,179 |
| ..\\..\\..\\..\\..\\..\\other\\ragData\\micro-index\\tools\\loader | 4 | -131 | -3 | -47 | -181 |
| __mock__ | 2 | 34 | 5 | 9 | 48 |
| actions | 2 | 8 | 2 | 3 | 13 |
| assets | 6 | 483 | 31 | 47 | 561 |
| assets\\css | 6 | 483 | 31 | 47 | 561 |
| assets\\css\\common | 5 | 483 | 30 | 46 | 559 |
| assets\\css\\lib | 1 | 0 | 1 | 1 | 2 |
| config | 5 | 202 | 39 | 13 | 254 |
| constants | 4 | 35 | 12 | 5 | 52 |
| middleware | 1 | 69 | 8 | 18 | 95 |
| pages | 72 | 5,205 | 85 | 468 | 5,758 |
| pages (Files) | 3 | 53 | 0 | 8 | 61 |
| pages\\index | 69 | 5,152 | 85 | 460 | 5,697 |
| pages\\index (Files) | 7 | 171 | 6 | 28 | 205 |
| pages\\index\\actions | 2 | 118 | 0 | 4 | 122 |
| pages\\index\\components | 16 | 1,452 | 59 | 198 | 1,709 |
| pages\\index\\components (Files) | 1 | 14 | 1 | 5 | 20 |
| pages\\index\\components\\AppBox | 1 | 163 | 14 | 15 | 192 |
| pages\\index\\components\\AppList | 1 | 94 | 2 | 9 | 105 |
| pages\\index\\components\\Banner | 1 | 46 | 1 | 6 | 53 |
| pages\\index\\components\\Experience | 2 | 100 | 0 | 18 | 118 |
| pages\\index\\components\\FeatsIntro | 2 | 95 | 0 | 18 | 113 |
| pages\\index\\components\\Home | 2 | 691 | 36 | 90 | 817 |
| pages\\index\\components\\NotFound | 3 | 79 | 0 | 11 | 90 |
| pages\\index\\components\\Notice | 1 | 91 | 4 | 11 | 106 |
| pages\\index\\components\\QuickStart | 2 | 79 | 1 | 15 | 95 |
| pages\\index\\container | 33 | 1,790 | 13 | 154 | 1,957 |
| pages\\index\\container\\AppList | 1 | 13 | 0 | 4 | 17 |
| pages\\index\\container\\Guide | 7 | 730 | 3 | 17 | 750 |
| pages\\index\\container\\Guide (Files) | 3 | 381 | 1 | 5 | 387 |
| pages\\index\\container\\Guide\\components | 4 | 349 | 2 | 12 | 363 |
| pages\\index\\container\\Guide\\components\\GuideCard | 2 | 197 | 2 | 5 | 204 |
| pages\\index\\container\\Guide\\components\\ToolBox | 2 | 152 | 0 | 7 | 159 |
| pages\\index\\container\\Home | 1 | 13 | 0 | 4 | 17 |
| pages\\index\\container\\TrialGuide | 24 | 1,034 | 10 | 129 | 1,173 |
| pages\\index\\container\\TrialGuide (Files) | 2 | 437 | 10 | 34 | 481 |
| pages\\index\\container\\TrialGuide\\DiscoverCC | 2 | 39 | 0 | 7 | 46 |
| pages\\index\\container\\TrialGuide\\DiscoverOnline | 2 | 39 | 0 | 7 | 46 |
| pages\\index\\container\\TrialGuide\\DiscoverQiyu | 2 | 37 | 0 | 8 | 45 |
| pages\\index\\container\\TrialGuide\\DiscoverRobot | 2 | 39 | 0 | 7 | 46 |
| pages\\index\\container\\TrialGuide\\DiscoverWorksheet | 2 | 38 | 0 | 7 | 45 |
| pages\\index\\container\\TrialGuide\\ExperienceCall | 2 | 38 | 0 | 6 | 44 |
| pages\\index\\container\\TrialGuide\\ExperienceRobot | 2 | 119 | 0 | 18 | 137 |
| pages\\index\\container\\TrialGuide\\ExperienceSession | 2 | 50 | 0 | 8 | 58 |
| pages\\index\\container\\TrialGuide\\MoreCC | 2 | 72 | 0 | 9 | 81 |
| pages\\index\\container\\TrialGuide\\MoreOnline | 2 | 63 | 0 | 9 | 72 |
| pages\\index\\container\\TrialGuide\\MoreRobot | 2 | 63 | 0 | 9 | 72 |
| pages\\index\\qxy | 8 | 1,551 | 3 | 63 | 1,617 |
| pages\\index\\qxy (Files) | 2 | 174 | 2 | 27 | 203 |
| pages\\index\\qxy\\components | 4 | 209 | 1 | 30 | 240 |
| pages\\index\\qxy\\components\\VideoList | 2 | 113 | 0 | 16 | 129 |
| pages\\index\\qxy\\components\\VideoModal | 2 | 96 | 1 | 14 | 111 |
| pages\\index\\qxy\\data | 1 | 1,122 | 0 | 0 | 1,122 |
| pages\\index\\qxy\\store | 1 | 46 | 0 | 6 | 52 |
| pages\\index\\reducers | 3 | 70 | 4 | 13 | 87 |
| reducers | 2 | 23 | 9 | 4 | 36 |
| store | 3 | 31 | 8 | 9 | 48 |
| typings | 1 | 7 | 0 | 1 | 8 |
| utils | 9 | 484 | 193 | 67 | 744 |
| vendor | 1 | 1 | 0 | 0 | 1 |
| vendor\\js | 1 | 1 | 0 | 0 | 1 |
| vendor\\js\\lib | 1 | 1 | 0 | 0 | 1 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)