# Summary

Date : 2025-08-12 20:43:27

Directory e:\\WorkSpace\\Netease\\theaiarchitect\\FrontAIArchitect\\CodeGraph\\micro-index\\source

Total : 110 files,  6609 codes, 418 comments, 651 blanks, all 7678 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JavaScript | 55 | 2,336 | 364 | 271 | 2,971 |
| Less | 30 | 1,555 | 40 | 193 | 1,788 |
| TypeScript JSX | 18 | 1,267 | 11 | 161 | 1,439 |
| JSON | 1 | 1,122 | 0 | 0 | 1,122 |
| JavaScript JSX | 3 | 242 | 3 | 13 | 258 |
| TypeScript | 2 | 53 | 0 | 7 | 60 |
| Markdown | 1 | 34 | 0 | 6 | 40 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 110 | 6,609 | 418 | 651 | 7,678 |
| . (Files) | 2 | 27 | 26 | 7 | 60 |
| __mock__ | 2 | 34 | 5 | 9 | 48 |
| actions | 2 | 8 | 2 | 3 | 13 |
| assets | 6 | 483 | 31 | 47 | 561 |
| assets\\css | 6 | 483 | 31 | 47 | 561 |
| assets\\css\\common | 5 | 483 | 30 | 46 | 559 |
| assets\\css\\lib | 1 | 0 | 1 | 1 | 2 |
| config | 5 | 202 | 39 | 13 | 254 |
| constants | 4 | 35 | 12 | 5 | 52 |
| middleware | 1 | 69 | 8 | 18 | 95 |
| pages | 72 | 5,205 | 85 | 468 | 5,758 |
| pages (Files) | 3 | 53 | 0 | 8 | 61 |
| pages\\index | 69 | 5,152 | 85 | 460 | 5,697 |
| pages\\index (Files) | 7 | 171 | 6 | 28 | 205 |
| pages\\index\\actions | 2 | 118 | 0 | 4 | 122 |
| pages\\index\\components | 16 | 1,452 | 59 | 198 | 1,709 |
| pages\\index\\components (Files) | 1 | 14 | 1 | 5 | 20 |
| pages\\index\\components\\AppBox | 1 | 163 | 14 | 15 | 192 |
| pages\\index\\components\\AppList | 1 | 94 | 2 | 9 | 105 |
| pages\\index\\components\\Banner | 1 | 46 | 1 | 6 | 53 |
| pages\\index\\components\\Experience | 2 | 100 | 0 | 18 | 118 |
| pages\\index\\components\\FeatsIntro | 2 | 95 | 0 | 18 | 113 |
| pages\\index\\components\\Home | 2 | 691 | 36 | 90 | 817 |
| pages\\index\\components\\NotFound | 3 | 79 | 0 | 11 | 90 |
| pages\\index\\components\\Notice | 1 | 91 | 4 | 11 | 106 |
| pages\\index\\components\\QuickStart | 2 | 79 | 1 | 15 | 95 |
| pages\\index\\container | 33 | 1,790 | 13 | 154 | 1,957 |
| pages\\index\\container\\AppList | 1 | 13 | 0 | 4 | 17 |
| pages\\index\\container\\Guide | 7 | 730 | 3 | 17 | 750 |
| pages\\index\\container\\Guide (Files) | 3 | 381 | 1 | 5 | 387 |
| pages\\index\\container\\Guide\\components | 4 | 349 | 2 | 12 | 363 |
| pages\\index\\container\\Guide\\components\\GuideCard | 2 | 197 | 2 | 5 | 204 |
| pages\\index\\container\\Guide\\components\\ToolBox | 2 | 152 | 0 | 7 | 159 |
| pages\\index\\container\\Home | 1 | 13 | 0 | 4 | 17 |
| pages\\index\\container\\TrialGuide | 24 | 1,034 | 10 | 129 | 1,173 |
| pages\\index\\container\\TrialGuide (Files) | 2 | 437 | 10 | 34 | 481 |
| pages\\index\\container\\TrialGuide\\DiscoverCC | 2 | 39 | 0 | 7 | 46 |
| pages\\index\\container\\TrialGuide\\DiscoverOnline | 2 | 39 | 0 | 7 | 46 |
| pages\\index\\container\\TrialGuide\\DiscoverQiyu | 2 | 37 | 0 | 8 | 45 |
| pages\\index\\container\\TrialGuide\\DiscoverRobot | 2 | 39 | 0 | 7 | 46 |
| pages\\index\\container\\TrialGuide\\DiscoverWorksheet | 2 | 38 | 0 | 7 | 45 |
| pages\\index\\container\\TrialGuide\\ExperienceCall | 2 | 38 | 0 | 6 | 44 |
| pages\\index\\container\\TrialGuide\\ExperienceRobot | 2 | 119 | 0 | 18 | 137 |
| pages\\index\\container\\TrialGuide\\ExperienceSession | 2 | 50 | 0 | 8 | 58 |
| pages\\index\\container\\TrialGuide\\MoreCC | 2 | 72 | 0 | 9 | 81 |
| pages\\index\\container\\TrialGuide\\MoreOnline | 2 | 63 | 0 | 9 | 72 |
| pages\\index\\container\\TrialGuide\\MoreRobot | 2 | 63 | 0 | 9 | 72 |
| pages\\index\\qxy | 8 | 1,551 | 3 | 63 | 1,617 |
| pages\\index\\qxy (Files) | 2 | 174 | 2 | 27 | 203 |
| pages\\index\\qxy\\components | 4 | 209 | 1 | 30 | 240 |
| pages\\index\\qxy\\components\\VideoList | 2 | 113 | 0 | 16 | 129 |
| pages\\index\\qxy\\components\\VideoModal | 2 | 96 | 1 | 14 | 111 |
| pages\\index\\qxy\\data | 1 | 1,122 | 0 | 0 | 1,122 |
| pages\\index\\qxy\\store | 1 | 46 | 0 | 6 | 52 |
| pages\\index\\reducers | 3 | 70 | 4 | 13 | 87 |
| reducers | 2 | 23 | 9 | 4 | 36 |
| store | 3 | 31 | 8 | 9 | 48 |
| typings | 1 | 7 | 0 | 1 | 8 |
| utils | 9 | 484 | 193 | 67 | 744 |
| vendor | 1 | 1 | 0 | 0 | 1 |
| vendor\\js | 1 | 1 | 0 | 0 | 1 |
| vendor\\js\\lib | 1 | 1 | 0 | 0 | 1 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)