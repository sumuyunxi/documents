# Diff Details

Date : 2025-08-12 20:43:27

Directory e:\\WorkSpace\\Netease\\theaiarchitect\\FrontAIArchitect\\CodeGraph\\micro-index\\source

Total : 321 files,  -47509 codes, -1140 comments, -1738 blanks, all -50387 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [micro-index/source/\_\_mock\_\_/localStorage.js](/micro-index/source/__mock__/localStorage.js) | JavaScript | 20 | 0 | 2 | 22 |
| [micro-index/source/\_\_mock\_\_/rAF.js](/micro-index/source/__mock__/rAF.js) | JavaScript | 14 | 5 | 7 | 26 |
| [micro-index/source/actions/actionTypes.js](/micro-index/source/actions/actionTypes.js) | JavaScript | 1 | 0 | 1 | 2 |
| [micro-index/source/actions/actions.js](/micro-index/source/actions/actions.js) | JavaScript | 7 | 2 | 2 | 11 |
| [micro-index/source/app.js](/micro-index/source/app.js) | JavaScript | 22 | 2 | 4 | 28 |
| [micro-index/source/appRoutes.js](/micro-index/source/appRoutes.js) | JavaScript | 5 | 24 | 3 | 32 |
| [micro-index/source/assets/css/common/color.less](/micro-index/source/assets/css/common/color.less) | Less | 15 | 0 | 6 | 21 |
| [micro-index/source/assets/css/common/index.less](/micro-index/source/assets/css/common/index.less) | Less | 4 | 1 | 1 | 6 |
| [micro-index/source/assets/css/common/main.less](/micro-index/source/assets/css/common/main.less) | Less | 44 | 4 | 11 | 59 |
| [micro-index/source/assets/css/common/mixin.less](/micro-index/source/assets/css/common/mixin.less) | Less | 107 | 17 | 24 | 148 |
| [micro-index/source/assets/css/common/reset.less](/micro-index/source/assets/css/common/reset.less) | Less | 313 | 8 | 4 | 325 |
| [micro-index/source/assets/css/lib/ppfish-theme-vars.less](/micro-index/source/assets/css/lib/ppfish-theme-vars.less) | Less | 0 | 1 | 1 | 2 |
| [micro-index/source/config/constants.js](/micro-index/source/config/constants.js) | JavaScript | 13 | 28 | 6 | 47 |
| [micro-index/source/config/dev.js](/micro-index/source/config/dev.js) | JavaScript | 9 | 4 | 1 | 14 |
| [micro-index/source/config/envConfig.js](/micro-index/source/config/envConfig.js) | JavaScript | 133 | 1 | 2 | 136 |
| [micro-index/source/config/index.js](/micro-index/source/config/index.js) | JavaScript | 39 | 3 | 3 | 45 |
| [micro-index/source/config/prod.js](/micro-index/source/config/prod.js) | JavaScript | 8 | 3 | 1 | 12 |
| [micro-index/source/constants/default.js](/micro-index/source/constants/default.js) | JavaScript | 0 | 0 | 1 | 1 |
| [micro-index/source/constants/index.js](/micro-index/source/constants/index.js) | JavaScript | 2 | 5 | 1 | 8 |
| [micro-index/source/constants/limit.js](/micro-index/source/constants/limit.js) | JavaScript | 28 | 3 | 1 | 32 |
| [micro-index/source/constants/map.js](/micro-index/source/constants/map.js) | JavaScript | 5 | 4 | 2 | 11 |
| [micro-index/source/middleware/promise.js](/micro-index/source/middleware/promise.js) | JavaScript | 69 | 8 | 18 | 95 |
| [micro-index/source/pages/Root.dev.js](/micro-index/source/pages/Root.dev.js) | JavaScript | 26 | 0 | 4 | 30 |
| [micro-index/source/pages/Root.js](/micro-index/source/pages/Root.js) | JavaScript | 5 | 0 | 1 | 6 |
| [micro-index/source/pages/Root.prod.js](/micro-index/source/pages/Root.prod.js) | JavaScript | 22 | 0 | 3 | 25 |
| [micro-index/source/pages/index/App.js](/micro-index/source/pages/index/App.js) | JavaScript | 17 | 0 | 6 | 23 |
| [micro-index/source/pages/index/App.less](/micro-index/source/pages/index/App.less) | Less | 14 | 0 | 2 | 16 |
| [micro-index/source/pages/index/actions/actionTypes.js](/micro-index/source/pages/index/actions/actionTypes.js) | JavaScript | 7 | 0 | 1 | 8 |
| [micro-index/source/pages/index/actions/index.js](/micro-index/source/pages/index/actions/index.js) | JavaScript | 111 | 0 | 3 | 114 |
| [micro-index/source/pages/index/components/AppBox/index.js](/micro-index/source/pages/index/components/AppBox/index.js) | JavaScript | 163 | 14 | 15 | 192 |
| [micro-index/source/pages/index/components/AppList/index.js](/micro-index/source/pages/index/components/AppList/index.js) | JavaScript | 94 | 2 | 9 | 105 |
| [micro-index/source/pages/index/components/Banner/index.js](/micro-index/source/pages/index/components/Banner/index.js) | JavaScript | 46 | 1 | 6 | 53 |
| [micro-index/source/pages/index/components/ErrorBoundary.js](/micro-index/source/pages/index/components/ErrorBoundary.js) | JavaScript | 14 | 1 | 5 | 20 |
| [micro-index/source/pages/index/components/Experience/index.less](/micro-index/source/pages/index/components/Experience/index.less) | Less | 35 | 0 | 7 | 42 |
| [micro-index/source/pages/index/components/Experience/index.tsx](/micro-index/source/pages/index/components/Experience/index.tsx) | TypeScript JSX | 65 | 0 | 11 | 76 |
| [micro-index/source/pages/index/components/FeatsIntro/index.less](/micro-index/source/pages/index/components/FeatsIntro/index.less) | Less | 37 | 0 | 6 | 43 |
| [micro-index/source/pages/index/components/FeatsIntro/index.tsx](/micro-index/source/pages/index/components/FeatsIntro/index.tsx) | TypeScript JSX | 58 | 0 | 12 | 70 |
| [micro-index/source/pages/index/components/Home/index.js](/micro-index/source/pages/index/components/Home/index.js) | JavaScript | 331 | 30 | 26 | 387 |
| [micro-index/source/pages/index/components/Home/index.less](/micro-index/source/pages/index/components/Home/index.less) | Less | 360 | 6 | 64 | 430 |
| [micro-index/source/pages/index/components/NotFound/doc.md](/micro-index/source/pages/index/components/NotFound/doc.md) | Markdown | 34 | 0 | 6 | 40 |
| [micro-index/source/pages/index/components/NotFound/index.js](/micro-index/source/pages/index/components/NotFound/index.js) | JavaScript | 17 | 0 | 4 | 21 |
| [micro-index/source/pages/index/components/NotFound/index.less](/micro-index/source/pages/index/components/NotFound/index.less) | Less | 28 | 0 | 1 | 29 |
| [micro-index/source/pages/index/components/Notice/index.js](/micro-index/source/pages/index/components/Notice/index.js) | JavaScript | 91 | 4 | 11 | 106 |
| [micro-index/source/pages/index/components/QuickStart/index.less](/micro-index/source/pages/index/components/QuickStart/index.less) | Less | 21 | 0 | 4 | 25 |
| [micro-index/source/pages/index/components/QuickStart/index.tsx](/micro-index/source/pages/index/components/QuickStart/index.tsx) | TypeScript JSX | 58 | 1 | 11 | 70 |
| [micro-index/source/pages/index/container/AppList/index.js](/micro-index/source/pages/index/container/AppList/index.js) | JavaScript | 13 | 0 | 4 | 17 |
| [micro-index/source/pages/index/container/Guide/components/GuideCard/index.jsx](/micro-index/source/pages/index/container/Guide/components/GuideCard/index.jsx) | JavaScript JSX | 114 | 2 | 4 | 120 |
| [micro-index/source/pages/index/container/Guide/components/GuideCard/index.less](/micro-index/source/pages/index/container/Guide/components/GuideCard/index.less) | Less | 83 | 0 | 1 | 84 |
| [micro-index/source/pages/index/container/Guide/components/ToolBox/index.jsx](/micro-index/source/pages/index/container/Guide/components/ToolBox/index.jsx) | JavaScript JSX | 60 | 0 | 6 | 66 |
| [micro-index/source/pages/index/container/Guide/components/ToolBox/index.less](/micro-index/source/pages/index/container/Guide/components/ToolBox/index.less) | Less | 92 | 0 | 1 | 93 |
| [micro-index/source/pages/index/container/Guide/config.js](/micro-index/source/pages/index/container/Guide/config.js) | JavaScript | 242 | 0 | 1 | 243 |
| [micro-index/source/pages/index/container/Guide/index.jsx](/micro-index/source/pages/index/container/Guide/index.jsx) | JavaScript JSX | 68 | 1 | 3 | 72 |
| [micro-index/source/pages/index/container/Guide/index.less](/micro-index/source/pages/index/container/Guide/index.less) | Less | 71 | 0 | 1 | 72 |
| [micro-index/source/pages/index/container/Home/index.js](/micro-index/source/pages/index/container/Home/index.js) | JavaScript | 13 | 0 | 4 | 17 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverCC/index.less](/micro-index/source/pages/index/container/TrialGuide/DiscoverCC/index.less) | Less | 3 | 0 | 1 | 4 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverCC/index.tsx](/micro-index/source/pages/index/container/TrialGuide/DiscoverCC/index.tsx) | TypeScript JSX | 36 | 0 | 6 | 42 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverOnline/index.less](/micro-index/source/pages/index/container/TrialGuide/DiscoverOnline/index.less) | Less | 3 | 0 | 1 | 4 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverOnline/index.tsx](/micro-index/source/pages/index/container/TrialGuide/DiscoverOnline/index.tsx) | TypeScript JSX | 36 | 0 | 6 | 42 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverQiyu/index.less](/micro-index/source/pages/index/container/TrialGuide/DiscoverQiyu/index.less) | Less | 3 | 0 | 1 | 4 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverQiyu/index.tsx](/micro-index/source/pages/index/container/TrialGuide/DiscoverQiyu/index.tsx) | TypeScript JSX | 34 | 0 | 7 | 41 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverRobot/index.less](/micro-index/source/pages/index/container/TrialGuide/DiscoverRobot/index.less) | Less | 3 | 0 | 1 | 4 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverRobot/index.tsx](/micro-index/source/pages/index/container/TrialGuide/DiscoverRobot/index.tsx) | TypeScript JSX | 36 | 0 | 6 | 42 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverWorksheet/index.less](/micro-index/source/pages/index/container/TrialGuide/DiscoverWorksheet/index.less) | Less | 3 | 0 | 1 | 4 |
| [micro-index/source/pages/index/container/TrialGuide/DiscoverWorksheet/index.tsx](/micro-index/source/pages/index/container/TrialGuide/DiscoverWorksheet/index.tsx) | TypeScript JSX | 35 | 0 | 6 | 41 |
| [micro-index/source/pages/index/container/TrialGuide/ExperienceCall/index.less](/micro-index/source/pages/index/container/TrialGuide/ExperienceCall/index.less) | Less | 3 | 0 | 1 | 4 |
| [micro-index/source/pages/index/container/TrialGuide/ExperienceCall/index.tsx](/micro-index/source/pages/index/container/TrialGuide/ExperienceCall/index.tsx) | TypeScript JSX | 35 | 0 | 5 | 40 |
| [micro-index/source/pages/index/container/TrialGuide/ExperienceRobot/index.less](/micro-index/source/pages/index/container/TrialGuide/ExperienceRobot/index.less) | Less | 36 | 0 | 7 | 43 |
| [micro-index/source/pages/index/container/TrialGuide/ExperienceRobot/index.tsx](/micro-index/source/pages/index/container/TrialGuide/ExperienceRobot/index.tsx) | TypeScript JSX | 83 | 0 | 11 | 94 |
| [micro-index/source/pages/index/container/TrialGuide/ExperienceSession/index.less](/micro-index/source/pages/index/container/TrialGuide/ExperienceSession/index.less) | Less | 3 | 0 | 1 | 4 |
| [micro-index/source/pages/index/container/TrialGuide/ExperienceSession/index.tsx](/micro-index/source/pages/index/container/TrialGuide/ExperienceSession/index.tsx) | TypeScript JSX | 47 | 0 | 7 | 54 |
| [micro-index/source/pages/index/container/TrialGuide/MoreCC/index.less](/micro-index/source/pages/index/container/TrialGuide/MoreCC/index.less) | Less | 4 | 0 | 1 | 5 |
| [micro-index/source/pages/index/container/TrialGuide/MoreCC/index.tsx](/micro-index/source/pages/index/container/TrialGuide/MoreCC/index.tsx) | TypeScript JSX | 68 | 0 | 8 | 76 |
| [micro-index/source/pages/index/container/TrialGuide/MoreOnline/index.less](/micro-index/source/pages/index/container/TrialGuide/MoreOnline/index.less) | Less | 4 | 0 | 1 | 5 |
| [micro-index/source/pages/index/container/TrialGuide/MoreOnline/index.tsx](/micro-index/source/pages/index/container/TrialGuide/MoreOnline/index.tsx) | TypeScript JSX | 59 | 0 | 8 | 67 |
| [micro-index/source/pages/index/container/TrialGuide/MoreRobot/index.less](/micro-index/source/pages/index/container/TrialGuide/MoreRobot/index.less) | Less | 4 | 0 | 1 | 5 |
| [micro-index/source/pages/index/container/TrialGuide/MoreRobot/index.tsx](/micro-index/source/pages/index/container/TrialGuide/MoreRobot/index.tsx) | TypeScript JSX | 59 | 0 | 8 | 67 |
| [micro-index/source/pages/index/container/TrialGuide/index.less](/micro-index/source/pages/index/container/TrialGuide/index.less) | Less | 52 | 1 | 9 | 62 |
| [micro-index/source/pages/index/container/TrialGuide/index.tsx](/micro-index/source/pages/index/container/TrialGuide/index.tsx) | TypeScript JSX | 385 | 9 | 25 | 419 |
| [micro-index/source/pages/index/entry.js](/micro-index/source/pages/index/entry.js) | JavaScript | 26 | 5 | 6 | 37 |
| [micro-index/source/pages/index/index.js](/micro-index/source/pages/index/index.js) | JavaScript | 5 | 0 | 2 | 7 |
| [micro-index/source/pages/index/qxy/components/VideoList/index.less](/micro-index/source/pages/index/qxy/components/VideoList/index.less) | Less | 70 | 0 | 10 | 80 |
| [micro-index/source/pages/index/qxy/components/VideoList/index.tsx](/micro-index/source/pages/index/qxy/components/VideoList/index.tsx) | TypeScript JSX | 43 | 0 | 6 | 49 |
| [micro-index/source/pages/index/qxy/components/VideoModal/index.less](/micro-index/source/pages/index/qxy/components/VideoModal/index.less) | Less | 54 | 1 | 7 | 62 |
| [micro-index/source/pages/index/qxy/components/VideoModal/index.tsx](/micro-index/source/pages/index/qxy/components/VideoModal/index.tsx) | TypeScript JSX | 42 | 0 | 7 | 49 |
| [micro-index/source/pages/index/qxy/data/course.json](/micro-index/source/pages/index/qxy/data/course.json) | JSON | 1,122 | 0 | 0 | 1,122 |
| [micro-index/source/pages/index/qxy/index.less](/micro-index/source/pages/index/qxy/index.less) | Less | 86 | 1 | 16 | 103 |
| [micro-index/source/pages/index/qxy/index.tsx](/micro-index/source/pages/index/qxy/index.tsx) | TypeScript JSX | 88 | 1 | 11 | 100 |
| [micro-index/source/pages/index/qxy/store/index.ts](/micro-index/source/pages/index/qxy/store/index.ts) | TypeScript | 46 | 0 | 6 | 52 |
| [micro-index/source/pages/index/reducers/initialState.js](/micro-index/source/pages/index/reducers/initialState.js) | JavaScript | 9 | 4 | 1 | 14 |
| [micro-index/source/pages/index/reducers/reducer.js](/micro-index/source/pages/index/reducers/reducer.js) | JavaScript | 51 | 0 | 9 | 60 |
| [micro-index/source/pages/index/reducers/rootReducer.js](/micro-index/source/pages/index/reducers/rootReducer.js) | JavaScript | 10 | 0 | 3 | 13 |
| [micro-index/source/pages/index/routes.js](/micro-index/source/pages/index/routes.js) | JavaScript | 46 | 1 | 4 | 51 |
| [micro-index/source/pages/index/services.js](/micro-index/source/pages/index/services.js) | JavaScript | 50 | 0 | 4 | 54 |
| [micro-index/source/pages/index/view.js](/micro-index/source/pages/index/view.js) | JavaScript | 13 | 0 | 4 | 17 |
| [micro-index/source/reducers/initialState.js](/micro-index/source/reducers/initialState.js) | JavaScript | 11 | 7 | 2 | 20 |
| [micro-index/source/reducers/reducer.js](/micro-index/source/reducers/reducer.js) | JavaScript | 12 | 2 | 2 | 16 |
| [micro-index/source/store/configureStore.dev.js](/micro-index/source/store/configureStore.dev.js) | JavaScript | 16 | 8 | 6 | 30 |
| [micro-index/source/store/configureStore.js](/micro-index/source/store/configureStore.js) | JavaScript | 5 | 0 | 1 | 6 |
| [micro-index/source/store/configureStore.prod.js](/micro-index/source/store/configureStore.prod.js) | JavaScript | 10 | 0 | 2 | 12 |
| [micro-index/source/typings/index.d.ts](/micro-index/source/typings/index.d.ts) | TypeScript | 7 | 0 | 1 | 8 |
| [micro-index/source/utils/DevTools.js](/micro-index/source/utils/DevTools.js) | JavaScript | 9 | 1 | 2 | 12 |
| [micro-index/source/utils/ajax.js](/micro-index/source/utils/ajax.js) | JavaScript | 124 | 27 | 8 | 159 |
| [micro-index/source/utils/cli.js](/micro-index/source/utils/cli.js) | JavaScript | 80 | 23 | 9 | 112 |
| [micro-index/source/utils/getWindowVar.js](/micro-index/source/utils/getWindowVar.js) | JavaScript | 90 | 39 | 20 | 149 |
| [micro-index/source/utils/iframeWrapper.js](/micro-index/source/utils/iframeWrapper.js) | JavaScript | 67 | 44 | 8 | 119 |
| [micro-index/source/utils/index.js](/micro-index/source/utils/index.js) | JavaScript | 31 | 6 | 2 | 39 |
| [micro-index/source/utils/publicPath.js](/micro-index/source/utils/publicPath.js) | JavaScript | 52 | 28 | 9 | 89 |
| [micro-index/source/utils/type2type.js](/micro-index/source/utils/type2type.js) | JavaScript | 26 | 21 | 7 | 54 |
| [micro-index/source/utils/webpackPublicPath.js](/micro-index/source/utils/webpackPublicPath.js) | JavaScript | 5 | 4 | 2 | 11 |
| [micro-index/source/vendor/js/lib/napm-web-min-1.1.6.js](/micro-index/source/vendor/js/lib/napm-web-min-1.1.6.js) | JavaScript | 1 | 0 | 0 | 1 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\.eslintrc.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5C.eslintrc.js) | JavaScript | -22 | 0 | -1 | -23 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\.gitlab-ci.yml](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5C.gitlab-ci.yml) | YAML | -2 | 0 | -1 | -3 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\.prettierrc.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5C.prettierrc.js) | JavaScript | -4 | 0 | 0 | -4 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\Dockerfile](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5CDockerfile) | Docker | -5 | 0 | -5 | -10 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\README.md](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5CREADME.md) | Markdown | -140 | 0 | -25 | -165 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\babel.config.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cbabel.config.js) | JavaScript | -40 | -1 | -4 | -45 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\buildScripts\\downloadFiles.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5CbuildScripts%5CdownloadFiles.js) | JavaScript | -76 | -17 | -9 | -102 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\buildScripts\\font\_158250\_54266uef21o.css](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5CbuildScripts%5Cfont_158250_54266uef21o.css) | CSS | -1,840 | 0 | -612 | -2,452 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\buildScripts\\font\_697017\_m9q3eurcmbi.svg](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5CbuildScripts%5Cfont_697017_m9q3eurcmbi.svg) | XML | -124 | -3 | -215 | -342 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\buildScripts\\stringReplace.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5CbuildScripts%5CstringReplace.js) | JavaScript | -121 | -28 | -11 | -160 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\d34025845c2a4b7084e13851e5deeca3\_master\_gray.md](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cd34025845c2a4b7084e13851e5deeca3_master_gray.md) | Markdown | -1 | 0 | 0 | -1 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\defaultOptions.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5CdefaultOptions.js) | JavaScript | -40 | -19 | -3 | -62 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\deploy.config.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cdeploy.config.js) | JavaScript | -123 | -12 | -9 | -144 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\docs\\README.md](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cdocs%5CREADME.md) | Markdown | -4 | 0 | -1 | -5 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\docs\\backend\\ysf\_first\_guide.sql](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cdocs%5Cbackend%5Cysf_first_guide.sql) | MS SQL | -11 | 0 | -1 | -12 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\misc\\ant-build-debug.xml](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cmisc%5Cant-build-debug.xml) | XML | -68 | -17 | -7 | -92 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\misc\\ant-build-online-gray.xml](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cmisc%5Cant-build-online-gray.xml) | XML | -76 | -17 | -7 | -100 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\misc\\ant-build-online.xml](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cmisc%5Cant-build-online.xml) | XML | -90 | 0 | -7 | -97 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\misc\\ant-build-release.xml](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cmisc%5Cant-build-release.xml) | XML | -76 | -17 | -7 | -100 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\misc\\ant-build-test.xml](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cmisc%5Cant-build-test.xml) | XML | -69 | -17 | -7 | -93 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\overmind\_build.xml](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Covermind_build.xml) | XML | -128 | -5 | -14 | -147 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\package-lock.json](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cpackage-lock.json) | JSON | -38,567 | 0 | -1 | -38,568 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\package.json](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cpackage.json) | JSON | -192 | 0 | -1 | -193 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\pom.xml](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cpom.xml) | XML | -450 | -9 | -17 | -476 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\postcss.config.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cpostcss.config.js) | JavaScript | -8 | -4 | -2 | -14 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\pp.project.json](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cpp.project.json) | JSON | -11 | 0 | 0 | -11 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\prettier.config.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cprettier.config.js) | JavaScript | -6 | -1 | -1 | -8 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\\_\_mock\_\_\\localStorage.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5C__mock__%5ClocalStorage.js) | JavaScript | -20 | 0 | -2 | -22 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\\_\_mock\_\_\\rAF.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5C__mock__%5CrAF.js) | JavaScript | -14 | -5 | -7 | -26 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\actions\\actionTypes.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cactions%5CactionTypes.js) | JavaScript | -1 | 0 | -1 | -2 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\actions\\actions.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cactions%5Cactions.js) | JavaScript | -7 | -2 | -2 | -11 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\app.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Capp.js) | JavaScript | -22 | -2 | -4 | -28 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\appRoutes.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5CappRoutes.js) | JavaScript | -5 | -24 | -3 | -32 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\assets\\css\\common\\color.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cassets%5Ccss%5Ccommon%5Ccolor.less) | Less | -15 | 0 | -6 | -21 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\assets\\css\\common\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cassets%5Ccss%5Ccommon%5Cindex.less) | Less | -4 | -1 | -1 | -6 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\assets\\css\\common\\main.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cassets%5Ccss%5Ccommon%5Cmain.less) | Less | -44 | -4 | -11 | -59 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\assets\\css\\common\\mixin.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cassets%5Ccss%5Ccommon%5Cmixin.less) | Less | -107 | -17 | -24 | -148 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\assets\\css\\common\\reset.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cassets%5Ccss%5Ccommon%5Creset.less) | Less | -313 | -8 | -4 | -325 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\assets\\css\\lib\\ppfish-theme-vars.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cassets%5Ccss%5Clib%5Cppfish-theme-vars.less) | Less | 0 | -1 | -1 | -2 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\config\\constants.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cconfig%5Cconstants.js) | JavaScript | -13 | -28 | -6 | -47 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\config\\dev.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cconfig%5Cdev.js) | JavaScript | -9 | -4 | -1 | -14 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\config\\envConfig.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cconfig%5CenvConfig.js) | JavaScript | -133 | -1 | -2 | -136 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\config\\index.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cconfig%5Cindex.js) | JavaScript | -39 | -3 | -3 | -45 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\config\\prod.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cconfig%5Cprod.js) | JavaScript | -8 | -3 | -1 | -12 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\constants\\default.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cconstants%5Cdefault.js) | JavaScript | 0 | 0 | -1 | -1 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\constants\\index.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cconstants%5Cindex.js) | JavaScript | -2 | -5 | -1 | -8 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\constants\\limit.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cconstants%5Climit.js) | JavaScript | -28 | -3 | -1 | -32 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\constants\\map.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cconstants%5Cmap.js) | JavaScript | -5 | -4 | -2 | -11 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\middleware\\promise.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cmiddleware%5Cpromise.js) | JavaScript | -69 | -8 | -18 | -95 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\Root.dev.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5CRoot.dev.js) | JavaScript | -26 | 0 | -4 | -30 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\Root.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5CRoot.js) | JavaScript | -5 | 0 | -1 | -6 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\Root.prod.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5CRoot.prod.js) | JavaScript | -22 | 0 | -3 | -25 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\App.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5CApp.js) | JavaScript | -17 | 0 | -6 | -23 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\App.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5CApp.less) | Less | -14 | 0 | -2 | -16 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\actions\\actionTypes.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Cactions%5CactionTypes.js) | JavaScript | -7 | 0 | -1 | -8 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\actions\\index.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Cactions%5Cindex.js) | JavaScript | -111 | 0 | -3 | -114 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\components\\AppBox\\index.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccomponents%5CAppBox%5Cindex.js) | JavaScript | -163 | -14 | -15 | -192 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\components\\AppList\\index.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccomponents%5CAppList%5Cindex.js) | JavaScript | -94 | -2 | -9 | -105 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\components\\Banner\\index.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccomponents%5CBanner%5Cindex.js) | JavaScript | -46 | -1 | -6 | -53 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\components\\ErrorBoundary.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccomponents%5CErrorBoundary.js) | JavaScript | -14 | -1 | -5 | -20 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\components\\Experience\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccomponents%5CExperience%5Cindex.less) | Less | -35 | 0 | -7 | -42 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\components\\Experience\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccomponents%5CExperience%5Cindex.tsx) | TypeScript JSX | -65 | 0 | -11 | -76 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\components\\FeatsIntro\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccomponents%5CFeatsIntro%5Cindex.less) | Less | -37 | 0 | -6 | -43 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\components\\FeatsIntro\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccomponents%5CFeatsIntro%5Cindex.tsx) | TypeScript JSX | -58 | 0 | -12 | -70 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\components\\Home\\index.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccomponents%5CHome%5Cindex.js) | JavaScript | -331 | -30 | -26 | -387 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\components\\Home\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccomponents%5CHome%5Cindex.less) | Less | -360 | -6 | -64 | -430 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\components\\NotFound\\doc.md](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccomponents%5CNotFound%5Cdoc.md) | Markdown | -34 | 0 | -6 | -40 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\components\\NotFound\\index.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccomponents%5CNotFound%5Cindex.js) | JavaScript | -17 | 0 | -4 | -21 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\components\\NotFound\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccomponents%5CNotFound%5Cindex.less) | Less | -28 | 0 | -1 | -29 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\components\\Notice\\index.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccomponents%5CNotice%5Cindex.js) | JavaScript | -91 | -4 | -11 | -106 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\components\\QuickStart\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccomponents%5CQuickStart%5Cindex.less) | Less | -21 | 0 | -4 | -25 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\components\\QuickStart\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccomponents%5CQuickStart%5Cindex.tsx) | TypeScript JSX | -58 | -1 | -11 | -70 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\AppList\\index.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CAppList%5Cindex.js) | JavaScript | -13 | 0 | -4 | -17 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\Guide\\components\\GuideCard\\index.jsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CGuide%5Ccomponents%5CGuideCard%5Cindex.jsx) | JavaScript JSX | -114 | -2 | -4 | -120 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\Guide\\components\\GuideCard\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CGuide%5Ccomponents%5CGuideCard%5Cindex.less) | Less | -83 | 0 | -1 | -84 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\Guide\\components\\ToolBox\\index.jsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CGuide%5Ccomponents%5CToolBox%5Cindex.jsx) | JavaScript JSX | -60 | 0 | -6 | -66 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\Guide\\components\\ToolBox\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CGuide%5Ccomponents%5CToolBox%5Cindex.less) | Less | -92 | 0 | -1 | -93 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\Guide\\config.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CGuide%5Cconfig.js) | JavaScript | -242 | 0 | -1 | -243 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\Guide\\index.jsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CGuide%5Cindex.jsx) | JavaScript JSX | -68 | -1 | -3 | -72 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\Guide\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CGuide%5Cindex.less) | Less | -71 | 0 | -1 | -72 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\Home\\index.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CHome%5Cindex.js) | JavaScript | -13 | 0 | -4 | -17 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\DiscoverCC\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CDiscoverCC%5Cindex.less) | Less | -3 | 0 | -1 | -4 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\DiscoverCC\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CDiscoverCC%5Cindex.tsx) | TypeScript JSX | -36 | 0 | -6 | -42 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\DiscoverOnline\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CDiscoverOnline%5Cindex.less) | Less | -3 | 0 | -1 | -4 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\DiscoverOnline\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CDiscoverOnline%5Cindex.tsx) | TypeScript JSX | -36 | 0 | -6 | -42 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\DiscoverQiyu\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CDiscoverQiyu%5Cindex.less) | Less | -3 | 0 | -1 | -4 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\DiscoverQiyu\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CDiscoverQiyu%5Cindex.tsx) | TypeScript JSX | -34 | 0 | -7 | -41 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\DiscoverRobot\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CDiscoverRobot%5Cindex.less) | Less | -3 | 0 | -1 | -4 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\DiscoverRobot\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CDiscoverRobot%5Cindex.tsx) | TypeScript JSX | -36 | 0 | -6 | -42 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\DiscoverWorksheet\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CDiscoverWorksheet%5Cindex.less) | Less | -3 | 0 | -1 | -4 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\DiscoverWorksheet\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CDiscoverWorksheet%5Cindex.tsx) | TypeScript JSX | -35 | 0 | -6 | -41 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\ExperienceCall\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CExperienceCall%5Cindex.less) | Less | -3 | 0 | -1 | -4 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\ExperienceCall\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CExperienceCall%5Cindex.tsx) | TypeScript JSX | -35 | 0 | -5 | -40 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\ExperienceRobot\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CExperienceRobot%5Cindex.less) | Less | -36 | 0 | -7 | -43 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\ExperienceRobot\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CExperienceRobot%5Cindex.tsx) | TypeScript JSX | -83 | 0 | -11 | -94 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\ExperienceSession\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CExperienceSession%5Cindex.less) | Less | -3 | 0 | -1 | -4 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\ExperienceSession\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CExperienceSession%5Cindex.tsx) | TypeScript JSX | -47 | 0 | -7 | -54 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\MoreCC\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CMoreCC%5Cindex.less) | Less | -4 | 0 | -1 | -5 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\MoreCC\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CMoreCC%5Cindex.tsx) | TypeScript JSX | -68 | 0 | -8 | -76 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\MoreOnline\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CMoreOnline%5Cindex.less) | Less | -4 | 0 | -1 | -5 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\MoreOnline\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CMoreOnline%5Cindex.tsx) | TypeScript JSX | -59 | 0 | -8 | -67 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\MoreRobot\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CMoreRobot%5Cindex.less) | Less | -4 | 0 | -1 | -5 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\MoreRobot\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5CMoreRobot%5Cindex.tsx) | TypeScript JSX | -59 | 0 | -8 | -67 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5Cindex.less) | Less | -52 | -1 | -9 | -62 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\container\\TrialGuide\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Ccontainer%5CTrialGuide%5Cindex.tsx) | TypeScript JSX | -385 | -9 | -25 | -419 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\entry.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Centry.js) | JavaScript | -26 | -5 | -6 | -37 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\index.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Cindex.js) | JavaScript | -5 | 0 | -2 | -7 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\qxy\\components\\VideoList\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Cqxy%5Ccomponents%5CVideoList%5Cindex.less) | Less | -70 | 0 | -10 | -80 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\qxy\\components\\VideoList\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Cqxy%5Ccomponents%5CVideoList%5Cindex.tsx) | TypeScript JSX | -43 | 0 | -6 | -49 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\qxy\\components\\VideoModal\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Cqxy%5Ccomponents%5CVideoModal%5Cindex.less) | Less | -54 | -1 | -7 | -62 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\qxy\\components\\VideoModal\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Cqxy%5Ccomponents%5CVideoModal%5Cindex.tsx) | TypeScript JSX | -42 | 0 | -7 | -49 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\qxy\\data\\course.json](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Cqxy%5Cdata%5Ccourse.json) | JSON | -1,122 | 0 | 0 | -1,122 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\qxy\\index.less](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Cqxy%5Cindex.less) | Less | -86 | -1 | -16 | -103 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\qxy\\index.tsx](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Cqxy%5Cindex.tsx) | TypeScript JSX | -88 | -1 | -11 | -100 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\qxy\\store\\index.ts](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Cqxy%5Cstore%5Cindex.ts) | TypeScript | -46 | 0 | -6 | -52 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\reducers\\initialState.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Creducers%5CinitialState.js) | JavaScript | -9 | -4 | -1 | -14 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\reducers\\reducer.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Creducers%5Creducer.js) | JavaScript | -51 | 0 | -9 | -60 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\reducers\\rootReducer.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Creducers%5CrootReducer.js) | JavaScript | -10 | 0 | -3 | -13 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\routes.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Croutes.js) | JavaScript | -46 | -1 | -4 | -51 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\services.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Cservices.js) | JavaScript | -50 | 0 | -4 | -54 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\pages\\index\\view.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cpages%5Cindex%5Cview.js) | JavaScript | -13 | 0 | -4 | -17 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\reducers\\initialState.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Creducers%5CinitialState.js) | JavaScript | -11 | -7 | -2 | -20 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\reducers\\reducer.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Creducers%5Creducer.js) | JavaScript | -12 | -2 | -2 | -16 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\store\\configureStore.dev.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cstore%5CconfigureStore.dev.js) | JavaScript | -16 | -8 | -6 | -30 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\store\\configureStore.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cstore%5CconfigureStore.js) | JavaScript | -5 | 0 | -1 | -6 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\store\\configureStore.prod.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cstore%5CconfigureStore.prod.js) | JavaScript | -10 | 0 | -2 | -12 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\typings\\index.d.ts](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Ctypings%5Cindex.d.ts) | TypeScript | -7 | 0 | -1 | -8 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\utils\\DevTools.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cutils%5CDevTools.js) | JavaScript | -9 | -1 | -2 | -12 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\utils\\ajax.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cutils%5Cajax.js) | JavaScript | -124 | -27 | -8 | -159 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\utils\\cli.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cutils%5Ccli.js) | JavaScript | -80 | -23 | -9 | -112 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\utils\\getWindowVar.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cutils%5CgetWindowVar.js) | JavaScript | -90 | -39 | -20 | -149 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\utils\\iframeWrapper.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cutils%5CiframeWrapper.js) | JavaScript | -67 | -44 | -8 | -119 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\utils\\index.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cutils%5Cindex.js) | JavaScript | -31 | -6 | -2 | -39 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\utils\\publicPath.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cutils%5CpublicPath.js) | JavaScript | -52 | -28 | -9 | -89 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\utils\\type2type.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cutils%5Ctype2type.js) | JavaScript | -26 | -21 | -7 | -54 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\utils\\webpackPublicPath.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cutils%5CwebpackPublicPath.js) | JavaScript | -5 | -4 | -2 | -11 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\source\\vendor\\js\\lib\\napm-web-min-1.1.6.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csource%5Cvendor%5Cjs%5Clib%5Cnapm-web-min-1.1.6.js) | JavaScript | -1 | 0 | 0 | -1 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\filters\\filter-debug-env.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cfilters%5Cfilter-debug-env.properties) | Java Properties | -6 | 0 | -1 | -7 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\filters\\filter-gray-env.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cfilters%5Cfilter-gray-env.properties) | Java Properties | -7 | 0 | -2 | -9 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\filters\\filter-gray-jd-env.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cfilters%5Cfilter-gray-jd-env.properties) | Java Properties | -7 | 0 | -1 | -8 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\filters\\filter-image-env.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cfilters%5Cfilter-image-env.properties) | Java Properties | -9 | 0 | -1 | -10 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\filters\\filter-online-env.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cfilters%5Cfilter-online-env.properties) | Java Properties | -5 | 0 | -1 | -6 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\filters\\filter-online-jd-env.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cfilters%5Cfilter-online-jd-env.properties) | Java Properties | -7 | 0 | -1 | -8 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\filters\\filter-online-sg-env.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cfilters%5Cfilter-online-sg-env.properties) | Java Properties | -7 | 0 | -1 | -8 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\filters\\filter-perftest-env.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cfilters%5Cfilter-perftest-env.properties) | Java Properties | -6 | 0 | -1 | -7 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\filters\\filter-release-env.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cfilters%5Cfilter-release-env.properties) | Java Properties | -6 | 0 | -1 | -7 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\filters\\filter-release-gray-env.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cfilters%5Cfilter-release-gray-env.properties) | Java Properties | -6 | 0 | -1 | -7 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\filters\\filter-release-gray-jd-env.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cfilters%5Cfilter-release-gray-jd-env.properties) | Java Properties | -5 | 0 | -1 | -6 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\filters\\filter-release-jd-env.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cfilters%5Cfilter-release-jd-env.properties) | Java Properties | -5 | 0 | -1 | -6 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\filters\\filter-testing-env.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cfilters%5Cfilter-testing-env.properties) | Java Properties | -6 | 0 | -1 | -7 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\device\\dao\\FirstGuideStatusDao.java](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cjava%5Ccom%5Cnetease%5Cysf%5Cdevice%5Cdao%5CFirstGuideStatusDao.java) | Java | -22 | 0 | -8 | -30 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\device\\model\\FirstGuideStatusRO.java](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cjava%5Ccom%5Cnetease%5Cysf%5Cdevice%5Cmodel%5CFirstGuideStatusRO.java) | Java | -35 | 0 | -14 | -49 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\MicroIndexMain.java](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cjava%5Ccom%5Cnetease%5Cysf%5Cmicro%5Cindex%5CMicroIndexMain.java) | Java | -40 | 0 | -4 | -44 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\cdn\\NosCdnUpload.java](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cjava%5Ccom%5Cnetease%5Cysf%5Cmicro%5Cindex%5Ccdn%5CNosCdnUpload.java) | Java | -167 | -5 | -43 | -215 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\config\\WebMvcConfig.java](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cjava%5Ccom%5Cnetease%5Cysf%5Cmicro%5Cindex%5Cconfig%5CWebMvcConfig.java) | Java | -42 | 0 | -9 | -51 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\controller\\PageFrameController.java](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cjava%5Ccom%5Cnetease%5Cysf%5Cmicro%5Cindex%5Ccontroller%5CPageFrameController.java) | Java | -228 | -12 | -20 | -260 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\controller\\PageLegacyController.java](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cjava%5Ccom%5Cnetease%5Cysf%5Cmicro%5Cindex%5Ccontroller%5CPageLegacyController.java) | Java | -28 | -3 | -5 | -36 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\instance\\InstanceController.java](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cjava%5Ccom%5Cnetease%5Cysf%5Cmicro%5Cindex%5Cinstance%5CInstanceController.java) | Java | -69 | -4 | -20 | -93 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\intercepter\\ForceHttpsInterceptor.java](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cjava%5Ccom%5Cnetease%5Cysf%5Cmicro%5Cindex%5Cintercepter%5CForceHttpsInterceptor.java) | Java | -70 | -3 | -9 | -82 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\intercepter\\OperateLoggingInterceptor.java](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cjava%5Ccom%5Cnetease%5Cysf%5Cmicro%5Cindex%5Cintercepter%5COperateLoggingInterceptor.java) | Java | -385 | -21 | -12 | -418 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\intercepter\\PageRightCheckInterceptor.java](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cjava%5Ccom%5Cnetease%5Cysf%5Cmicro%5Cindex%5Cintercepter%5CPageRightCheckInterceptor.java) | Java | -188 | -13 | -33 | -234 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\intercepter\\SessionCheckInterceptor.java](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cjava%5Ccom%5Cnetease%5Cysf%5Cmicro%5Cindex%5Cintercepter%5CSessionCheckInterceptor.java) | Java | -576 | -48 | -63 | -687 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\intercepter\\WebInterceptor.java](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cjava%5Ccom%5Cnetease%5Cysf%5Cmicro%5Cindex%5Cintercepter%5CWebInterceptor.java) | Java | -181 | -19 | -17 | -217 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\model\\AppInfo.java](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cjava%5Ccom%5Cnetease%5Cysf%5Cmicro%5Cindex%5Cmodel%5CAppInfo.java) | Java | -3 | 0 | -2 | -5 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\model\\BaseInfo.java](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cjava%5Ccom%5Cnetease%5Cysf%5Cmicro%5Cindex%5Cmodel%5CBaseInfo.java) | Java | -15 | 0 | -4 | -19 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\java\\com\\netease\\ysf\\micro\\index\\nos\\Nos.java](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cjava%5Ccom%5Cnetease%5Cysf%5Cmicro%5Cindex%5Cnos%5CNos.java) | Java | -78 | -9 | -14 | -101 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\resources\\application.yml](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cresources%5Capplication.yml) | YAML | -84 | 0 | -3 | -87 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\resources\\config\\eureka\_custom.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cresources%5Cconfig%5Ceureka_custom.properties) | Java Properties | -3 | 0 | -1 | -4 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\resources\\config\\microindex.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cresources%5Cconfig%5Cmicroindex.properties) | Java Properties | -18 | -1 | -1 | -20 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\resources\\config\\napm-agent.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cresources%5Cconfig%5Cnapm-agent.properties) | Java Properties | -3 | -5 | -3 | -11 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\resources\\config\\qiyu-bootstrap.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cresources%5Cconfig%5Cqiyu-bootstrap.properties) | Java Properties | -12 | -2 | -2 | -16 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\resources\\config\\res.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cresources%5Cconfig%5Cres.properties) | Java Properties | -1 | 0 | -1 | -2 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\resources\\config\\spring-dubbo-micro-index.xml](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cresources%5Cconfig%5Cspring-dubbo-micro-index.xml) | XML | -11 | 0 | -2 | -13 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\resources\\config\\version.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cresources%5Cconfig%5Cversion.properties) | Java Properties | -5 | 0 | 0 | -5 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\resources\\log4j2.xml](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cresources%5Clog4j2.xml) | XML | -101 | -14 | -10 | -125 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\resources\\mapper\\FirstGuideStatusMapper.xml](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cresources%5Cmapper%5CFirstGuideStatusMapper.xml) | XML | -28 | 0 | -7 | -35 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\resources\\sentry-javaagent-home\\javaMethod.xml](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cresources%5Csentry-javaagent-home%5CjavaMethod.xml) | XML | -3 | 0 | -1 | -4 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\resources\\sentry-javaagent-home\\sentry.properties](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cresources%5Csentry-javaagent-home%5Csentry.properties) | Java Properties | -2 | -20 | -11 | -33 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\resources\\sentry-javaagent-home\\url.xml](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cresources%5Csentry-javaagent-home%5Curl.xml) | XML | -3 | -3 | -1 | -7 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\src\\main\\resources\\static\\index.html](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Csrc%5Cmain%5Cresources%5Cstatic%5Cindex.html) | HTML | -10 | 0 | -1 | -11 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\SubmoduleReferencedStatisticsPlugin\\contents\\icons.svg](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5CSubmoduleReferencedStatisticsPlugin%5Ccontents%5Cicons.svg) | XML | -1 | 0 | 0 | -1 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\SubmoduleReferencedStatisticsPlugin\\contents\\jsonTree.css](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5CSubmoduleReferencedStatisticsPlugin%5Ccontents%5CjsonTree.css) | CSS | -90 | -15 | -7 | -112 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\SubmoduleReferencedStatisticsPlugin\\contents\\jsonTree.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5CSubmoduleReferencedStatisticsPlugin%5Ccontents%5CjsonTree.js) | JavaScript | -391 | -314 | -107 | -812 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\SubmoduleReferencedStatisticsPlugin\\contents\\recorder.css](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5CSubmoduleReferencedStatisticsPlugin%5Ccontents%5Crecorder.css) | CSS | -90 | -1 | -22 | -113 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\SubmoduleReferencedStatisticsPlugin\\contents\\recorder.html](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5CSubmoduleReferencedStatisticsPlugin%5Ccontents%5Crecorder.html) | HTML | -16 | -3 | -1 | -20 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\SubmoduleReferencedStatisticsPlugin\\contents\\recorder.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5CSubmoduleReferencedStatisticsPlugin%5Ccontents%5Crecorder.js) | JavaScript | -82 | -6 | -10 | -98 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\SubmoduleReferencedStatisticsPlugin\\contents\\recorderServer.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5CSubmoduleReferencedStatisticsPlugin%5Ccontents%5CrecorderServer.js) | JavaScript | -19 | 0 | -4 | -23 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\SubmoduleReferencedStatisticsPlugin\\index.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5CSubmoduleReferencedStatisticsPlugin%5Cindex.js) | JavaScript | -124 | -22 | -17 | -163 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\analyzeBundle.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5CanalyzeBundle.js) | JavaScript | -12 | 0 | -6 | -18 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\assetsTransformer.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5CassetsTransformer.js) | JavaScript | -6 | -7 | -2 | -15 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\build.dll.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5Cbuild.dll.js) | JavaScript | -84 | -13 | -16 | -113 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\build.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5Cbuild.js) | JavaScript | -72 | -11 | -14 | -97 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\chalkConfig.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5CchalkConfig.js) | JavaScript | -5 | -1 | -1 | -7 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\config.d.ts](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5Cconfig.d.ts) | TypeScript | -81 | -91 | -11 | -183 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\distServer.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5CdistServer.js) | JavaScript | -50 | -4 | -10 | -64 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\helps.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5Chelps.js) | JavaScript | -275 | -56 | -35 | -366 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\loader\\debug-loader.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5Cloader%5Cdebug-loader.js) | JavaScript | -12 | 0 | -5 | -17 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\loader\\freemarker-Readme.md](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5Cloader%5Cfreemarker-Readme.md) | Markdown | -60 | 0 | -29 | -89 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\loader\\ftl-loader-prod.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5Cloader%5Cftl-loader-prod.js) | JavaScript | -8 | 0 | -3 | -11 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\loader\\ftl-loader.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5Cloader%5Cftl-loader.js) | JavaScript | -51 | -3 | -10 | -64 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\mock.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5Cmock.js) | JavaScript | -38 | -5 | -5 | -48 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\neiPatch.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5CneiPatch.js) | JavaScript | -59 | -4 | -4 | -67 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\srcServer.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5CsrcServer.js) | JavaScript | -187 | -47 | -21 | -255 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\startMessage.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5CstartMessage.js) | JavaScript | -2 | -1 | -3 | -6 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tools\\testCi.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctools%5CtestCi.js) | JavaScript | -12 | -1 | -4 | -17 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\tsconfig.json](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Ctsconfig.json) | JSON with Comments | -40 | 0 | -1 | -41 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\webpack.config.dev.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cwebpack.config.dev.js) | JavaScript | -109 | -59 | -15 | -183 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\webpack.config.prod.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cwebpack.config.prod.js) | JavaScript | -125 | -71 | -15 | -211 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\webpack.merged.dev.dll.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cwebpack.merged.dev.dll.js) | JavaScript | -138 | -9 | -10 | -157 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\webpack.merged.dev.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cwebpack.merged.dev.js) | JavaScript | -229 | -20 | -24 | -273 |
| [e:\\WorkSpace\\other\\ragData\\micro-index\\webpack.merged.prod.js](/e:%5CWorkSpace%5Cother%5CragData%5Cmicro-index%5Cwebpack.merged.prod.js) | JavaScript | -254 | -27 | -23 | -304 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details