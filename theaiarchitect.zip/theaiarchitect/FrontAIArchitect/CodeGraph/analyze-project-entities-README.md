# 项目实体分析工具使用说明

## 📋 概述

`analyze-project-entities.js` 是一个强大的项目代码实体分析工具，基于 `entity-analyzer.js` 构建，专门用于分析 JavaScript/TypeScript 项目中的代码实体（函数、类、组件等）及其关系。

### 🎯 主要功能

- **多文件分析**：支持分析整个项目的所有 JavaScript/TypeScript 文件
- **实体识别**：识别函数、类、方法、React 组件、Redux 实体、NEJ 模块等
- **关系分析**：分析调用关系、继承关系、导入导出关系
- **返回值分析**：分析函数返回值类型和使用情况
- **框架支持**：专门支持 React、Redux、NEJ 框架的实体分析
- **Neo4j 集成**：将分析结果存储到图数据库，支持可视化查询
- **本地存储**：支持将结果保存为 JSON 文件

## 🚀 快速开始

### 1. 环境准备

确保已安装必要的依赖：

```bash
cd FrontAIArchitect/CodeGraph
npm install
```

### 2. 基本使用

#### 分析指定项目路径

```bash
# 分析指定路径的项目
node analyze-project-entities.js "C:\path\to\your\project"

# 分析当前目录
node analyze-project-entities.js "."
```

#### 保存结果到本地文件

```bash
# 分析项目并保存到本地文件
node analyze-project-entities.js "C:\path\to\your\project" --save-to-file
```

#### 仅保存到本地文件（不连接 Neo4j）

```bash
# 不连接 Neo4j，只保存到本地文件
node analyze-project-entities.js "C:\path\to\your\project" --save-to-file --no-neo4j
```

## 📖 完整命令行选项

### 基本语法

```bash
node analyze-project-entities.js <项目绝对路径> [选项]
```

### 可用选项

| 选项 | 说明 | 默认值 | 示例 |
|------|------|--------|------|
| `--neo4j-uri <uri>` | Neo4j 连接 URI | `bolt://localhost:7687` | `--neo4j-uri bolt://192.168.1.100:7687` |
| `--neo4j-user <user>` | Neo4j 用户名 | `neo4j` | `--neo4j-user admin` |
| `--neo4j-pass <pass>` | Neo4j 密码 | `fF5SQmjTvDgovryr9UAJxEGFIQHVfjP3WwmP3_Qz4Es` | `--neo4j-pass mypassword` |
| `--neo4j-db <database>` | Neo4j 数据库名 | `neo4j` | `--neo4j-db myproject` |
| `--output-dir <dir>` | 输出目录 | `./output` | `--output-dir ./results` |
| `--save-to-file` | 保存结果到本地文件 | `false` | `--save-to-file` |
| `--no-neo4j` | 不保存到 Neo4j 数据库 | `false` | `--no-neo4j` |
| `--verbose` | 详细输出模式 | `false` | `--verbose` |

### 使用示例

#### 示例 1：基本分析

```bash
# 分析 React 项目
node analyze-project-entities.js "C:\Users\username\projects\my-react-app"
```

#### 示例 2：自定义 Neo4j 配置

```bash
# 使用自定义 Neo4j 配置
node analyze-project-entities.js "C:\path\to\project" \
  --neo4j-uri "bolt://192.168.1.100:7687" \
  --neo4j-user "admin" \
  --neo4j-pass "mypassword" \
  --neo4j-db "myproject"
```

#### 示例 3：保存到本地文件

```bash
# 分析项目并保存到自定义目录
node analyze-project-entities.js "C:\path\to\project" \
  --save-to-file \
  --output-dir "./analysis-results"
```

#### 示例 4：详细输出模式

```bash
# 启用详细输出，查看每个文件的分析进度
node analyze-project-entities.js "C:\path\to\project" \
  --verbose \
  --save-to-file
```

#### 示例 5：仅本地分析（不连接数据库）

```bash
# 仅进行本地分析，不连接 Neo4j
node analyze-project-entities.js "C:\path\to\project" \
  --save-to-file \
  --no-neo4j \
  --output-dir "./local-results"
```

## 📊 输出结果

### 控制台输出

分析过程中会显示详细的进度信息：

```
🚀 项目实体分析工具启动
==================================================
✅ 项目路径验证通过: C:\path\to\project
📁 找到 150 个文件需要分析

🔍 开始分析 150 个文件...
==================================================
🔍 分析文件: src/components/App.js
✅ 分析完成: src/components/App.js
   - 实体数量: 5
   - 关系数量: 12
   - React 实体: 3
   - Redux 实体: 0
   - NEJ 实体: 0

🔄 合并分析结果...

📊 分析统计信息
==================================================
📁 文件统计:
   - 总文件数: 150
   - 成功分析: 148
   - 分析失败: 2

🏗️  实体统计:
   - 总实体数: 1250
   - 总关系数: 3200
   - 导入实体: 450
   - 导出实体: 380

⚛️  框架统计:
   - React 实体: 85
   - Redux 实体: 12
   - NEJ 实体: 0

🔄 返回值统计:
   - 总函数数: 800
   - 有返回值: 650
   - 返回值类型: { "object": 300, "identifier": 200, "literal": 150 }
   - 赋值使用: 400
   - 声明使用: 250
==================================================

🗄️  连接 Neo4j 数据库...
✅ Neo4j 连接成功
📊 创建数据库索引...
💾 存储 1250 个实体...
💾 存储 3200 个关系...
💾 存储返回值关系...
💾 存储导入导出关系...
✅ 所有数据已成功存储到 Neo4j

✅ 项目分析完成！

🌐 在 Neo4j Browser 中查看结果:
   1. 打开: http://localhost:7474
   2. 切换到数据库: :use neo4j
   3. 查看所有实体: MATCH (e:Entity) RETURN e LIMIT 100
   4. 查看调用关系: MATCH (a:Entity)-[r:CALLS]->(b:Entity) RETURN a, r, b LIMIT 50
```

### 本地文件输出

如果启用了 `--save-to-file` 选项，会在输出目录生成以下文件：

```
output/
├── analysis-2024-01-15T10-30-45-123Z-complete.json      # 完整分析结果
├── analysis-2024-01-15T10-30-45-123Z-entities.json      # 实体数据
├── analysis-2024-01-15T10-30-45-123Z-relations.json     # 关系数据
├── analysis-2024-01-15T10-30-45-123Z-framework-entities.json  # 框架实体
└── analysis-2024-01-15T10-30-45-123Z-stats.json         # 统计信息
```

## 🗄️ Neo4j 数据库查询

### 连接 Neo4j Browser

1. 打开浏览器访问：`http://localhost:7474`
2. 使用配置的用户名和密码登录
3. 切换到目标数据库：`:use neo4j`（或你指定的数据库名）

### 常用查询语句

#### 查看所有实体

```cypher
MATCH (e:Entity) 
RETURN e 
LIMIT 100
```

#### 查看调用关系

```cypher
MATCH (a:Entity)-[r:CALLS]->(b:Entity) 
RETURN a, r, b 
LIMIT 50
```

#### 查看 React 组件

```cypher
MATCH (e:Entity) 
WHERE e.framework = 'React' 
RETURN e
```

#### 查看 Redux 实体

```cypher
MATCH (e:Entity) 
WHERE e.framework = 'Redux' 
RETURN e
```

#### 查看函数返回值关系

```cypher
MATCH (a:Entity)-[r:RETURNS]->(b:Entity) 
RETURN a, r, b
```

#### 查看文件依赖关系

```cypher
MATCH (f1:File)-[r:IMPORTS_FROM]->(f2:File) 
RETURN f1, r, f2
```

#### 统计信息查询

```cypher
// 按类型统计实体
MATCH (e:Entity) 
RETURN e.type as Type, count(e) as Count 
ORDER BY Count DESC

// 按框架统计实体
MATCH (e:Entity) 
WHERE e.framework IS NOT NULL
RETURN e.framework as Framework, count(e) as Count 
ORDER BY Count DESC

// 查看最被调用的函数
MATCH (a:Entity)-[:CALLS]->(b:Entity) 
RETURN b.name as Function, count(a) as CallCount 
ORDER BY CallCount DESC 
LIMIT 20
```

## 🔧 配置说明

### 支持的文件类型

- `.js` - JavaScript 文件
- `.jsx` - React JSX 文件
- `.ts` - TypeScript 文件
- `.tsx` - TypeScript React 文件

### 自动排除的目录

- `node_modules/` - npm 包
- `dist/` - 构建输出
- `build/` - 构建输出
- `.git/` - Git 仓库
- `coverage/` - 测试覆盖率
- `.next/` - Next.js 构建
- `.nuxt/` - Nuxt.js 构建
- `out/` - 输出目录
- `target/` - 目标目录
- `.cache/` - 缓存目录
- `.parcel-cache/` - Parcel 缓存

### Neo4j 默认配置

```javascript
{
  uri: 'bolt://localhost:7687',
  user: 'neo4j',
  password: 'fF5SQmjTvDgovryr9UAJxEGFIQHVfjP3WwmP3_Qz4Es',
  database: 'neo4j'
}
```

## 🎯 使用场景

### 1. 代码重构分析

```bash
# 分析项目结构，识别重构机会
node analyze-project-entities.js "C:\path\to\legacy-project" --save-to-file --verbose
```

### 2. 依赖关系分析

```bash
# 分析模块间的依赖关系
node analyze-project-entities.js "C:\path\to\project" --save-to-file
```

### 3. 框架迁移分析

```bash
# 分析现有代码中的框架使用情况
node analyze-project-entities.js "C:\path\to\project" --verbose
```

### 4. 代码质量评估

```bash
# 分析函数复杂度和返回值使用情况
node analyze-project-entities.js "C:\path\to\project" --save-to-file
```

## ⚠️ 注意事项

### 1. 性能考虑

- **大型项目**：对于包含数千个文件的项目，分析可能需要较长时间
- **内存使用**：分析过程中会占用较多内存，建议确保有足够的内存空间
- **并发限制**：工具会并发分析多个文件，但会控制并发数量以避免系统过载

### 2. 数据库要求

- **Neo4j 版本**：建议使用 Neo4j 4.x 或更高版本
- **数据库权限**：确保 Neo4j 用户有创建节点、关系和索引的权限
- **网络连接**：确保能够连接到 Neo4j 数据库

### 3. 文件系统

- **路径格式**：Windows 系统使用反斜杠 `\`，Linux/Mac 使用正斜杠 `/`
- **权限要求**：确保对项目目录有读取权限
- **磁盘空间**：确保有足够的磁盘空间存储输出文件

### 4. 错误处理

- **解析错误**：某些复杂的代码结构可能无法完全解析，工具会跳过这些文件并继续分析
- **网络错误**：如果 Neo4j 连接失败，工具会显示错误信息并退出
- **文件错误**：如果某个文件无法读取，工具会跳过该文件并继续分析其他文件

## 🐛 故障排除

### 常见问题

#### 1. Neo4j 连接失败

**错误信息**：`❌ Neo4j 操作失败: Connection refused`

**解决方案**：
- 确保 Neo4j 数据库正在运行
- 检查连接 URI 是否正确
- 验证用户名和密码是否正确
- 检查防火墙设置

#### 2. Neo4j 序列化错误

**错误信息**：`Neo4jError: Property values can only be of primitive types or arrays thereof. Encountered: Map{...}`

**解决方案**：
- 这个错误已经在新版本中修复
- 工具会自动将复杂对象序列化为 JSON 字符串
- 如果仍然遇到此错误，请运行测试：`npm run test-neo4j`

#### 3. 文件路径为空错误

**错误信息**：`Cannot merge the following node because of null property value for 'path': (:File {path: null})`

**解决方案**：
- 这个错误已经在新版本中修复
- 工具会自动为没有文件路径的实体设置默认值 'unknown'
- 如果仍然遇到此错误，请运行测试：`npm run test-neo4j`

#### 2. 没有找到可分析的文件

**错误信息**：`⚠️ 警告: 没有找到可分析的文件`

**解决方案**：
- 检查项目路径是否正确
- 确认项目包含 JavaScript/TypeScript 文件
- 检查文件是否在排除目录中

#### 3. 内存不足

**错误信息**：`JavaScript heap out of memory`

**解决方案**：
- 增加 Node.js 内存限制：`node --max-old-space-size=4096 analyze-project-entities.js ...`
- 分批分析项目（先分析部分目录）
- 关闭其他占用内存的程序

#### 4. 权限错误

**错误信息**：`EACCES: permission denied`

**解决方案**：
- 检查文件和目录的读取权限
- 以管理员身份运行命令（Windows）
- 使用 `sudo` 运行命令（Linux/Mac）

## 📞 技术支持

如果遇到问题，请检查：

1. **依赖安装**：确保所有 npm 依赖已正确安装
2. **版本兼容性**：检查 Node.js 版本（建议 14.x 或更高）
3. **配置文件**：检查 Neo4j 配置是否正确
4. **日志信息**：查看详细的错误日志信息

## 🔄 更新日志

### v1.0.0
- 初始版本发布
- 支持基本的项目实体分析
- 集成 Neo4j 数据库存储
- 支持本地文件输出
- 支持多框架实体识别

---

**注意**：此工具仅用于代码分析目的，不会修改任何源代码文件。分析结果仅供参考，请根据实际项目情况做出决策。
