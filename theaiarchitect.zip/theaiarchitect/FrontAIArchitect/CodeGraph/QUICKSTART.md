# 🚀 快速开始指南

## 📋 概述

这个快速开始指南将帮助你在 5 分钟内开始使用项目实体分析工具。

## ⚡ 5分钟快速开始

### 1. 环境准备 (1分钟)

```bash
# 进入项目目录
cd FrontAIArchitect/CodeGraph

# 安装依赖
npm install
```

### 2. 基本使用 (2分钟)

#### 分析当前目录项目
```bash
# 最简单的方式：分析当前目录
node analyze-project-entities.js "."
```

#### 分析指定路径项目
```bash
# 分析指定路径的项目
node analyze-project-entities.js "C:\path\to\your\project"
```

### 3. 查看结果 (2分钟)

#### 方式一：查看控制台输出
分析完成后，控制台会显示详细的统计信息：
- 文件统计
- 实体统计  
- 框架统计
- 返回值统计

#### 方式二：在 Neo4j Browser 中查看
1. 打开浏览器访问：`http://localhost:7474`
2. 登录 Neo4j（默认用户名：neo4j，密码：fF5SQmjTvDgovryr9UAJxEGFIQHVfjP3WwmP3_Qz4Es）
3. 运行查询：`MATCH (e:Entity) RETURN e LIMIT 100`

## 🎯 常用命令

### 基本命令

```bash
# 分析项目并保存到本地文件
node analyze-project-entities.js "C:\path\to\project" --save-to-file

# 仅本地分析（不连接 Neo4j）
node analyze-project-entities.js "C:\path\to\project" --save-to-file --no-neo4j

# 详细输出模式
node analyze-project-entities.js "C:\path\to\project" --verbose
```

### 使用 npm 脚本

```bash
# 查看使用示例
npm run examples

# 查看帮助信息
npm run help

# 分析项目（需要提供路径参数）
npm run analyze-project "C:\path\to\project"

# 测试 Neo4j 连接和序列化
npm run test-neo4j
```

## 📊 输出文件说明

如果使用 `--save-to-file` 选项，会在 `output/` 目录生成以下文件：

- `analysis-{timestamp}-complete.json` - 完整分析结果
- `analysis-{timestamp}-entities.json` - 实体数据
- `analysis-{timestamp}-relations.json` - 关系数据
- `analysis-{timestamp}-framework-entities.json` - 框架实体
- `analysis-{timestamp}-stats.json` - 统计信息

## 🔍 常用 Neo4j 查询

### 查看所有实体
```cypher
MATCH (e:Entity) RETURN e LIMIT 100
```

### 查看调用关系
```cypher
MATCH (a:Entity)-[r:CALLS]->(b:Entity) RETURN a, r, b LIMIT 50
```

### 查看 React 组件
```cypher
MATCH (e:Entity) WHERE e.framework = 'React' RETURN e
```

### 查看最被调用的函数
```cypher
MATCH (a:Entity)-[:CALLS]->(b:Entity) 
RETURN b.name as Function, count(a) as CallCount 
ORDER BY CallCount DESC LIMIT 20
```

## ⚠️ 常见问题

### Q: Neo4j 连接失败怎么办？
A: 确保 Neo4j 数据库正在运行，或者使用 `--no-neo4j` 选项进行本地分析。

### Q: 没有找到可分析的文件？
A: 检查项目路径是否正确，确认项目包含 `.js`、`.jsx`、`.ts`、`.tsx` 文件。

### Q: 分析速度很慢？
A: 大型项目分析需要时间，可以使用 `--verbose` 查看进度。

### Q: 内存不足？
A: 使用 `node --max-old-space-size=4096 analyze-project-entities.js ...` 增加内存限制。

## 🎯 下一步

- 📖 阅读完整文档：`analyze-project-entities-README.md`
- 🔧 查看使用示例：`npm run examples`
- 🗄️ 学习 Neo4j 查询：查看文档中的查询示例
- 🚀 开始分析你的项目！

---

**提示**：如果遇到问题，请查看完整文档中的故障排除部分。
