const fs = require('fs');
const path = require('path');
const parser = require('@babel/parser');
const traverse = require('@babel/traverse').default;
const neo4j = require('neo4j-driver');

/**
 * 代码实体分析器类
 * 用于分析代码文件中的实体(函数、类等)及其关系
 * 支持React、Redux、NEJ框架的实体分析
 * 支持百万级项目的调用链路分析
 */
class EntityAnalyzer {
  constructor() {
    // 存储发现的实体
    this.entities = new Map();// 使用Map这个数据结构的原因是为了节省查找的时间复杂度
    // 存储实体间的关系
    this.relations = new Map();
    // 当前正在分析的实体栈
    this.entityStack = [];
    // 框架特定的实体映射
    this.frameworkEntities = {
      react: new Map(),
      redux: new Map(),
      nej: new Map()
    };
    // 导入的实体映射（用于跨文件调用分析）
    this.importedEntities = new Map();
    // 导出的实体映射
    this.exportedEntities = new Map();
    // 当前分析的文件路径
    this.currentFilePath = null;
  }

  /**
   * 检测React组件特性（Hook和JSX）
   * @param {object} path - AST路径
   * @param {object} entity - 实体对象
   * @returns {object} 检测结果
   */
  detectReactComponentFeatures(path, entity) {
    let hasHooks = false;
    let hooksList = [];
    let hasJSX = false;
    let hasReduxCalls = false;
    
    path.traverse({
      CallExpression: (p) => {
        this.handleCallExpression(p, this.currentFilePath);
        
        // 检测React Hooks
        const hookInfo = this.detectHookUsage(p);
        if (hookInfo) {
          hasHooks = true;
          hooksList.push(hookInfo);
          entity.framework = 'React';
          entity.isReactComponent = true;
          entity.hooks = entity.hooks || [];
          entity.hooks.push(hookInfo);
        }
        
        // 检测Redux相关调用
        const reduxInfo = this.detectReduxActionCall(p);
        if (reduxInfo) {
          hasReduxCalls = true;
          entity.reduxCalls = entity.reduxCalls || [];
          entity.reduxCalls.push(reduxInfo);
        }
      },
      JSXElement: (p) => {
        hasJSX = true;
        entity.framework = 'React';
        entity.isReactComponent = true;
      }
    });
    
    return { hasHooks, hooksList, hasJSX, hasReduxCalls };
  }

  /**
   * 创建框架实体
   * @param {string} id - 实体ID
   * @param {string} type - 实体类型
   * @param {string} name - 实体名称
   * @param {string} framework - 框架名称
   * @param {object} loc - 位置信息
   * @param {object} extraProps - 额外属性
   * @returns {object} 实体对象
   */
  createFrameworkEntity(id, type, name, framework, loc, extraProps = {}) {
    const entity = {
      id,
      type,
      name,
      filePath: this.currentFilePath || 'unknown',
      loc: this.formatLocation(loc),
      framework,
      ...extraProps
    };
    
    // 添加到框架特定映射
    this.frameworkEntities[framework.toLowerCase()].set(entity.id, entity);
    this.entities.set(entity.id, entity);
    
    return entity;
  }

  /**
   * 检测导入的框架类型
   * @param {string} source - 导入源
   * @returns {string|null} 框架名称
   */
  detectImportFramework(source) {
    if (source === 'react' || source.includes('react')) {
      return 'React';
    } else if (source.includes('redux') || source.includes('@reduxjs/toolkit')) {
      return 'Redux';
    } else if (source.includes('nej') || source.includes('pro')) {
      return 'NEJ';
    }
    return null;
  }

  /**
   * 分析AST,提取实体和关系
   * @param {string} filePath - 文件路径
   * @param {object} ast - 解析后的AST
   * @returns {{entities: Array, relations: Array}} 分析结果
   */
  analyze(filePath, ast) {
    this.currentFilePath = filePath;
    
    traverse(ast, {
      // 分析函数定义
      FunctionDeclaration: (path) => {
        const entity = this.createFunctionEntity(path, filePath);
        this.entities.set(entity.id, entity);
        this.entityStack.push(entity);
        
        // 使用统一的React组件特性检测
        const { hasHooks, hooksList, hasJSX, hasReduxCalls } = this.detectReactComponentFeatures(path, entity);
        
        // 更新实体信息
        if (hasHooks) {
          entity.hasHooks = true;
          entity.hookCount = hooksList.length;
        }
        if (hasJSX) {
          entity.hasJSX = true;
        }
        if (hasReduxCalls) {
          entity.hasReduxCalls = true;
        }
        
        this.entityStack.pop();
      },

      // 分析类定义
      ClassDeclaration: (path) => {
        const entity = this.createClassEntity(path, filePath);
        this.entities.set(entity.id, entity);
        this.entityStack.push(entity);
        path.traverse({
          ClassMethod: (p) => {
            const methodEntity = this.createMethodEntity(p, entity, filePath);
            if (entity.type === 'ClassDeclaration' && entity.framework === 'React') {
              methodEntity.framework = 'React';
            }
            this.entities.set(methodEntity.id, methodEntity);
            this.addRelation(entity.id, methodEntity.id, 'HAS_METHOD');
            
            // 将方法实体添加到栈中，以便记录内部调用关系
            this.entityStack.push(methodEntity);
            p.traverse({
              CallExpression: (callPath) => this.handleCallExpression(callPath, filePath)
            });
            this.entityStack.pop();
          }
        });
        this.entityStack.pop();
      },

      // 分析变量声明
      VariableDeclaration: (path) => {
        // 检查是否是导出的变量声明
        const isExported = path.parentPath && path.parentPath.node.type === 'ExportNamedDeclaration';
        
        path.node.declarations.forEach(decl => {
          if (decl.init && decl.init.type === 'ArrowFunctionExpression') {
            const entity = this.createArrowFunctionEntity(path, decl, filePath);
            if (isExported) {
              entity.isExported = true;
              this.exportedEntities.set(entity.name, entity);
            }
            this.entities.set(entity.id, entity);
            
            // 将实体添加到栈中，以便记录内部调用关系
            this.entityStack.push(entity);
            
            // 使用统一的React组件特性检测
            const { hasHooks, hooksList, hasJSX, hasReduxCalls } = this.detectReactComponentFeatures(path, entity);
            
            // 更新实体信息
            if (hasHooks) {
              entity.hasHooks = true;
              entity.hookCount = hooksList.length;
            }
            if (hasJSX) {
              entity.hasJSX = true;
            }
            if (hasReduxCalls) {
              entity.hasReduxCalls = true;
            }
            
            this.entityStack.pop();
          } else if (decl.init && decl.init.type === 'FunctionExpression') {
            const entity = this.createFunctionExpressionEntity(path, decl, filePath);
            if (isExported) {
              entity.isExported = true;
              this.exportedEntities.set(entity.name, entity);
            }
            this.entities.set(entity.id, entity);
            
            // 将实体添加到栈中，以便记录内部调用关系
            this.entityStack.push(entity);
            
            // 使用统一的React组件特性检测
            const { hasHooks, hooksList, hasJSX, hasReduxCalls } = this.detectReactComponentFeatures(path, entity);
            
            // 更新实体信息
            if (hasHooks) {
              entity.hasHooks = true;
              entity.hookCount = hooksList.length;
            }
            if (hasJSX) {
              entity.hasJSX = true;
            }
            if (hasReduxCalls) {
              entity.hasReduxCalls = true;
            }
            
            this.entityStack.pop();
          } else {
            // 处理普通变量声明（非函数类型）
            const entity = this.createVariableEntity(path, decl, filePath);
            if (isExported) {
              entity.isExported = true;
              this.exportedEntities.set(entity.name, entity);
            }
            this.entities.set(entity.id, entity);
            
            // 分析变量初始化值中的调用关系
            if (decl.init) {
              this.entityStack.push(entity);
              this.analyzeVariableInitializer(decl.init, entity, filePath);
              this.entityStack.pop();
            }
          }
        });
      },

      // 分析React组件
      CallExpression: (path) => {
        this.analyzeReactComponent(path);
        this.analyzeReduxEntity(path);
        this.analyzeNEJEntity(path);
        this.analyzeIIFE(path, filePath);
      },

      // 分析JSX元素
      JSXElement: (path) => {
        this.analyzeJSXElement(path);
      },

      // 分析导入语句
      ImportDeclaration: (path) => {
        this.analyzeImportStatement(path, filePath);
      },

      // 分析导出语句
      ExportNamedDeclaration: (path) => {
        this.analyzeExportStatement(path, filePath);
      },

      // 分析对象属性
      ObjectProperty: (path) => {
        this.analyzeReduxAction(path);
        this.analyzeReduxReducer(path);
        this.analyzeObjectMethod(path, filePath);
      },

      // 分析返回语句
      ReturnStatement: (path) => {
        this.analyzeReturnStatement(path, filePath);
      },

      // 分析赋值表达式（可能涉及返回值的使用）
      AssignmentExpression: (path) => {
        this.analyzeAssignmentExpression(path, filePath);
      },

      // 分析变量声明（可能涉及返回值的使用）
      VariableDeclarator: (path) => {
        this.analyzeVariableDeclarator(path, filePath);
      }
    });

    return {
      entities: Array.from(this.entities.values()),
      relations: Array.from(this.relations.values()),
      frameworkEntities: {
        react: Array.from(this.frameworkEntities.react.values()),
        redux: Array.from(this.frameworkEntities.redux.values()),
        nej: Array.from(this.frameworkEntities.nej.values())
      },
      importedEntities: Array.from(this.importedEntities.values()),
      exportedEntities: Array.from(this.exportedEntities.values()),
      returnValueStats: this.getReturnValueStats(),
      astTypeStats: this.getASTTypeStats()
    };
  }

  /**
   * 分析React组件
   * @param {object} path - AST路径
   */
  analyzeReactComponent(path) {
    const node = path.node;
    
    // 检测React组件创建 (函数组件)
    // 检查函数是否返回JSX，或者是否使用了React Hooks
    if (path.parentPath && path.parentPath.node.type === 'ReturnStatement' && path.node.type === 'JSXElement') {
      const currentEntity = this.entityStack[this.entityStack.length - 1];
      if (currentEntity && currentEntity.type === 'FunctionDeclaration') {
        currentEntity.framework = 'React';
        currentEntity.isReactComponent = true;
      }
    }

    // 检查是否是 React.createElement 调用
    if (node.callee && node.callee.object && node.callee.object.name === 'React' && node.callee.property && node.callee.property.name === 'createElement') {
      const componentName = node.arguments[0]?.name || node.arguments[0]?.value;
      if (componentName) {
        this.createFrameworkEntity(
          `react_function_component_${componentName}`,
          'CallExpression',
          componentName,
          'React',
          node.loc,
          { isReactComponent: true }
        );
      }
    }

    // 检测React组件创建 (类组件)
    if (path.node.type === 'ClassDeclaration' && path.node.superClass && (path.node.superClass.name === 'Component' || (path.node.superClass.property && path.node.superClass.property.name === 'Component'))) {
      const componentName = path.node.id.name;
      if (componentName) {
        this.createFrameworkEntity(
          `react_class_component_${componentName}`,
          'ClassDeclaration',
          componentName,
          'React',
          path.node.loc,
          { isReactComponent: true }
        );
      }
    }

    // 检测函数组件 (FunctionDeclaration) - 复用已创建的实体
    if (path.node.type === 'FunctionDeclaration') {
      const functionName = path.node.id?.name;
      if (functionName) {
        // 查找已创建的实体
        const entityId = `${this.currentFilePath}:${path.node.loc.start.line}:${path.node.loc.start.column}:${functionName}`;
        const existingEntity = this.entities.get(entityId);
        
        if (existingEntity) {
          // 检查函数体是否包含JSX元素
          let hasJSX = false;
          path.traverse({
            JSXElement: () => {
              hasJSX = true;
              path.stop(); // 找到一个即可停止遍历
            }
          });

          // 使用新的Hook检测逻辑
          let hasHooks = false;
          let hooksList = [];
          path.traverse({
            CallExpression: (p) => {
              const hookInfo = this.detectHookUsage(p);
              if (hookInfo) {
                hasHooks = true;
                hooksList.push(hookInfo);
              }
            }
          });

          // 更新已存在的实体为React组件
          if (hasJSX || hasHooks) {
            existingEntity.framework = 'React';
            existingEntity.isReactComponent = true;
            existingEntity.hasJSX = hasJSX;
            existingEntity.hasHooks = hasHooks;
            existingEntity.hooks = hooksList;
            existingEntity.hookCount = hooksList.length;
            
            // 同时添加到React框架实体映射中
            this.frameworkEntities.react.set(entityId, existingEntity);
          }
        }
      }
    }

    // 保留原有的简单Hook检测逻辑作为后备
    // 检测函数组件
    if (node.callee && node.callee.name === 'useState') {
      const currentEntity = this.entityStack[this.entityStack.length - 1];
      if (currentEntity) {
        currentEntity.hasState = true;
        currentEntity.framework = 'React';
        currentEntity.isReactComponent = true;
      }
    }

    // 检测useEffect
    if (node.callee && node.callee.name === 'useEffect') {
      const currentEntity = this.entityStack[this.entityStack.length - 1];
      if (currentEntity) {
        currentEntity.hasEffects = true;
      }
    }
  }

  /**
   * 分析JSX元素
   * @param {object} path - AST路径
   */
  analyzeJSXElement(path) {
    const node = path.node;
    const openingElement = node.openingElement;
    
    if (openingElement.name && openingElement.name.name) {
      const componentName = openingElement.name.name;
      this.createFrameworkEntity(
        `jsx_element_${componentName}`,
        'JSXElement',
        componentName,
        'React',
        node.loc
      );
    }
  }

  /**
   * 分析Redux实体
   * @param {object} path - AST路径
   */
  analyzeReduxEntity(path) {
    const node = path.node;
    
    // 检测Redux store创建
    if (node.callee && node.callee.name === 'createStore') {
      this.createFrameworkEntity(
        `redux_store_${Date.now()}`,
        'CallExpression',
        'Store',
        'Redux',
        node.loc
      );
    }

    // 检测Redux Toolkit
    if (node.callee && node.callee.name === 'configureStore') {
      this.createFrameworkEntity(
        `redux_toolkit_store_${Date.now()}`,
        'CallExpression',
        'ToolkitStore',
        'Redux',
        node.loc
      );
    }

    // 检测createSlice
    if (node.callee && node.callee.name === 'createSlice') {
      const sliceName = node.arguments[0]?.properties?.find(p => p.key.name === 'name')?.value?.value;
      if (sliceName) {
        this.createFrameworkEntity(
          `redux_slice_${sliceName}`,
          'CallExpression',
          sliceName,
          'Redux',
          node.loc
        );
      }
    }
  }

  /**
   * 分析Redux Action
   * @param {object} path - AST路径
   */
  analyzeReduxAction(path) {
    const node = path.node;
    
    // 检测action creator
    if (node.key && node.key.name === 'actions') {
      const currentEntity = this.entityStack[this.entityStack.length - 1];
      if (currentEntity && currentEntity.framework === 'Redux') {
        currentEntity.hasActions = true;
      }
    }

    // 检测reducer
    if (node.key && node.key.name === 'reducer') {
      const currentEntity = this.entityStack[this.entityStack.length - 1];
      if (currentEntity && currentEntity.framework === 'Redux') {
        currentEntity.hasReducer = true;
      }
    }
  }

  /**
   * 检测Hook使用
   * @param {object} path - CallExpression AST路径
   * @returns {object|null} Hook信息或null
   */
  detectHookUsage(path) {
    const node = path.node;
    if (!node.callee || node.callee.type !== 'Identifier') {
      return null;
    }
    
    const calleName = node.callee.name;
    
    // React内置Hooks
    const builtinHooks = {
      'useState': { type: 'state', category: 'useState' },
      'useEffect': { type: 'effect', category: 'useEffect' },
      'useContext': { type: 'context', category: 'useContext' },
      'useReducer': { type: 'state', category: 'useReducer' },
      'useCallback': { type: 'optimization', category: 'useCallback' },
      'useMemo': { type: 'optimization', category: 'useMemo' },
      'useRef': { type: 'ref', category: 'useRef' },
      'useImperativeHandle': { type: 'advanced', category: 'useImperativeHandle' },
      'useLayoutEffect': { type: 'effect', category: 'useLayoutEffect' },
      'useDebugValue': { type: 'debug', category: 'useDebugValue' },
      'useId': { type: 'utility', category: 'useId' },
      'useDeferredValue': { type: 'concurrent', category: 'useDeferredValue' },
      'useTransition': { type: 'concurrent', category: 'useTransition' },
      'useSyncExternalStore': { type: 'external', category: 'useSyncExternalStore' },
      'useInsertionEffect': { type: 'effect', category: 'useInsertionEffect' }
    };
    
    // Redux Hooks
    const reduxHooks = {
      'useSelector': { type: 'redux', category: 'useSelector', framework: 'Redux' },
      'useDispatch': { type: 'redux', category: 'useDispatch', framework: 'Redux' },
      'useStore': { type: 'redux', category: 'useStore', framework: 'Redux' }
    };
    
    // 自定义Hook检测（以use开头）
    const isCustomHook = calleName.startsWith('use') && calleName.length > 3 && 
                        calleName[3] === calleName[3].toUpperCase();
    
    let hookInfo = null;
    
    if (builtinHooks[calleName]) {
      hookInfo = {
        name: calleName,
        type: 'builtin',
        category: builtinHooks[calleName].category,
        hookType: builtinHooks[calleName].type,
        framework: 'React',
        loc: this.formatLocation(node.loc),
        args: this.analyzeHookArguments(node.arguments, calleName)
      };
    } else if (reduxHooks[calleName]) {
      hookInfo = {
        name: calleName,
        type: 'redux',
        category: reduxHooks[calleName].category,
        hookType: reduxHooks[calleName].type,
        framework: reduxHooks[calleName].framework,
        loc: this.formatLocation(node.loc),
        args: this.analyzeHookArguments(node.arguments, calleName)
      };
    } else if (isCustomHook) {
      hookInfo = {
        name: calleName,
        type: 'custom',
        category: 'custom',
        hookType: 'custom',
        framework: 'React',
        loc: this.formatLocation(node.loc),
        args: this.analyzeHookArguments(node.arguments, calleName)
      };
    }
    
    return hookInfo;
  }
  
  /**
   * 分析Hook参数
   * @param {Array} args - Hook调用的参数数组
   * @param {string} hookName - Hook名称
   * @returns {object} 参数分析结果
   */
  analyzeHookArguments(args, hookName) {
    const result = {
      count: args.length,
      types: []
    };
    
    args.forEach((arg, index) => {
      let argType = 'unknown';
      
      switch (arg.type) {
        case 'Literal':
          argType = typeof arg.value;
          break;
        case 'Identifier':
          argType = 'identifier';
          break;
        case 'ArrowFunctionExpression':
        case 'FunctionExpression':
          argType = 'function';
          break;
        case 'ArrayExpression':
          argType = 'array';
          break;
        case 'ObjectExpression':
          argType = 'object';
          break;
        case 'CallExpression':
          argType = 'call';
          break;
        default:
          argType = arg.type;
      }
      
      result.types.push({
        index,
        type: argType,
        raw: arg.type
      });
    });
    
    // 特定Hook的参数分析
    if (hookName === 'useState' && args.length > 0) {
      result.initialValue = result.types[0];
    } else if (hookName === 'useEffect' && args.length > 0) {
      result.effect = result.types[0];
      if (args.length > 1) {
        result.dependencies = result.types[1];
      }
    } else if (hookName === 'useSelector' && args.length > 0) {
      result.selector = result.types[0];
    }
    
    return result;
  }
  
  /**
   * 检测Redux Action调用
   * @param {object} path - CallExpression AST路径
   * @returns {object|null} Redux Action信息或null
   */
  detectReduxActionCall(path) {
    const node = path.node;
    
    // 检测dispatch调用
    if (node.callee && node.callee.type === 'Identifier' && node.callee.name === 'dispatch') {
      let actionInfo = null;
      
      if (node.arguments.length > 0) {
        const arg = node.arguments[0];
        
        if (arg.type === 'CallExpression' && arg.callee && arg.callee.type === 'Identifier') {
          // dispatch(actionCreator())
          actionInfo = {
            type: 'action_creator_call',
            actionName: arg.callee.name,
            hasArguments: arg.arguments.length > 0,
            loc: this.formatLocation(node.loc)
          };
        } else if (arg.type === 'Identifier') {
          // dispatch(action)
          actionInfo = {
            type: 'action_dispatch',
            actionName: arg.name,
            hasArguments: false,
            loc: this.formatLocation(node.loc)
          };
        } else if (arg.type === 'ObjectExpression') {
          // dispatch({ type: 'ACTION_TYPE', payload: ... })
          const typeProperty = arg.properties.find(p => 
            p.key && p.key.name === 'type' && p.value && p.value.type === 'Literal'
          );
          
          if (typeProperty) {
            actionInfo = {
              type: 'action_object',
              actionType: typeProperty.value.value,
              hasPayload: arg.properties.some(p => p.key && p.key.name === 'payload'),
              loc: this.formatLocation(node.loc)
            };
          }
        }
      }
      
      return actionInfo;
    }
    
    // 检测useDispatch hook的使用
    if (node.callee && node.callee.type === 'Identifier' && node.callee.name === 'useDispatch') {
      return {
        type: 'use_dispatch_hook',
        framework: 'Redux',
        loc: this.formatLocation(node.loc)
      };
    }
    
    // 检测action creator调用（常见模式）
    if (node.callee && node.callee.type === 'MemberExpression') {
      const object = node.callee.object;
      const property = node.callee.property;
      
      // 检测 actions.actionName() 模式
      if (object && object.name === 'actions' && property && property.name) {
        return {
          type: 'action_from_actions',
          actionName: property.name,
          hasArguments: node.arguments.length > 0,
          loc: this.formatLocation(node.loc)
        };
      }
      
      // 检测 slice.actions.actionName() 模式
      if (object && object.type === 'MemberExpression' && 
          object.property && object.property.name === 'actions' &&
          property && property.name) {
        return {
          type: 'slice_action',
          sliceName: object.object ? object.object.name : 'unknown',
          actionName: property.name,
          hasArguments: node.arguments.length > 0,
          loc: this.formatLocation(node.loc)
        };
      }
    }
    
    return null;
  }

  /**
   * 分析Redux Reducer
   * @param {object} path - AST路径
   */
  analyzeReduxReducer(path) {
    const node = path.node;
    
    // 检测reducer函数
    if (node.value && node.value.type === 'FunctionExpression') {
      const currentEntity = this.entityStack[this.entityStack.length - 1];
      if (currentEntity && currentEntity.framework === 'Redux') {
        const reducerEntity = {
          id: `redux_reducer_${currentEntity.name}`,
          type: 'FunctionExpression',
          name: `${currentEntity.name}Reducer`,
          filePath: this.currentFilePath || 'unknown',
          loc: this.formatLocation(node.value.loc),
          framework: 'Redux',
          parentSlice: currentEntity.id
        };
        this.frameworkEntities.redux.set(reducerEntity.id, reducerEntity);
        this.entities.set(reducerEntity.id, reducerEntity);
        this.addRelation(currentEntity.id, reducerEntity.id, 'HAS_REDUCER');
      }
    }
  }

  /**
   * 分析对象方法
   * @param {object} path - AST路径
   * @param {string} filePath - 文件路径
   */
  analyzeObjectMethod(path, filePath) {
    const node = path.node;
    
    // 检测对象属性中的函数表达式
    if (node.value && node.value.type === 'FunctionExpression') {
      const methodName = node.key.name || node.key.value;
      const entity = {
        id: `${filePath}:${node.value.loc.start.line}:${node.value.loc.start.column}:${methodName}`,
        type: 'ObjectMethod',
        name: methodName,
        filePath: filePath || 'unknown',
        loc: this.formatLocation(node.value.loc),
        params: node.value.params.map(p => p.name),
        signature: this.getObjectMethodSignature(node.value, methodName)
      };
      this.entities.set(entity.id, entity);
      
      // 将实体添加到栈中，以便记录内部调用关系
      this.entityStack.push(entity);
      path.traverse({
        CallExpression: (p) => this.handleCallExpression(p, filePath)
      });
      this.entityStack.pop();
    }
  }

  /**
   * 分析立即执行函数表达式（IIFE）
   * @param {object} path - AST路径
   * @param {string} filePath - 文件路径
   */
  analyzeIIFE(path, filePath) {
    const node = path.node;
    
    // 检测立即执行函数表达式
    if (node.callee && node.callee.type === 'FunctionExpression') {
      const entity = {
        id: `${filePath}:${node.callee.loc.start.line}:${node.callee.loc.start.column}:IIFE`,
        type: 'CallExpression',
        name: 'IIFE',
        filePath: filePath || 'unknown',
        loc: this.formatLocation(node.callee.loc),
        params: node.callee.params.map(p => p.name),
        signature: this.getIIFESignature(node.callee),
        isIIFE: true
      };
      this.entities.set(entity.id, entity);
      
      // 将实体添加到栈中，以便记录内部调用关系
      this.entityStack.push(entity);
      path.traverse({
        CallExpression: (p) => this.handleCallExpression(p, filePath)
      });
      this.entityStack.pop();
    }
  }

  /**
   * 分析NEJ实体
   * @param {object} path - AST路径
   */
  analyzeNEJEntity(path) {
    const node = path.node;
    
    // 检测NEJ模块定义
    if (node.callee && node.callee.name === 'define') {
      const moduleName = node.arguments[0]?.value;
      if (moduleName) {
        this.createFrameworkEntity(
          `nej_module_${moduleName}`,
          'CallExpression',
          moduleName,
          'NEJ',
          node.loc
        );
      }
    }

    // 检测NEJ类定义
    if (node.callee && node.callee.name === 'Class') {
      const currentEntity = this.entityStack[this.entityStack.length - 1];
      if (currentEntity && currentEntity.framework === 'NEJ') {
        currentEntity.hasClass = true;
      }
    }

    // 检测NEJ继承
    if (node.callee && node.callee.name === 'extend') {
      const currentEntity = this.entityStack[this.entityStack.length - 1];
      if (currentEntity && currentEntity.framework === 'NEJ') {
        currentEntity.hasInheritance = true;
      }
    }
  }

  /**
   * 分析导入语句
   * @param {object} path - AST路径
   * @param {string} filePath - 文件路径
   */
  analyzeImportStatement(path, filePath) {
    const node = path.node;
    
    node.specifiers.forEach(specifier => {
      if (specifier.type === 'ImportDefaultSpecifier') {
        const importName = specifier.local.name;
        
        // 记录导入的实体，用于后续跨文件调用分析
        this.importedEntities.set(importName, {
          originalName: importName,
          localName: importName,
          source: node.source.value,
          filePath: filePath,
          type: 'ImportDefaultSpecifier'
        });
        
        // 使用统一的框架检测和实体创建
        const framework = this.detectImportFramework(node.source.value);
        if (framework) {
          const entityId = `${filePath}:${node.loc.start.line}:${node.loc.start.column}:import_${framework.toLowerCase()}_${importName}`;
          this.createFrameworkEntity(
            entityId,
            'ImportDeclaration',
            importName,
            framework,
            node.loc,
            { source: node.source.value }
          );
        }
      }
      
      // 处理命名导入
      if (specifier.type === 'ImportSpecifier') {
        const importedName = specifier.imported?.name || specifier.local?.name;
        const localName = specifier.local?.name;
        
        this.importedEntities.set(localName, {
          originalName: importedName,
          localName: localName,
          source: node.source.value,
          filePath: filePath,
          type: 'ImportSpecifier'
        });
      }
    });
  }

  /**
   * 分析导出语句
   * @param {object} path - AST路径
   * @param {string} filePath - 文件路径
   */
  analyzeExportStatement(path, filePath) {
    const node = path.node;
    
    if (node.declaration) {
      const declaration = node.declaration;
      
      if (declaration.type === 'FunctionDeclaration') {
        const entity = this.createFunctionEntity({ node: declaration }, filePath);
        entity.isExported = true;
        this.entities.set(entity.id, entity);
        this.exportedEntities.set(entity.name, entity);
      } else if (declaration.type === 'ClassDeclaration') {
        const entity = this.createClassEntity({ node: declaration }, filePath);
        entity.isExported = true;
        this.entities.set(entity.id, entity);
        this.exportedEntities.set(entity.name, entity);
      } else if (declaration.type === 'VariableDeclaration') {
        // 处理导出的变量声明，如 export const getRangeDays = ...
        declaration.declarations.forEach(decl => {
          if (decl.init && decl.init.type === 'ArrowFunctionExpression') {
            const entity = this.createArrowFunctionEntity({ node: declaration }, decl, filePath);
            entity.isExported = true;
            this.entities.set(entity.id, entity);
            this.exportedEntities.set(entity.name, entity);
          } else if (decl.init && decl.init.type === 'FunctionExpression') {
            const entity = this.createFunctionExpressionEntity({ node: declaration }, decl, filePath);
            entity.isExported = true;
            this.entities.set(entity.id, entity);
            this.exportedEntities.set(entity.name, entity);
          }
        });
      }
    }
    
    // 处理命名导出
    if (node.specifiers) {
      node.specifiers.forEach(specifier => {
        if (specifier.type === 'ExportSpecifier') {
          const exportedName = specifier.exported?.name || specifier.local?.name;
          this.exportedEntities.set(exportedName, {
            name: exportedName,
            localName: specifier.local?.name,
            filePath: filePath,
            type: 'ExportSpecifier'
          });
        }
      });
    }
  }

  /**
   * 创建函数实体
   * @param {object} path - AST路径
   * @param {string} filePath - 文件路径
   * @returns {object} 函数实体对象
   */
  createFunctionEntity(path, filePath) {
    return {
      id: `${filePath}:${path.node.loc.start.line}:${path.node.loc.start.column}:${path.node.id.name}`,
      type: 'FunctionDeclaration',
      name: path.node.id.name,
      filePath: filePath || 'unknown',
      loc: this.formatLocation(path.node.loc),
      params: path.node.params.map(p => p.name),
      isExported: false,
      signature: this.getFunctionSignature(path.node)
    };
  }

  /**
   * 创建类实体
   * @param {object} path - AST路径
   * @param {string} filePath - 文件路径
   * @returns {object} 类实体对象
   */
  createClassEntity(path, filePath) {
    return {
      id: `${filePath}:${path.node.loc.start.line}:${path.node.loc.start.column}:${path.node.id.name}`,
      type: 'ClassDeclaration',
      name: path.node.id.name,
      filePath: filePath || 'unknown',
      loc: this.formatLocation(path.node.loc),
      superClass: path.node.superClass?.name,
      isExported: false,
      signature: this.getClassSignature(path.node)
    };
  }

  /**
   * 创建类方法实体
   * @param {object} path - AST路径
   * @param {object} parentClass - 父类实体
   * @param {string} filePath - 文件路径
   * @returns {object} 方法实体对象
   */
  createMethodEntity(path, parentClass, filePath) {
    const methodName = path.node.key.name;
    return {
      id: `${filePath}:${path.node.loc.start.line}:${path.node.loc.start.column}:${parentClass.name}.${methodName}`,
      type: 'ClassMethod',
      name: methodName,
      filePath: filePath || 'unknown',
      loc: this.formatLocation(path.node.loc),
      isStatic: path.node.static,
      isAsync: path.node.async,
      params: path.node.params.map(p => p.name),
      parentClass: parentClass.id,
      signature: this.getMethodSignature(path.node)
    };
  }

  /**
   * 创建箭头函数实体
   * @param {object} path - AST路径
   * @param {object} declaration - 变量声明节点
   * @param {string} filePath - 文件路径
   * @returns {object} 箭头函数实体对象
   */
  createArrowFunctionEntity(path, declaration, filePath) {
    return {
      id: `${filePath}:${declaration.init.loc.start.line}:${declaration.init.loc.start.column}:${declaration.id.name}`,
      type: 'ArrowFunctionExpression',
      name: declaration.id.name,
      filePath: filePath || 'unknown',
      loc: this.formatLocation(declaration.init.loc),
      params: declaration.init.params.map(p => p.name),
      signature: this.getArrowFunctionSignature(declaration.init)
    };
  }

  /**
   * 创建函数表达式实体
   * @param {object} path - AST路径
   * @param {object} declaration - 变量声明节点
   * @param {string} filePath - 文件路径
   * @returns {object} 函数表达式实体对象
   */
  createFunctionExpressionEntity(path, declaration, filePath) {
    return {
      id: `${filePath}:${declaration.init.loc.start.line}:${declaration.init.loc.start.column}:${declaration.id.name}`,
      type: 'FunctionExpression',
      name: declaration.id.name,
      filePath: filePath || 'unknown',
      loc: this.formatLocation(declaration.init.loc),
      params: declaration.init.params.map(p => p.name),
      signature: this.getFunctionExpressionSignature(declaration.init)
    };
  }

  /**
   * 创建普通变量实体
   * @param {object} path - AST路径
   * @param {object} declaration - 变量声明节点
   * @param {string} filePath - 文件路径
   * @returns {object} 变量实体对象
   */
  createVariableEntity(path, declaration, filePath) {
    const variableType = this.detectVariableType(declaration.init);
    const declarationKind = path.node.kind; // 'const', 'let', 'var'
    
    return {
      id: `${filePath}:${declaration.loc.start.line}:${declaration.loc.start.column}:${declaration.id.name}`,
      type: 'VariableDeclarator',
      subType: variableType.type,
      name: declaration.id.name,
      filePath: filePath || 'unknown',
      loc: this.formatLocation(declaration.loc),
      declarationKind: declarationKind,
      initializer: variableType,
      isConstant: declarationKind === 'const'
    };
  }

  /**
   * 检测变量类型
   * @param {object} initNode - 初始化表达式节点
   * @returns {object} 变量类型信息
   */
  detectVariableType(initNode) {
    if (!initNode) {
      return { type: 'undefined', value: undefined };
    }

    switch (initNode.type) {
      case 'Literal':
        return {
          type: 'literal',
          valueType: typeof initNode.value,
          value: initNode.value
        };
      
      case 'Identifier':
        return {
          type: 'identifier',
          name: initNode.name
        };
      
      case 'ObjectExpression':
        return {
          type: 'object',
          properties: initNode.properties.map(prop => ({
            key: prop.key?.name || prop.key?.value,
            valueType: this.detectVariableType(prop.value).type
          }))
        };
      
      case 'ArrayExpression':
        return {
          type: 'array',
          length: initNode.elements.length,
          elementTypes: initNode.elements.map(el => this.detectVariableType(el).type)
        };
      
      case 'CallExpression':
        const callee = initNode.callee;
        if (callee.type === 'Identifier') {
          return {
            type: 'function_call',
            functionName: callee.name,
            arguments: initNode.arguments.length
          };
        } else if (callee.type === 'MemberExpression') {
          return {
            type: 'method_call',
            object: callee.object?.name,
            method: callee.property?.name,
            arguments: initNode.arguments.length
          };
        }
        return { type: 'call_expression' };
      
      case 'NewExpression':
        return {
          type: 'new_instance',
          className: initNode.callee?.name,
          arguments: initNode.arguments.length
        };
      
      case 'MemberExpression':
        return {
          type: 'member_access',
          object: initNode.object?.name,
          property: initNode.property?.name
        };
      
      case 'BinaryExpression':
        return {
          type: 'binary_expression',
          operator: initNode.operator
        };
      
      case 'ConditionalExpression':
        return {
          type: 'conditional_expression'
        };
      
      case 'TemplateLiteral':
        return {
          type: 'template_literal',
          expressionCount: initNode.expressions.length
        };
      
      case 'JSXElement':
        return {
          type: 'jsx_element',
          componentName: initNode.openingElement?.name?.name
        };
      
      default:
        return {
          type: initNode.type.toLowerCase(),
          raw: initNode.type
        };
    }
  }

  /**
   * 分析变量初始化器
   * @param {object} initNode - 初始化表达式节点
   * @param {object} variableEntity - 变量实体
   * @param {string} filePath - 文件路径
   */
  analyzeVariableInitializer(initNode, variableEntity, filePath) {
    if (!initNode) return;

    // 对初始化表达式进行分析，提取调用关系
    if (initNode.type === 'CallExpression') {
      // 为初始化器中的函数调用单独处理，避免传递无效的path对象
      this.handleVariableCallExpression(initNode, variableEntity, filePath);
      
      // 检测是否是Redux相关调用
      const reduxInfo = this.detectReduxActionCall({ node: initNode });
      if (reduxInfo) {
        variableEntity.reduxCalls = variableEntity.reduxCalls || [];
        variableEntity.reduxCalls.push(reduxInfo);
        variableEntity.hasReduxCalls = true;
      }
      
      // 检测是否是Hook调用
      const hookInfo = this.detectHookUsage({ node: initNode });
      if (hookInfo) {
        variableEntity.hooks = variableEntity.hooks || [];
        variableEntity.hooks.push(hookInfo);
        variableEntity.hasHooks = true;
        variableEntity.framework = 'React';
      }
    } else if (initNode.type === 'NewExpression') {
      // 分析构造函数调用
      this.handleConstructorCall(initNode, variableEntity, filePath);
    } else if (initNode.type === 'MemberExpression') {
      // 分析属性访问
      this.handleMemberAccess(initNode, variableEntity, filePath);
    } else if (initNode.type === 'ObjectExpression') {
      // 分析对象字面量中的方法
      initNode.properties.forEach(prop => {
        if (prop.value && (prop.value.type === 'FunctionExpression' || prop.value.type === 'ArrowFunctionExpression')) {
          const methodEntity = {
            id: `${variableEntity.id}_method_${prop.key?.name || 'anonymous'}`,
            type: 'ObjectMethod',
            name: prop.key?.name || 'anonymous',
            filePath: filePath,
            loc: this.formatLocation(prop.value.loc),
            parentVariable: variableEntity.id,
            params: prop.value.params?.map(p => p.name) || []
          };
          
          this.entities.set(methodEntity.id, methodEntity);
          this.addRelation(variableEntity.id, methodEntity.id, 'HAS_METHOD');
        }
      });
    }
  }

  /**
   * 处理变量初始化器中的函数调用（不依赖path对象）
   * @param {object} callNode - CallExpression节点
   * @param {object} variableEntity - 变量实体
   * @param {string} filePath - 文件路径
   */
  handleVariableCallExpression(callNode, variableEntity, filePath) {
    const callee = callNode.callee;
    
    if (callee.type === 'Identifier' || callee.type === 'MemberExpression') {
      // 获取被调用函数的名称
      let calledFunctionName = callee.type === 'Identifier' ? callee.name : (callee.property ? callee.property.name : 'unknown');
      
      // 在当前文件中查找同名实体
      let targetEntityId = null;
      for (const entity of this.entities.values()) {
        if (entity.name === calledFunctionName && entity.filePath === filePath) {
          targetEntityId = entity.id;
          break;
        }
      }
      
      // 如果在当前文件中没找到，检查是否是导入的函数
      if (!targetEntityId && this.importedEntities.has(calledFunctionName)) {
        targetEntityId = `imported_${calledFunctionName}`;
      }
      
      // 如果还是没找到，创建一个基于函数名的ID
      if (!targetEntityId) {
        targetEntityId = `${filePath}:unknown:${calledFunctionName}`;
      }
      
      // 记录调用信息（简化版本，不包含上下文信息）
      const callInfo = {
        from: variableEntity.id,
        to: targetEntityId,
        toName: calledFunctionName,
        type: 'CALLS',
        filePath: filePath,
        line: callNode.loc?.start?.line || 0,
        column: callNode.loc?.start?.column || 0,
        context: 'variable_initializer', // 固定上下文
        arguments: this.getArgumentsInfo(callNode.arguments),
        calleeType: this.getCalleeType(callee)
      };
      
      this.addDetailedRelation(callInfo);
      
      // 记录变量与函数调用的关系
      variableEntity.calls = variableEntity.calls || [];
      variableEntity.calls.push({
        functionName: calledFunctionName,
        targetId: targetEntityId,
        arguments: callNode.arguments.length,
        loc: this.formatLocation(callNode.loc)
      });
      
      console.log(`🔍 发现变量初始化调用: ${variableEntity.name} -> ${calledFunctionName} (${targetEntityId})`);
    }
  }

  /**
   * 处理构造函数调用
   * @param {object} newExprNode - new表达式节点
   * @param {object} variableEntity - 变量实体
   * @param {string} filePath - 文件路径
   */
  handleConstructorCall(newExprNode, variableEntity, filePath) {
    if (newExprNode.callee && newExprNode.callee.type === 'Identifier') {
      const constructorName = newExprNode.callee.name;
      
      // 记录构造函数调用关系
      const callRelation = {
        id: `${variableEntity.id}_new_${constructorName}`,
        from: variableEntity.id,
        to: constructorName,
        type: 'INSTANTIATES',
        loc: this.formatLocation(newExprNode.loc)
      };
      
      this.relations.set(callRelation.id, callRelation);
      
      // 更新变量实体信息
      variableEntity.instantiates = variableEntity.instantiates || [];
      variableEntity.instantiates.push({
        className: constructorName,
        arguments: newExprNode.arguments.length,
        loc: this.formatLocation(newExprNode.loc)
      });
    }
  }

  /**
   * 处理属性访问
   * @param {object} memberExprNode - 成员表达式节点
   * @param {object} variableEntity - 变量实体
   * @param {string} filePath - 文件路径
   */
  handleMemberAccess(memberExprNode, variableEntity, filePath) {
    if (memberExprNode.object && memberExprNode.property) {
      const objectName = memberExprNode.object.name;
      const propertyName = memberExprNode.property.name;
      
      // 记录属性访问关系
      variableEntity.accesses = variableEntity.accesses || [];
      variableEntity.accesses.push({
        object: objectName,
        property: propertyName,
        loc: this.formatLocation(memberExprNode.loc)
      });
    }
  }

  /**
   * 处理函数调用表达式
   * @param {object} path - AST路径
   * @param {string} filePath - 文件路径
   */
  handleCallExpression(path, filePath) {
    const currentEntity = this.entityStack[this.entityStack.length - 1];
    const callee = path.node.callee;
    
    if (currentEntity && (callee.type === 'Identifier' || callee.type === 'MemberExpression')) {
      // 获取被调用函数的名称
      let calledFunctionName = callee.type === 'Identifier' ? callee.name : (callee.property ? callee.property.name : 'unknown');
      
      // 处理 this.methodName() 形式的调用
      if (callee.type === 'MemberExpression' && callee.object && callee.object.type === 'ThisExpression') {
        // 这是 this.methodName() 形式的调用
        calledFunctionName = callee.property.name;
        
        // 查找当前类中的同名方法
        let targetEntityId = null;
        for (const entity of this.entities.values()) {
          if (entity.name === calledFunctionName && 
              entity.type === 'ClassMethod' && 
              entity.filePath === filePath) {
            // 检查是否是同一个类的方法
            const currentClass = this.findParentClass(currentEntity);
            if (currentClass && entity.parentClass === currentClass.id) {
              targetEntityId = entity.id;
              break;
            }
          }
        }
        
        if (targetEntityId) {
          // 记录类方法间的调用关系
          const callInfo = {
            from: currentEntity.id,
            to: targetEntityId,
            toName: calledFunctionName,
            type: 'CALLS',
            filePath: filePath,
            line: path.node.loc.start.line,
            column: path.node.loc.start.column,
            context: this.getCallContext(path),
            arguments: this.getArgumentsInfo(path.node.arguments),
            calleeType: 'method'
          };
          
          this.addDetailedRelation(callInfo);
          console.log(`🔍 发现类方法调用关系: ${currentEntity.name} -> ${calledFunctionName} (${targetEntityId})`);
          return;
        }
      }
      
      // 处理普通函数调用
      let targetEntityId = null;
      
      // 在当前文件中查找同名实体
      for (const entity of this.entities.values()) {
        if (entity.name === calledFunctionName && entity.filePath === filePath) {
          targetEntityId = entity.id;
          break;
        }
      }
      
      // 如果在当前文件中没找到，检查是否是导入的函数
      if (!targetEntityId && this.importedEntities.has(calledFunctionName)) {
        // 对于导入的函数，我们创建一个虚拟的ID
        targetEntityId = `imported_${calledFunctionName}`;
      }
      
      // 如果还是没找到，创建一个基于函数名的ID
      if (!targetEntityId) {
        targetEntityId = `${filePath}:unknown:${calledFunctionName}`;
      }
      
      // 记录详细的调用信息
      const callInfo = {
        from: currentEntity.id,
        to: targetEntityId,
        toName: calledFunctionName,  // 保存原始函数名
        type: 'CALLS',
        filePath: filePath,
        line: path.node.loc.start.line,
        column: path.node.loc.start.column,
        context: this.getCallContext(path),
        arguments: this.getArgumentsInfo(path.node.arguments),
        calleeType: this.getCalleeType(callee)
      };
      
      this.addDetailedRelation(callInfo);
      
      // 调试信息
      console.log(`🔍 发现调用关系: ${currentEntity.name} -> ${calledFunctionName} (${targetEntityId})`);
    }
  }

  /**
   * 添加实体间关系
   * @param {string} fromId - 源实体ID
   * @param {string} toId - 目标实体ID
   * @param {string} type - 关系类型
   */
  addRelation(fromId, toId, type) {
    const relationId = `${fromId}_${type}_${toId}`;
    this.relations.set(relationId, {
      from: fromId,
      to: toId,
      type
    });
  }

  /**
   * 添加详细的调用关系
   * @param {object} callInfo - 调用信息
   */
  addDetailedRelation(callInfo) {
    const relationId = `${callInfo.from}_${callInfo.type}_${callInfo.to}_${callInfo.line}_${callInfo.column}`;
    this.relations.set(relationId, callInfo);
  }

  /**
   * 格式化位置信息
   * @param {object} loc - AST位置信息
   * @returns {object} 格式化后的位置信息
   */
  formatLocation(loc) {
    return {
      start: { line: loc.start.line, column: loc.start.column },
      end: { line: loc.end.line, column: loc.end.column }
    };
  }

  /**
   * 获取框架特定的实体统计
   * @returns {object} 统计信息
   */
  getFrameworkStats() {
    return {
      react: {
        components: this.frameworkEntities.react.size,
        entities: Array.from(this.frameworkEntities.react.values())
      },
      redux: {
        stores: this.frameworkEntities.redux.size,
        entities: Array.from(this.frameworkEntities.redux.values())
      },
      nej: {
        modules: this.frameworkEntities.nej.size,
        entities: Array.from(this.frameworkEntities.nej.values())
      }
    };
  }

  /**
   * 获取AST类型统计
   * @returns {object} AST类型统计信息
   */
  getASTTypeStats() {
    const stats = {
      total: this.entities.size,
      byASTType: {},
      byFramework: {
        react: 0,
        redux: 0,
        nej: 0,
        none: 0
      },
      byFile: new Map()
    };

    for (const entity of this.entities.values()) {
      // 按AST类型统计
      const astType = entity.type;
      stats.byASTType[astType] = (stats.byASTType[astType] || 0) + 1;
      
      // 按框架统计
      if (entity.framework) {
        stats.byFramework[entity.framework.toLowerCase()] = (stats.byFramework[entity.framework.toLowerCase()] || 0) + 1;
      } else {
        stats.byFramework.none++;
      }
      
      // 按文件统计
      const filePath = entity.filePath;
      if (!stats.byFile.has(filePath)) {
        stats.byFile.set(filePath, { total: 0, byASTType: {} });
      }
      const fileStats = stats.byFile.get(filePath);
      fileStats.total++;
      fileStats.byASTType[astType] = (fileStats.byASTType[astType] || 0) + 1;
    }

    return stats;
  }

  /**
   * 获取函数签名
   * @param {object} node - 函数节点
   * @returns {string} 函数签名
   */
  getFunctionSignature(node) {
    const params = node.params.map(p => p.name || 'param').join(', ');
    return `${node.id?.name || 'anonymous'}(${params})`;
  }

  /**
   * 获取类签名
   * @param {object} node - 类节点
   * @returns {string} 类签名
   */
  getClassSignature(node) {
    const extendsClause = node.superClass ? ` extends ${node.superClass.name}` : '';
    return `class ${node.id?.name || 'anonymous'}${extendsClause}`;
  }

  /**
   * 获取方法签名
   * @param {object} node - 方法节点
   * @returns {string} 方法签名
   */
  getMethodSignature(node) {
    const params = node.params.map(p => p.name || 'param').join(', ');
    const modifiers = [];
    if (node.static) modifiers.push('static');
    if (node.async) modifiers.push('async');
    const modifierStr = modifiers.length > 0 ? `${modifiers.join(' ')} ` : '';
    return `${modifierStr}${node.key?.name || 'anonymous'}(${params})`;
  }

  /**
   * 获取箭头函数签名
   * @param {object} node - 箭头函数节点
   * @returns {string} 箭头函数签名
   */
  getArrowFunctionSignature(node) {
    const params = node.params.map(p => p.name || 'param').join(', ');
    return `(${params}) =>`;
  }

  /**
   * 获取函数表达式签名
   * @param {object} node - 函数表达式节点
   * @returns {string} 函数表达式签名
   */
  getFunctionExpressionSignature(node) {
    const params = node.params.map(p => p.name || 'param').join(', ');
    return `function(${params})`;
  }

  /**
   * 获取对象方法签名
   * @param {object} node - 函数表达式节点
   * @param {string} methodName - 方法名
   * @returns {string} 对象方法签名
   */
  getObjectMethodSignature(node, methodName) {
    const params = node.params.map(p => p.name || 'param').join(', ');
    return `${methodName}(${params})`;
  }

  /**
   * 获取IIFE签名
   * @param {object} node - 函数表达式节点
   * @returns {string} IIFE签名
   */
  getIIFESignature(node) {
    const params = node.params.map(p => p.name || 'param').join(', ');
    return `(function(${params}))()`;
  }

  /**
   * 获取调用上下文
   * @param {object} path - AST路径
   * @returns {string} 调用上下文
   */
  getCallContext(path) {
    const ancestors = path.getAncestry();
    const context = [];
    
    for (const ancestor of ancestors) {
      if (ancestor.node.type === 'FunctionDeclaration' && ancestor.node.id) {
        context.push(`function:${ancestor.node.id.name}`);
      } else if (ancestor.node.type === 'ClassDeclaration' && ancestor.node.id) {
        context.push(`class:${ancestor.node.id.name}`);
      } else if (ancestor.node.type === 'ClassMethod' && ancestor.node.key) {
        context.push(`method:${ancestor.node.key.name}`);
      }
    }
    
    return context.reverse().join(' > ');
  }

  /**
   * 获取参数信息
   * @param {Array} args - 参数数组
   * @returns {Array} 参数信息数组
   */
  getArgumentsInfo(args) {
    return args.map((arg, index) => {
      if (arg.type === 'Identifier') {
        return { type: 'identifier', name: arg.name, index };
      } else if (arg.type === 'Literal') {
        return { type: 'literal', value: arg.value, index };
      } else if (arg.type === 'ObjectExpression') {
        return { type: 'object', index };
      } else if (arg.type === 'ArrayExpression') {
        return { type: 'array', index };
      } else {
        return { type: 'expression', index };
      }
    });
  }

  /**
   * 查找实体的父类
   * @param {object} entity - 实体对象
   * @returns {object|null} 父类实体
   */
  findParentClass(entity) {
    if (entity.parentClass) {
      return this.entities.get(entity.parentClass);
    }
    return null;
  }

  /**
   * 获取被调用者类型
   * @param {object} callee - 被调用者节点
   * @returns {string} 被调用者类型
   */
  getCalleeType(callee) {
    if (callee.type === 'Identifier') {
      // 检查是否是导入的函数
      if (this.importedEntities.has(callee.name)) {
        return 'imported';
      }
      // 检查是否是导出的函数
      if (this.exportedEntities.has(callee.name)) {
        return 'exported';
      }
      return 'local';
    } else if (callee.type === 'MemberExpression') {
      return 'method';
    } else if (callee.type === 'CallExpression') {
      return 'chained';
    }
    return 'unknown';
  }

  /**
   * 获取导入的实体信息
   * @returns {Array} 导入的实体数组
   */
  getImportedEntities() {
    return Array.from(this.importedEntities.values());
  }

  /**
   * 获取导出的实体信息
   * @returns {Array} 导出的实体数组
   */
  getExportedEntities() {
    return Array.from(this.exportedEntities.values());
  }

  /**
   * 分析返回语句
   * @param {object} path - AST路径
   * @param {string} filePath - 文件路径
   */
  analyzeReturnStatement(path, filePath) {
    const currentEntity = this.entityStack[this.entityStack.length - 1];
    if (!currentEntity) return;

    const returnNode = path.node.argument;
    const returnInfo = this.analyzeReturnValue(returnNode);
    
    // 记录返回值信息到当前实体
    if (!currentEntity.returnValues) {
      currentEntity.returnValues = [];
    }
    
    const returnStatementInfo = {
      ...returnInfo,
      line: path.node.loc.start.line,
      column: path.node.loc.start.column,
      hasReturn: true
    };
    
    currentEntity.returnValues.push(returnStatementInfo);
    
    // 如果返回值引用了其他实体，建立关系
    if (returnInfo.type === 'identifier' && returnInfo.name) {
      // 检查是否是当前作用域内的变量
      const referencedEntity = this.findReferencedEntity(returnInfo.name, currentEntity);
      if (referencedEntity) {
        this.addRelation(currentEntity.id, referencedEntity.id, 'RETURNS');
      }
    }
  }

  /**
   * 分析赋值表达式（可能涉及函数返回值的赋值）
   * @param {object} path - AST路径
   * @param {string} filePath - 文件路径
   */
  analyzeAssignmentExpression(path, filePath) {
    const currentEntity = this.entityStack[this.entityStack.length - 1];
    if (!currentEntity) return;

    const { left, right } = path.node;
    
    // 检查右侧是否是函数调用
    if (right.type === 'CallExpression') {
      const callee = right.callee;
      if (callee.type === 'Identifier') {
        // 记录函数调用返回值被赋值的情况
        const assignmentInfo = {
          target: this.getAssignmentTarget(left),
          functionCall: callee.name,
          line: path.node.loc.start.line,
          column: path.node.loc.start.column,
          type: 'return_value_assignment'
        };
        
        if (!currentEntity.returnValueAssignments) {
          currentEntity.returnValueAssignments = [];
        }
        currentEntity.returnValueAssignments.push(assignmentInfo);
      }
    }
  }

  /**
   * 分析变量声明（可能涉及函数返回值的声明）
   * @param {object} path - AST路径
   * @param {string} filePath - 文件路径
   */
  analyzeVariableDeclarator(path, filePath) {
    const currentEntity = this.entityStack[this.entityStack.length - 1];
    if (!currentEntity) return;

    const { id, init } = path.node;
    
    // 检查初始化值是否是函数调用
    if (init && init.type === 'CallExpression') {
      const callee = init.callee;
      if (callee.type === 'Identifier') {
        // 记录函数调用返回值被声明的情况
        const declarationInfo = {
          variableName: id.name,
          functionCall: callee.name,
          line: path.node.loc.start.line,
          column: path.node.loc.start.column,
          type: 'return_value_declaration'
        };
        
        if (!currentEntity.returnValueDeclarations) {
          currentEntity.returnValueDeclarations = [];
        }
        currentEntity.returnValueDeclarations.push(declarationInfo);
      }
    }
  }

  /**
   * 分析返回值
   * @param {object} returnNode - 返回语句节点
   * @returns {object} 返回值信息
   */
  analyzeReturnValue(returnNode) {
    if (!returnNode) {
      return { type: 'undefined', hasReturn: false };
    }

    if (returnNode.type === 'Identifier') {
      return { 
        type: 'identifier', 
        name: returnNode.name,
        hasReturn: true 
      };
    } else if (returnNode.type === 'Literal') {
      return { 
        type: 'literal', 
        value: returnNode.value,
        hasReturn: true 
      };
    } else if (returnNode.type === 'ObjectExpression') {
      const properties = returnNode.properties.map(prop => {
        if (prop.type === 'ObjectProperty') {
          return {
            key: prop.key.name,
            value: this.analyzePropertyValue(prop.value)
          };
        }
        return null;
      }).filter(Boolean);
      
      return { 
        type: 'object', 
        properties,
        hasReturn: true 
      };
    } else if (returnNode.type === 'ArrayExpression') {
      const elements = returnNode.elements.map(element => 
        this.analyzePropertyValue(element)
      );
      
      return { 
        type: 'array', 
        elements,
        hasReturn: true 
      };
    } else if (returnNode.type === 'CallExpression') {
      const callee = returnNode.callee;
      if (callee.type === 'Identifier') {
        return { 
          type: 'function_call', 
          functionName: callee.name,
          hasReturn: true 
        };
      }
    } else if (returnNode.type === 'BinaryExpression') {
      return { 
        type: 'binary_expression', 
        operator: returnNode.operator,
        left: this.analyzePropertyValue(returnNode.left),
        right: this.analyzePropertyValue(returnNode.right),
        hasReturn: true 
      };
    } else if (returnNode.type === 'ConditionalExpression') {
      return { 
        type: 'conditional_expression', 
        test: this.analyzePropertyValue(returnNode.test),
        consequent: this.analyzePropertyValue(returnNode.consequent),
        alternate: this.analyzePropertyValue(returnNode.alternate),
        hasReturn: true 
      };
    } else if (returnNode.type === 'ArrowFunctionExpression') {
      return { 
        type: 'arrow_function', 
        hasReturn: true 
      };
    } else if (returnNode.type === 'FunctionExpression') {
      return { 
        type: 'function_expression', 
        hasReturn: true 
      };
    } else if (returnNode.type === 'ClassExpression') {
      return { 
        type: 'class_expression', 
        hasReturn: true 
      };
    } else if (returnNode.type === 'TemplateLiteral') {
      return { 
        type: 'template_literal', 
        hasReturn: true 
      };
    } else if (returnNode.type === 'JSXElement') {
      return { 
        type: 'jsx_element', 
        hasReturn: true 
      };
    }

    return { 
      type: 'expression', 
      hasReturn: true 
    };
  }

  /**
   * 分析属性值
   * @param {object} valueNode - 属性值节点
   * @returns {object} 属性值信息
   */
  analyzePropertyValue(valueNode) {
    if (!valueNode) return null;

    if (valueNode.type === 'Identifier') {
      return { type: 'identifier', name: valueNode.name };
    } else if (valueNode.type === 'Literal') {
      return { type: 'literal', value: valueNode.value };
    } else if (valueNode.type === 'ObjectExpression') {
      return { type: 'object' };
    } else if (valueNode.type === 'ArrayExpression') {
      return { type: 'array' };
    } else if (valueNode.type === 'CallExpression') {
      const callee = valueNode.callee;
      if (callee.type === 'Identifier') {
        return { type: 'function_call', functionName: callee.name };
      }
    }

    return { type: 'expression' };
  }

  /**
   * 查找引用的实体
   * @param {string} name - 实体名称
   * @param {object} currentEntity - 当前实体
   * @returns {object|null} 引用的实体
   */
  findReferencedEntity(name, currentEntity) {
    // 在当前作用域中查找
    for (const entity of this.entities.values()) {
      if (entity.name === name && entity.filePath === currentEntity.filePath) {
        return entity;
      }
    }
    
    // 在导入的实体中查找
    if (this.importedEntities.has(name)) {
      return this.importedEntities.get(name);
    }
    
    return null;
  }

  /**
   * 获取赋值目标信息
   * @param {object} leftNode - 赋值左侧节点
   * @returns {object} 赋值目标信息
   */
  getAssignmentTarget(leftNode) {
    if (leftNode.type === 'Identifier') {
      return { type: 'variable', name: leftNode.name };
    } else if (leftNode.type === 'MemberExpression') {
      const object = this.getAssignmentTarget(leftNode.object);
      const property = leftNode.property.name;
      return { type: 'property', object, property };
    } else if (leftNode.type === 'ArrayPattern') {
      return { type: 'array_destructuring' };
    } else if (leftNode.type === 'ObjectPattern') {
      return { type: 'object_destructuring' };
    }
    
    return { type: 'unknown' };
  }

  /**
   * 获取函数的返回值统计
   * @returns {object} 返回值统计信息
   */
  getReturnValueStats() {
    const stats = {
      totalFunctions: 0,
      functionsWithReturn: 0,
      returnTypes: {},
      returnValueUsage: {
        assignments: 0,
        declarations: 0
      }
    };

    for (const entity of this.entities.values()) {
      if (entity.type === 'FunctionDeclaration' || entity.type === 'ClassMethod' || entity.type === 'ArrowFunctionExpression' || entity.type === 'FunctionExpression' || entity.type === 'ObjectMethod') {
        stats.totalFunctions++;
        
        if (entity.returnValues && entity.returnValues.length > 0) {
          stats.functionsWithReturn++;
          
          entity.returnValues.forEach(returnInfo => {
            const type = returnInfo.type;
            stats.returnTypes[type] = (stats.returnTypes[type] || 0) + 1;
          });
        }
        
        if (entity.returnValueAssignments) {
          stats.returnValueUsage.assignments += entity.returnValueAssignments.length;
        }
        
        if (entity.returnValueDeclarations) {
          stats.returnValueUsage.declarations += entity.returnValueDeclarations.length;
        }
      }
    }

    return stats;
  }
}

/**
 * 分析单个文件
 * @param {string} filePath - 文件路径
 * @returns {Promise<object>} 分析结果
 * 
 * 使用示例：
 * const { analyzeFile, Neo4jEntityStore } = require('./entity-analyzer');
 * const neo4j = require('neo4j-driver');
 * 
 * // 分析文件
 * const result = await analyzeFile('./src/example.js');
 * 
 * // 存储到Neo4j
 * const driver = neo4j.driver('bolt://localhost:7687', neo4j.auth.basic('neo4j', 'password'));
 * const store = new Neo4jEntityStore(driver);
 * 
 * await store.createIndexes();
 * await store.storeEntities(result.entities);
 * await store.storeCallRelations(result.relations);
 * await store.storeReturnValueRelations(result.entities);  // 新增：存储返回值关系
 * await store.storeImportExportRelations(result.importedEntities, result.exportedEntities);
 * 
 * // 查看返回值统计
 * console.log('返回值统计:', result.returnValueStats);
 * 
 * driver.close();
 */
async function analyzeFile(filePath) {
  try {
    // 读取并解析文件
    const code = fs.readFileSync(filePath, 'utf-8');
    const ast = parser.parse(code, {
      sourceType: 'module',
      plugins: [
        // 基础语法支持
        'jsx',
        'typescript',
        // ES6/ES7 语法支持 (Babel 6.x 项目常用)
        'asyncToGenerator',
        'functionBind',
        'exportDefaultFrom',
        'exportExtensions',
        'decorators-legacy',
        'classProperties',
        'objectRestSpread',
        'functionSent',
        'dynamicImport',
        
        // React 相关 (针对 React + Redux 项目)
        // 现代 JavaScript 语法 (向后兼容)
        'asyncGenerators',
        'optionalChaining',
        'nullishCoalescingOperator',
        'optionalCatchBinding',
        'numericSeparator',
        'bigInt',
        'throwExpressions',
        
        // 模块系统增强
        'exportNamespaceFrom',
        'importMeta',
        // 私有属性 (如果项目使用)
        'privateIn',
        'classPrivateProperties',
        'classPrivateMethods',
        // 其他可能用到的语法
        'doExpressions',
        'partialApplication',
        'topLevelAwait',
        // NEJ 框架可能用到的特性
        'logicalAssignment',
        'recordAndTuple'
      ],
    });

    // 分析实体和关系
    const entityAnalyzer = new EntityAnalyzer();
    const { entities, relations, frameworkEntities, importedEntities, exportedEntities, returnValueStats, astTypeStats } = entityAnalyzer.analyze(filePath, ast);
    const stats = entityAnalyzer.getFrameworkStats();

    // 不再保存到本地文件，而是返回结果供存储到Neo4j
    // 如果需要调试，可以取消注释下面的代码
    /*
    const outputDir = path.join(path.dirname(filePath), 'output');
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir);
    }

    // 保存分析结果
    fs.writeFileSync(
      path.join(outputDir, 'entities.json'),
      JSON.stringify(entities, null, 2)
    );

    fs.writeFileSync(
      path.join(outputDir, 'entity-relations.json'),
      JSON.stringify(relations, null, 2)
    );

    fs.writeFileSync(
      path.join(outputDir, 'framework-entities.json'),
      JSON.stringify(frameworkEntities, null, 2)
    );

    fs.writeFileSync(
      path.join(outputDir, 'framework-stats.json'),
      JSON.stringify(stats, null, 2)
    );
    */

    return { entities, relations, frameworkEntities, importedEntities, exportedEntities, returnValueStats, astTypeStats, stats };

  } catch (error) {
    console.error(`Failed to analyze ${filePath}:`, error);
    return null;
  }
}

/**
 * Neo4j实体存储类
 * 用于将分析结果存储到Neo4j图数据库
 */
class Neo4jEntityStore {
  constructor(driver) {
    this.driver = driver;
  }

  /**
   * 批量存储实体到Neo4j
   * @param {Array} entities - 实体数组
   * @param {string} database - 数据库名称
   */
  async storeEntities(entities, database = 'neo4j') {
    const session = this.driver.session({ database });
    try {
      // 过滤掉没有有效文件路径的实体
      const validEntities = entities.filter(entity => entity.filePath && entity.filePath.trim() !== '');
      
      if (validEntities.length === 0) {
        console.log('📝 没有有效的实体需要存储');
        return;
      }
      
      // 批量创建实体节点
      await session.run(`
        UNWIND $entities as entity
        MERGE (e:Entity {id: entity.id})
        SET e += entity
        WITH e, entity
        WHERE entity.filePath IS NOT NULL AND entity.filePath <> ''
        MERGE (f:File {path: entity.filePath})
        MERGE (e)-[:BELONGS_TO]->(f)
      `, { entities: validEntities });
      
      console.log(`✅ 成功存储 ${validEntities.length} 个实体到Neo4j`);
      
      if (validEntities.length < entities.length) {
        console.log(`⚠️  跳过 ${entities.length - validEntities.length} 个无效文件路径的实体`);
      }
    } catch (error) {
      console.error('❌ 存储实体到Neo4j失败:', error);
      throw error;
    } finally {
      await session.close();
    }
  }

  /**
   * 批量存储调用关系到Neo4j
   * @param {Array} relations - 关系数组
   * @param {string} database - 数据库名称
   */
  async storeCallRelations(relations, database = 'neo4j') {
    const session = this.driver.session({ database });
    try {
      // 过滤出调用关系
      const callRelations = relations.filter(rel => rel.type === 'CALLS');
      
      if (callRelations.length === 0) {
        console.log('📝 没有调用关系需要存储');
        return;
      }

      // 存储所有调用关系，包括目标实体不存在的情况
      await session.run(`
        UNWIND $relations as rel
        MATCH (from:Entity {id: rel.from})
        MERGE (to:Entity {id: rel.to, name: rel.toName, type: 'Identifier'})
        MERGE (from)-[r:CALLS]->(to)
        SET r += rel
      `, { relations: callRelations });
      
      console.log(`✅ 成功存储 ${callRelations.length} 个调用关系到Neo4j`);
      
    } catch (error) {
      console.error('❌ 存储调用关系到Neo4j失败:', error);
      throw error;
    } finally {
      await session.close();
    }
  }

  /**
   * 存储文件依赖关系到Neo4j
   * @param {Array} importedEntities - 导入的实体数组
   * @param {Array} exportedEntities - 导出的实体数组
   * @param {string} database - 数据库名称
   */
  async storeImportExportRelations(importedEntities, exportedEntities, database = 'neo4j') {
    const session = this.driver.session({ database });
    try {
      // 创建导入导出关系
      const importExportRelations = [];
      
      importedEntities.forEach(imported => {
        exportedEntities.forEach(exported => {
          if (imported.originalName === exported.name) {
            importExportRelations.push({
              from: imported.filePath,
              to: exported.filePath,
              entityName: imported.originalName,
              type: 'IMPORTS_FROM'
            });
          }
        });
      });

      if (importExportRelations.length > 0) {
        await session.run(`
          UNWIND $relations as rel
          MERGE (f1:File {path: rel.from})
          MERGE (f2:File {path: rel.to})
          MERGE (f1)-[r:IMPORTS_FROM]->(f2)
          SET r += rel
        `, { relations: importExportRelations });
        
        console.log(`✅ 成功存储 ${importExportRelations.length} 个导入导出关系到Neo4j`);
      }
    } catch (error) {
      console.error('❌ 存储导入导出关系到Neo4j失败:', error);
      throw error;
    } finally {
      await session.close();
    }
  }

  /**
   * 存储返回值关系到Neo4j
   * @param {Array} entities - 实体数组
   * @param {string} database - 数据库名称
   */
  async storeReturnValueRelations(entities, database = 'neo4j') {
    const session = this.driver.session({ database });
    try {
      // 批量创建返回值关系
      const returnRelations = [];
      
      entities.forEach(entity => {
        // 处理序列化的 returnValues
        if (entity.returnValues) {
          let returnValues;
          try {
            // 尝试解析 JSON 字符串
            returnValues = typeof entity.returnValues === 'string' 
              ? JSON.parse(entity.returnValues) 
              : entity.returnValues;
          } catch (e) {
            // 如果不是 JSON 字符串，直接使用
            returnValues = entity.returnValues;
          }
          
          if (Array.isArray(returnValues) && returnValues.length > 0) {
            returnValues.forEach(returnInfo => {
              if (returnInfo.type === 'identifier' && returnInfo.name) {
                returnRelations.push({
                  from: entity.id,
                  to: returnInfo.name,
                  type: 'RETURNS',
                  returnType: returnInfo.type,
                  line: returnInfo.line,
                  column: returnInfo.column
                });
              }
            });
          }
        }
      });

      if (returnRelations.length > 0) {
        await session.run(`
          UNWIND $relations as rel
          MATCH (from:Entity {id: rel.from})
          MERGE (to:Entity {id: rel.to})
          MERGE (from)-[r:RETURNS]->(to)
          SET r += rel
        `, { relations: returnRelations });
        
        console.log(`✅ 成功存储 ${returnRelations.length} 个返回值关系到Neo4j`);
      } else {
        console.log('📝 没有返回值关系需要存储');
      }
    } catch (error) {
      console.error('❌ 存储返回值关系到Neo4j失败:', error);
      throw error;
    } finally {
      await session.close();
    }
  }

  /**
   * 创建Neo4j索引（如果不存在）
   * @param {string} database - 数据库名称
   */
  async createIndexes(database = 'neo4j') {
    const session = this.driver.session({ database });
    try {
      // 创建实体ID索引
      await session.run('CREATE INDEX entity_id_index IF NOT EXISTS FOR (e:Entity) ON (e.id)');
      // 创建文件路径索引
      await session.run('CREATE INDEX file_path_index IF NOT EXISTS FOR (f:File) ON (f.path)');
      // 创建实体名称索引
      await session.run('CREATE INDEX entity_name_index IF NOT EXISTS FOR (e:Entity) ON (e.name)');
      
      console.log('✅ Neo4j索引创建完成');
    } catch (error) {
      console.error('❌ 创建Neo4j索引失败:', error);
    } finally {
      await session.close();
    }
  }
}

// 导出模块
module.exports = {
  EntityAnalyzer,
  analyzeFile,
  Neo4jEntityStore
};
