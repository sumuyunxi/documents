const fs = require('fs');
const path = require('path');
const glob = require('glob');
const parser = require('@babel/parser');
const traverse = require('@babel/traverse').default;
const neo4j = require('neo4j-driver');

// 配置
const NEO4J_DATABASES = [
  {
    name: 'web-worksheet-database',
    uri: 'bolt://localhost:7687',
    user: 'neo4j',
    pass: 'fF5SQmjTvDgovryr9UAJxEGFIQHVfjP3WwmP3_Qz4Es',
  },
  {
    name: 'web-ai-database',
    uri: 'bolt://localhost:7687',
    user: 'neo4j',
    pass: 'fF5SQmjTvDgovryr9UAJxEGFIQHVfjP3WwmP3_Qz4Es',
  },

];

// 默认使用第一个数据库配置
const DEFAULT_DB_CONFIG = NEO4J_DATABASES[1];
const NEO4J_URI = DEFAULT_DB_CONFIG.uri;
const NEO4J_USER = DEFAULT_DB_CONFIG.user;
const NEO4J_PASS = DEFAULT_DB_CONFIG.pass;

// 可以通过命令行参数指定项目路径，默认为当前目录
const projectRoot = process.argv[2] || process.cwd();
const outputDir = path.join(process.cwd(), 'output');
const nodesFilePath = path.join(outputDir, 'nodes.json');
const edgesFilePath = path.join(outputDir, 'edges.json');

const possibleExtensions = ['.js', '.jsx', '.ts', '.tsx', '.json', '.d.ts'];

console.log(`🔍 分析项目: ${projectRoot}`);

// 简化的路径解析函数
function resolvePath(baseDir, source) {
  if (source.startsWith('.')) {
    const resolvedPath = path.resolve(baseDir, source);

    // 尝试不同的扩展名
    for (const ext of possibleExtensions) {
      const fullPath = resolvedPath + ext;
      if (fs.existsSync(fullPath)) {
        return fullPath;
      }
    }
    
    // 如果路径本身存在（可能是目录下的index文件）
    if (fs.existsSync(resolvedPath)) {
      const stat = fs.statSync(resolvedPath);
      if (stat.isDirectory()) {
        // 尝试index文件
        for (const ext of possibleExtensions) {
          const indexPath = path.join(resolvedPath, 'index' + ext);
          if (fs.existsSync(indexPath)) {
            return indexPath;
          }
        }
      } else {
        return resolvedPath;
      }
    }
  }
  
  return null;
}

if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir);
}

/**
 * 解析文件，并提取依赖
 */
async function analyzeFile(filePath, npmPackages) {
  try {
    const code = fs.readFileSync(filePath, 'utf-8');
    const ast = parser.parse(code, {
      sourceType: 'module',
      plugins: [
        'jsx',
        'typescript',
        'decorators-legacy',
        'classProperties',
        'exportDefaultFrom',
      ],
    });

    const dependencies = [];
    const currentDir = path.dirname(filePath);

    traverse(ast, {
      'ImportDeclaration|ExportNamedDeclaration|ExportAllDeclaration'(nodePath) {
        if (nodePath.node.source) {
          const source = nodePath.node.source.value;
          if (source.startsWith('.')) {
            const targetPath = resolvePath(currentDir, source);
            if (targetPath) {
              dependencies.push({ from: filePath, to: targetPath, type: 'static' });
            } else {
              console.warn(`[!] Could not resolve static import '${source}' in ${path.relative(projectRoot, filePath)}`);
            }
          } else {
            npmPackages.add(source);
            dependencies.push({ from: filePath, to: `npm:${source}`, type: 'npm' });
          }
        }
      },
      CallExpression(nodePath) {
        const callee = nodePath.node.callee;
        const args = nodePath.node.arguments;
        if (callee.name === 'require' && args.length > 0 && typeof args[0].value === 'string') {
          const source = args[0].value;
          if (source.startsWith('.')) {
            const targetPath = resolvePath(currentDir, source);
            if (targetPath) {
              dependencies.push({ from: filePath, to: targetPath, type: 'commonjs' });
            } else {
              console.warn(`[!] Could not resolve require('${source}') in ${path.relative(projectRoot, filePath)}`);
            }
          } else {
            npmPackages.add(source);
            dependencies.push({ from: filePath, to: `npm:${source}`, type: 'npm' });
          }
        }
        if (callee.type === 'Import' && args.length > 0 && typeof args[0].value === 'string') {
          const source = args[0].value;
          if (source.startsWith('.')) {
            const targetPath = resolvePath(currentDir, source);
            if (targetPath) {
              dependencies.push({ from: filePath, to: targetPath, type: 'dynamic' });
            } else {
              console.warn(`[!] Could not resolve dynamic import('${source}') in ${path.relative(projectRoot, filePath)}`);
            }
          } else {
            npmPackages.add(source);
            dependencies.push({ from: filePath, to: `npm:${source}`, type: 'npm' });
          }
        }
      },
    });
    
    return { dependencies };
  } catch (error) {
    console.error(`Failed to analyze ${filePath}:`, error.message);
    return null;
  }
}

/**
 * 保存数据到Neo4j
 */
async function saveToNeo4j(nodes, edges) {
  const driver = neo4j.driver(NEO4J_URI, neo4j.auth.basic(NEO4J_USER, NEO4J_PASS));
  const session = driver.session({ database: DEFAULT_DB_CONFIG.name });
  
  try {
    console.log('🗄️ 保存数据到Neo4j...');
    
    // 清空旧数据
    await session.run('MATCH (n) DETACH DELETE n');

    // 批量插入节点
    for (const node of nodes) {
      const label = node.type === 'package' ? 'Package' : 'File';
      await session.run(
        `MERGE (n:${label} {id: $id, file: $file, type: $type})`,
        { id: node.id, file: node.file, type: node.type }
      );
    }

    // 批量插入边
    for (const edge of edges) {
      const fromNode = nodes.find(n => n.id === edge.from);
      const toNode = nodes.find(n => n.id === edge.to);
      
      if (fromNode && toNode) {
        const fromLabel = fromNode.type === 'package' ? 'Package' : 'File';
        const toLabel = toNode.type === 'package' ? 'Package' : 'File';
        
        await session.run(
          `MATCH (a:${fromLabel} {id: $from}), (b:${toLabel} {id: $to})
           MERGE (a)-[:DEPENDS_ON {type: $type}]->(b)`,
          { from: edge.from, to: edge.to, type: edge.type }
        );
      }
    }
    
    console.log('✅ 数据已保存到Neo4j!');
  } finally {
    await session.close();
    await driver.close();
  }
}

async function main() {
  console.log('🚀 开始分析项目依赖关系...\n');

  // 查找所有JavaScript/TypeScript文件，只解析src和tools目录
  const patterns = [
    'source/**/*.{js,jsx,ts,tsx}',
    'tools/**/*.{js,jsx,ts,tsx}',
    '!node_modules/**',
    '!dist/**',
    '!build/**',
    '!.git/**',
    '!coverage/**'
  ];
  
  const files = glob.sync(patterns, { cwd: projectRoot, absolute: true });
  console.log(`📁 找到 ${files.length} 个文件`);

  const nodes = [];
  const edges = [];
  const npmPackages = new Set();

  // 分析每个文件
  for (const file of files) {
    const relativePath = path.relative(projectRoot, file);
    const analysisResult = await analyzeFile(file, npmPackages);

    if (analysisResult) {
      nodes.push({
        id: file,
        file: relativePath,
        type: 'internal',
      });
      edges.push(...analysisResult.dependencies);
    }
  }

  // 添加npm包节点
  npmPackages.forEach(pkg => {
    nodes.push({
      id: `npm:${pkg}`,
      file: pkg,
      type: 'package',
    });
  });

  // 过滤掉type为package的节点
  const filteredNodes = nodes.filter(node => node.type !== 'package');
  
  // 过滤掉与package节点相关的边
  const filteredEdges = edges.filter(edge => {
    const fromNode = nodes.find(n => n.id === edge.from);
    const toNode = nodes.find(n => n.id === edge.to);
    return !(fromNode && fromNode.type === 'package') && !(toNode && toNode.type === 'package');
  });
  
  // 保存到JSON文件
  fs.writeFileSync(nodesFilePath, JSON.stringify(filteredNodes, null, 2));
  fs.writeFileSync(edgesFilePath, JSON.stringify(filteredEdges, null, 2));

  console.log(`\n📊 分析完成:`);
  console.log(`  - 节点数量: ${filteredNodes.length}`);
  console.log(`  - 关系数量: ${filteredEdges.length}`);
  console.log(`  - 文件数量: ${filteredNodes.filter(n => n.type === 'internal').length}`);
  console.log(`  - 原始包数量: ${nodes.filter(n => n.type === 'package').length} (已从输出中过滤)`);

  // 保存到Neo4j
  await saveToNeo4j(filteredNodes, filteredEdges);

  console.log(`\n🎯 下一步:`);
  console.log(`  1. 打开Neo4j Browser: http://localhost:7474`);
  console.log(`  2. 切换到: :use ${DEFAULT_DB_CONFIG.name}数据库`);
  console.log(`  3. 查看完整图: MATCH (a)-[r:DEPENDS_ON]->(b) RETURN a, r, b`);
}

main().catch(console.error);