const fs = require('fs');
const path = require('path');
const glob = require('glob');
const { analyzeFile, Neo4jEntityStore } = require('./entity-analyzer');
const neo4j = require('neo4j-driver');

// Neo4j 数据库配置
const NEO4J_CONFIG = {
  uri: 'bolt://localhost:7687',
  user: 'neo4j',
  password: 'fF5SQmjTvDgovryr9UAJxEGFIQHVfjP3WwmP3_Qz4Es',
  database: 'testentity'
};

// 支持的文件扩展名
const SUPPORTED_EXTENSIONS = ['.js', '.jsx', '.ts', '.tsx','.d.ts'];

// 排除的目录
const EXCLUDED_DIRS = [
  'node_modules',
  'dist',
  'build',
  '.git',
  'coverage',
  '.next',
  '.nuxt',
  'out',
  'target',
  '.cache',
  '.parcel-cache'
];

/**
 * 获取命令行参数
 */
function getCommandLineArgs() {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.log('❌ 请提供项目路径参数');
    console.log('使用方法: node analyze-project-entities.js <项目绝对路径> [选项]');
    console.log('选项:');
    console.log('  --neo4j-uri <uri>      Neo4j 连接 URI (默认: bolt://localhost:7687)');
    console.log('  --neo4j-user <user>    Neo4j 用户名 (默认: neo4j)');
    console.log('  --neo4j-pass <pass>    Neo4j 密码');
    console.log('  --neo4j-db <database>  Neo4j 数据库名 (默认: neo4j)');
    console.log('  --output-dir <dir>     输出目录 (默认: ./output)');
    console.log('  --save-to-file         保存结果到本地文件');
    console.log('  --no-neo4j            不保存到 Neo4j 数据库');
    console.log('  --verbose             详细输出模式');
    process.exit(1);
  }

  const projectPath = args[0];
  const options = {
    projectPath,
    neo4jUri: 'bolt://localhost:7687',
    neo4jUser: 'neo4j',
    neo4jPassword: 'fF5SQmjTvDgovryr9UAJxEGFIQHVfjP3WwmP3_Qz4Es',
    neo4jDatabase: 'neo4j',
    outputDir: './output',
    saveToFile: false,
    useNeo4j: true,
    verbose: false
  };

  // 解析选项
  for (let i = 1; i < args.length; i += 2) {
    const option = args[i];
    const value = args[i + 1];

    switch (option) {
      case '--neo4j-uri':
        options.neo4jUri = value;
        break;
      case '--neo4j-user':
        options.neo4jUser = value;
        break;
      case '--neo4j-pass':
        options.neo4jPassword = value;
        break;
      case '--neo4j-db':
        options.neo4jDatabase = value;
        break;
      case '--output-dir':
        options.outputDir = value;
        break;
      case '--save-to-file':
        options.saveToFile = true;
        i--; // 不需要值参数
        break;
      case '--no-neo4j':
        options.useNeo4j = false;
        i--; // 不需要值参数
        break;
      case '--verbose':
        options.verbose = true;
        i--; // 不需要值参数
        break;
    }
  }

  return options;
}

/**
 * 验证项目路径
 */
function validateProjectPath(projectPath) {
  if (!fs.existsSync(projectPath)) {
    throw new Error(`项目路径不存在: ${projectPath}`);
  }

  const stat = fs.statSync(projectPath);
  if (!stat.isDirectory()) {
    throw new Error(`项目路径不是目录: ${projectPath}`);
  }

  console.log(`✅ 项目路径验证通过: ${projectPath}`);
  return true;
}

/**
 * 获取项目中的所有文件名在扩展文件名数组中的文件
 */
function getProjectFiles(projectPath) {
  const patterns = SUPPORTED_EXTENSIONS.map(ext => `**/*${ext}`);
  const ignorePatterns = EXCLUDED_DIRS.map(dir => `**/${dir}/**`);
  
  const allPatterns = [...patterns, ...ignorePatterns.map(pattern => `!${pattern}`)];
  
  const files = [];
  
  allPatterns.slice(0, -ignorePatterns.length).forEach(pattern => {
    const matchedFiles = glob.sync(pattern, {
      cwd: projectPath,
      absolute: true,
      ignore: ignorePatterns
    });
    files.push(...matchedFiles);
  });

  // 去重
  const uniqueFiles = [...new Set(files)];
  
  console.log(`📁 找到 ${uniqueFiles.length} 个文件需要分析`);
  
  if (uniqueFiles.length === 0) {
    console.log('⚠️  警告: 没有找到可分析的文件');
    console.log(`支持的文件类型: ${SUPPORTED_EXTENSIONS.join(', ')}`);
    console.log(`排除的目录: ${EXCLUDED_DIRS.join(', ')}`);
  }

  return uniqueFiles;
}

/**
 * 分析单个文件
 */
async function analyzeSingleFile(filePath, options) {
  try {
    if (options.verbose) {
      console.log(`🔍 分析文件: ${path.relative(options.projectPath, filePath)}`);
    }

    const result = await analyzeFile(filePath);
    
    if (!result) {
      console.log(`❌ 分析失败: ${filePath}`);
      return null;
    }

    if (options.verbose) {
      console.log(`✅ 分析完成: ${path.relative(options.projectPath, filePath)}`);
      console.log(`   - 实体数量: ${result.entities.length}`);
      console.log(`   - 关系数量: ${result.relations.length}`);
      console.log(`   - React 实体: ${result.frameworkEntities.react.length}`);
      console.log(`   - Redux 实体: ${result.frameworkEntities.redux.length}`);
      console.log(`   - NEJ 实体: ${result.frameworkEntities.nej.length}`);
    }

    return result;
  } catch (error) {
    console.error(`❌ 分析文件出错 ${filePath}:`, error.message);
    return null;
  }
}

/**
 * 合并分析结果
 */
function mergeAnalysisResults(results) {
  const merged = {
    entities: [],
    relations: [],
    frameworkEntities: {
      react: [],
      redux: [],
      nej: []
    },
    importedEntities: [],
    exportedEntities: [],
    returnValueStats: {
      totalFunctions: 0,
      functionsWithReturn: 0,
      returnTypes: {},
      returnValueUsage: {
        assignments: 0,
        declarations: 0
      }
    },
    stats: {
      react: { components: 0, entities: [] },
      redux: { stores: 0, entities: [] },
      nej: { modules: 0, entities: [] }
    },
    fileStats: {
      totalFiles: results.length,
      successfulFiles: 0,
      failedFiles: 0
    }
  };

  results.forEach(result => {
    if (result) {
      merged.entities.push(...result.entities);
      merged.relations.push(...result.relations);
      merged.frameworkEntities.react.push(...result.frameworkEntities.react);
      merged.frameworkEntities.redux.push(...result.frameworkEntities.redux);
      merged.frameworkEntities.nej.push(...result.frameworkEntities.nej);
      merged.importedEntities.push(...result.importedEntities);
      merged.exportedEntities.push(...result.exportedEntities);
      
      // 合并返回值统计
      if (result.returnValueStats) {
        merged.returnValueStats.totalFunctions += result.returnValueStats.totalFunctions || 0;
        merged.returnValueStats.functionsWithReturn += result.returnValueStats.functionsWithReturn || 0;
        
        Object.entries(result.returnValueStats.returnTypes || {}).forEach(([type, count]) => {
          merged.returnValueStats.returnTypes[type] = (merged.returnValueStats.returnTypes[type] || 0) + count;
        });
        
        merged.returnValueStats.returnValueUsage.assignments += result.returnValueStats.returnValueUsage?.assignments || 0;
        merged.returnValueStats.returnValueUsage.declarations += result.returnValueStats.returnValueUsage?.declarations || 0;
      }
      
      merged.fileStats.successfulFiles++;
    } else {
      merged.fileStats.failedFiles++;
    }
  });

  // 更新框架统计
  merged.stats.react.components = merged.frameworkEntities.react.length;
  merged.stats.redux.stores = merged.frameworkEntities.redux.length;
  merged.stats.nej.modules = merged.frameworkEntities.nej.length;

  return merged;
}

/**
 * 保存结果到本地文件
 */
function saveResultsToFile(results, outputDir) {
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const baseFileName = `analysis-${timestamp}`;

  // 保存完整结果
  fs.writeFileSync(
    path.join(outputDir, `${baseFileName}-complete.json`),
    JSON.stringify(results, null, 2)
  );

  // 保存实体数据
  fs.writeFileSync(
    path.join(outputDir, `${baseFileName}-entities.json`),
    JSON.stringify(results.entities, null, 2)
  );

  // 保存关系数据
  fs.writeFileSync(
    path.join(outputDir, `${baseFileName}-relations.json`),
    JSON.stringify(results.relations, null, 2)
  );

  // 保存框架实体数据
  fs.writeFileSync(
    path.join(outputDir, `${baseFileName}-framework-entities.json`),
    JSON.stringify(results.frameworkEntities, null, 2)
  );

  // 保存统计信息
  fs.writeFileSync(
    path.join(outputDir, `${baseFileName}-stats.json`),
    JSON.stringify({
      stats: results.stats,
      returnValueStats: results.returnValueStats,
      fileStats: results.fileStats
    }, null, 2)
  );

  console.log(`💾 结果已保存到: ${outputDir}`);
  console.log(`   - ${baseFileName}-complete.json (完整结果)`);
  console.log(`   - ${baseFileName}-entities.json (实体数据)`);
  console.log(`   - ${baseFileName}-relations.json (关系数据)`);
  console.log(`   - ${baseFileName}-framework-entities.json (框架实体)`);
  console.log(`   - ${baseFileName}-stats.json (统计信息)`);
}

  /**
   * 序列化实体数据，将复杂对象转换为字符串
   * @param {object} entity - 实体对象
   * @returns {object} 序列化后的实体对象
   */
  function serializeEntity(entity) {
    const serialized = { ...entity };
    
    // 确保 filePath 不为 null
    if (!serialized.filePath) {
      serialized.filePath = 'unknown';
    }
    
    // 序列化位置信息
    if (serialized.loc && typeof serialized.loc === 'object') {
      serialized.loc = JSON.stringify(serialized.loc);
    }
    
    // 序列化参数数组
    if (serialized.params && Array.isArray(serialized.params)) {
      serialized.params = JSON.stringify(serialized.params);
    }
    
    // 序列化返回值信息
    if (serialized.returnValues && Array.isArray(serialized.returnValues)) {
      serialized.returnValues = JSON.stringify(serialized.returnValues);
    }
    
    // 序列化返回值赋值信息
    if (serialized.returnValueAssignments && Array.isArray(serialized.returnValueAssignments)) {
      serialized.returnValueAssignments = JSON.stringify(serialized.returnValueAssignments);
    }
    
    // 序列化返回值声明信息
    if (serialized.returnValueDeclarations && Array.isArray(serialized.returnValueDeclarations)) {
      serialized.returnValueDeclarations = JSON.stringify(serialized.returnValueDeclarations);
    }
    
    // 序列化签名信息
    if (serialized.signature && typeof serialized.signature === 'object') {
      serialized.signature = JSON.stringify(serialized.signature);
    }
    
    // 序列化Hook信息
    if (serialized.hooks && Array.isArray(serialized.hooks)) {
      serialized.hooks = JSON.stringify(serialized.hooks);
    }
    
    // 序列化Redux调用信息
    if (serialized.reduxCalls && Array.isArray(serialized.reduxCalls)) {
      serialized.reduxCalls = JSON.stringify(serialized.reduxCalls);
    }
    
    // 序列化变量初始化器信息
    if (serialized.initializer && typeof serialized.initializer === 'object') {
      serialized.initializer = JSON.stringify(serialized.initializer);
    }
    
    // 序列化实例化信息
    if (serialized.instantiates && Array.isArray(serialized.instantiates)) {
      serialized.instantiates = JSON.stringify(serialized.instantiates);
    }
    
    // 序列化访问信息
    if (serialized.accesses && Array.isArray(serialized.accesses)) {
      serialized.accesses = JSON.stringify(serialized.accesses);
    }
    
    // 序列化调用信息
    if (serialized.calls && Array.isArray(serialized.calls)) {
      serialized.calls = JSON.stringify(serialized.calls);
    }
    
    // 序列化其他可能的复杂对象属性
    Object.keys(serialized).forEach(key => {
      const value = serialized[key];
      // 检查是否是非Primitive类型且不是null
      if (value !== null && typeof value === 'object' && !(value instanceof Date) && typeof value !== 'string') {
        // 将所有复杂对象序列化为JSON字符串
        try {
          serialized[key] = JSON.stringify(value);
        } catch (e) {
          // 如果序列化失败，设置为字符串表示
          serialized[key] = `[Object: ${value.constructor?.name || 'Unknown'}]`;
        }
      }
    });
    
    return serialized;
  }

  /**
   * 序列化关系数据
   * @param {object} relation - 关系对象
   * @returns {object} 序列化后的关系对象
   */
  function serializeRelation(relation) {
    const serialized = { ...relation };
    
    // 序列化上下文信息
    if (serialized.context && typeof serialized.context === 'object') {
      serialized.context = JSON.stringify(serialized.context);
    }
    
    // 序列化参数信息
    if (serialized.arguments && Array.isArray(serialized.arguments)) {
      serialized.arguments = JSON.stringify(serialized.arguments);
    }
    
    return serialized;
  }

  /**
   * 保存结果到 Neo4j
   */
  async function saveResultsToNeo4j(results, options) {
    if (!options.useNeo4j) {
      console.log('⏭️  跳过 Neo4j 存储');
      return;
    }

    console.log('🗄️  连接 Neo4j 数据库...');
    
    const driver = neo4j.driver(
      options.neo4jUri,
      neo4j.auth.basic(options.neo4jUser, options.neo4jPassword)
    );

    try {
      // 测试连接
      await driver.verifyConnectivity();
      console.log('✅ Neo4j 连接成功');

      const store = new Neo4jEntityStore(driver);
      
      // 创建索引
      console.log('📊 创建数据库索引...');
      await store.createIndexes(options.neo4jDatabase);
      
      // 序列化并存储实体
      if (results.entities.length > 0) {
        console.log(`💾 存储 ${results.entities.length} 个实体...`);
        const serializedEntities = results.entities.map(serializeEntity);
        await store.storeEntities(serializedEntities, options.neo4jDatabase);
      }
      
      // 序列化并存储调用关系
      if (results.relations.length > 0) {
        console.log(`💾 存储 ${results.relations.length} 个关系...`);
        const serializedRelations = results.relations.map(serializeRelation);
        await store.storeCallRelations(serializedRelations, options.neo4jDatabase);
      }
      
      // 存储返回值关系
      console.log('💾 存储返回值关系...');
      const serializedEntities = results.entities.map(serializeEntity);
      await store.storeReturnValueRelations(serializedEntities, options.neo4jDatabase);
      
      // 存储导入导出关系
      if (results.importedEntities.length > 0 || results.exportedEntities.length > 0) {
        console.log('💾 存储导入导出关系...');
        await store.storeImportExportRelations(
          results.importedEntities, 
          results.exportedEntities, 
          options.neo4jDatabase
        );
      }
      
      console.log('✅ 所有数据已成功存储到 Neo4j');
      
    } catch (error) {
      console.error('❌ Neo4j 操作失败:', error.message);
      throw error;
    } finally {
      await driver.close();
    }
  }

/**
 * 打印分析统计信息
 */
function printAnalysisStats(results) {
  console.log('\n📊 分析统计信息');
  console.log('='.repeat(50));
  
  console.log(`📁 文件统计:`);
  console.log(`   - 总文件数: ${results.fileStats.totalFiles}`);
  console.log(`   - 成功分析: ${results.fileStats.successfulFiles}`);
  console.log(`   - 分析失败: ${results.fileStats.failedFiles}`);
  
  console.log(`\n🏗️  实体统计:`);
  console.log(`   - 总实体数: ${results.entities.length}`);
  console.log(`   - 总关系数: ${results.relations.length}`);
  console.log(`   - 导入实体: ${results.importedEntities.length}`);
  console.log(`   - 导出实体: ${results.exportedEntities.length}`);
  
  console.log(`\n⚛️  框架统计:`);
  console.log(`   - React 实体: ${results.stats.react.components}`);
  console.log(`   - Redux 实体: ${results.stats.redux.stores}`);
  console.log(`   - NEJ 实体: ${results.stats.nej.modules}`);
  
  console.log(`\n🔄 返回值统计:`);
  console.log(`   - 总函数数: ${results.returnValueStats.totalFunctions}`);
  console.log(`   - 有返回值: ${results.returnValueStats.functionsWithReturn}`);
  console.log(`   - 返回值类型:`, results.returnValueStats.returnTypes);
  console.log(`   - 赋值使用: ${results.returnValueStats.returnValueUsage.assignments}`);
  console.log(`   - 声明使用: ${results.returnValueStats.returnValueUsage.declarations}`);
  
  console.log('='.repeat(50));
}

/**
 * 主函数
 */
/**
 * 核心分析函数 - 接受选项对象作为参数
 * @param {Object} options - 分析选项
 * @param {string} options.projectPath - 项目路径
 * @param {boolean} [options.saveToFile=false] - 是否保存到文件
 * @param {boolean} [options.useNeo4j=true] - 是否使用Neo4j
 * @param {boolean} [options.verbose=false] - 是否详细输出
 * @param {string} [options.outputDir='./output'] - 输出目录
 * @param {Object} [options.neo4j] - Neo4j配置
 * @returns {Promise<Object>} 分析结果
 */
async function analyzeProject(options) {
  // 验证必需参数
  if (!options || !options.projectPath) {
    throw new Error('缺少必需参数: projectPath');
  }

  // 设置默认值
  const config = {
    saveToFile: false,
    useNeo4j: true,
    verbose: false,
    outputDir: './output',
    neo4jUri: 'bolt://localhost:7687',
    neo4jUser: 'neo4j',
    neo4jPassword: 'fF5SQmjTvDgovryr9UAJxEGFIQHVfjP3WwmP3_Qz4Es',
    neo4jDatabase: 'neo4j',
    ...options
  };
  
  if (config.verbose) {
    console.log('🚀 项目实体分析工具启动');
    console.log('='.repeat(50));
  }
  
  try {
    // 验证项目路径
    validateProjectPath(config.projectPath);
    
    // 获取项目文件
    const files = getProjectFiles(config.projectPath);
    
    if (files.length === 0) {
      throw new Error('没有找到可分析的文件');
    }
    
    if (config.verbose) {
      console.log(`\n🔍 开始分析 ${files.length} 个文件...`);
      console.log('='.repeat(50));
    }
    
    // 分析所有文件
    const analysisPromises = files.map(file => analyzeSingleFile(file, config));
    const analysisResults = await Promise.all(analysisPromises);// 并行执行，减少总执行时间
    
    // 合并结果
    if (config.verbose) {
      console.log('\n🔄 合并分析结果...');
    }
    const mergedResults = mergeAnalysisResults(analysisResults);
    
    // 打印统计信息
    if (config.verbose) {
      printAnalysisStats(mergedResults);
    }
    
    // 保存到本地文件
    if (config.saveToFile) {
      saveResultsToFile(mergedResults, config.outputDir);
    }
    
    // 保存到 Neo4j
    if (config.useNeo4j) {
      await saveResultsToNeo4j(mergedResults, config);
    }
    
    if (config.verbose) {
      console.log('\n✅ 项目分析完成！');
      
      if (config.useNeo4j) {
        console.log('\n🌐 在 Neo4j Browser 中查看结果:');
        console.log(`   1. 打开: http://localhost:7474`);
        console.log(`   2. 切换到数据库: :use ${config.neo4jDatabase}`);
        console.log(`   3. 查看所有实体: MATCH (e:Entity) RETURN e LIMIT 100`);
        console.log(`   4. 查看调用关系: MATCH (a:Entity)-[r:CALLS]->(b:Entity) RETURN a, r, b LIMIT 50`);
      }
    }
    
    return mergedResults;
    
  } catch (error) {
    if (config.verbose) {
      console.error('❌ 程序执行失败:', error.message);
    }
    throw error;
  }
}

/**
 * 命令行入口函数 - 处理命令行参数并调用核心分析函数
 */
async function main() {
  console.log('🚀 项目实体分析工具启动');
  console.log('='.repeat(50));
  
  try {
    // 获取命令行参数
    const options = getCommandLineArgs();
    
    // 调用核心分析函数
    await analyzeProject({ ...options, verbose: true });
    
  } catch (error) {
    console.error('❌ 程序执行失败:', error.message);
    process.exit(1);
  }
}

// 运行主函数
if (require.main === module) {
  main().catch(console.error);
}// 保证当前文件执行而不是被引入执行

module.exports = {
  analyzeProject,        // 导出核心分析函数
  getProjectFiles,
  mergeAnalysisResults,
  saveResultsToFile,
  saveResultsToNeo4j
};
