# Neo4j 实用查询示例

## 🎯 快速开始

### 1. 验证数据存在
```cypher
MATCH (n) RETURN count(n) as Nodes, 
       [(n)-[r]->(m) | count(r)] as Relationships
```

### 2. 查看完整图
```cypher
MATCH (a)-[r:DEPENDS_ON]->(b)
RETURN a, r, b
```

## 📊 数据探索查询

### 查看所有文件及其依赖
```cypher
MATCH (a:File)-[r:DEPENDS_ON]->(b)
RETURN a.file as File, 
       collect({target: b.file, type: r.type}) as Dependencies
```

### 查看依赖层次结构
```cypher
MATCH path = (start:File)-[:DEPENDS_ON*]->(end)
WHERE start.file = 'src/index.js'
RETURN start.file as Start, 
       end.file as End, 
       length(path) as Depth
ORDER BY Depth
```

### 查看特定文件的直接依赖
```cypher
MATCH (a:File {file: 'src/index.js'})-[:DEPENDS_ON]->(b)
RETURN a.file as From, b.file as To, type(r) as Type
```

## 🔍 分析查询

### 最核心的文件（被依赖最多）
```cypher
MATCH (a)-[:DEPENDS_ON]->(b:File)
RETURN b.file as File, 
       count(a) as Dependents
ORDER BY Dependents DESC
```

### 最依赖的文件（依赖其他文件最多）
```cypher
MATCH (a:File)-[:DEPENDS_ON]->(b)
RETURN a.file as File, 
       count(b) as Dependencies
ORDER BY Dependencies DESC
```

### 依赖类型分析
```cypher
MATCH ()-[r:DEPENDS_ON]->()
RETURN r.type as Type, 
       count(r) as Count,
       round(count(r) * 100.0 / size([(n)-[r]->(m) | r]) as Percentage
ORDER BY Count DESC
```

## 🎨 可视化查询

### 完整依赖图
```cypher
MATCH (a)-[r:DEPENDS_ON]->(b)
RETURN a, r, b
```

### 文件依赖图（排除包）
```cypher
MATCH (a:File)-[r:DEPENDS_ON]->(b:File)
RETURN a, r, b
```

### 包依赖图
```cypher
MATCH (a:File)-[r:DEPENDS_ON]->(b:Package)
RETURN a, r, b
```

## 🔧 实用工具查询

### 查找孤立节点（没有依赖关系的文件）
```cypher
MATCH (n:File)
WHERE NOT (n)-[:DEPENDS_ON]->() AND NOT ()-[:DEPENDS_ON]->(n)
RETURN n.file as IsolatedFile
```

### 查找叶子节点（不被其他文件依赖的文件）
```cypher
MATCH (n:File)
WHERE NOT ()-[:DEPENDS_ON]->(n)
RETURN n.file as LeafFile
```

### 查找根节点（不依赖其他文件的文件）
```cypher
MATCH (n:File)
WHERE NOT (n)-[:DEPENDS_ON]->()
RETURN n.file as RootFile
```

### 循环依赖检测
```cypher
MATCH (a)-[:DEPENDS_ON*]->(a)
RETURN a.file as CircularDependency
```

## 📈 统计查询

### 项目依赖统计
```cypher
MATCH (n)
RETURN labels(n) as NodeType, 
       count(n) as Count
UNION
MATCH ()-[r]->()
RETURN type(r) as RelationshipType, 
       count(r) as Count
```

### 文件依赖深度分析
```cypher
MATCH path = (start:File)-[:DEPENDS_ON*]->(end)
RETURN start.file as StartFile, 
       end.file as EndFile, 
       length(path) as Depth
ORDER BY Depth DESC
```

### 模块依赖分析
```cypher
MATCH (a:File)-[r:DEPENDS_ON]->(b:File)
WHERE a.file CONTAINS 'utils' OR b.file CONTAINS 'utils'
RETURN a.file as From, b.file as To, r.type as Type
```

## 🛠️ 维护查询

### 查看数据库信息
```cypher
CALL db.info() YIELD name, version, edition
RETURN name, version, edition
```

### 查看数据库统计
```cypher
CALL db.stats.retrieve('MAPdatabase') YIELD data
RETURN data
```

### 清空数据（谨慎使用）
```cypher
MATCH (n) DETACH DELETE n
```

## 💡 查询技巧

1. **使用LIMIT限制结果数量**:
   ```cypher
   MATCH (a)-[r]->(b) RETURN a, r, b LIMIT 10
   ```

2. **使用WHERE过滤条件**:
   ```cypher
   MATCH (a:File)-[r:DEPENDS_ON]->(b)
   WHERE a.file CONTAINS 'index'
   RETURN a, r, b
   ```

3. **使用ORDER BY排序**:
   ```cypher
   MATCH (a:File)-[r:DEPENDS_ON]->(b)
   RETURN a.file, b.file, r.type
   ORDER BY a.file, b.file
   ```

4. **使用DISTINCT去重**:
   ```cypher
   MATCH (a)-[r:DEPENDS_ON]->(b)
   RETURN DISTINCT a.file as File
   ```

## 🎯 预期结果

执行这些查询后，你应该看到：
- 8个节点（6个文件 + 2个包）
- 8个依赖关系
- 清晰的依赖层次结构
- 不同类型的依赖关系（static, commonjs, dynamic, npm） 