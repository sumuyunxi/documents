# Neo4j 查询指南

## 基础查询

### 1. 查看所有节点
```cypher
MATCH (n) RETURN n
```

### 2. 查看所有关系
```cypher
MATCH (a)-[r]->(b) RETURN a, r, b
```

### 3. 查看文件节点
```cypher
MATCH (n:File) RETURN n
```

### 4. 查看包节点
```cypher
MATCH (n:Package) RETURN n
```

## 依赖关系查询

### 5. 查看文件间的依赖关系
```cypher
MATCH (a:File)-[r:DEPENDS_ON]->(b:File) 
RETURN a.file as From, b.file as To, r.type as Type
```

### 6. 查看文件对包的依赖
```cypher
MATCH (a:File)-[r:DEPENDS_ON]->(b:Package) 
RETURN a.file as File, b.file as Package, r.type as Type
```

### 7. 查看依赖路径
```cypher
MATCH path = (a:File)-[:DEPENDS_ON*]->(b)
WHERE a.file = 'src/index.js'
RETURN path
```

## 统计分析

### 8. 节点类型统计
```cypher
MATCH (n) 
RETURN labels(n) as NodeType, count(n) as Count
```

### 9. 关系类型统计
```cypher
MATCH ()-[r]->() 
RETURN type(r) as RelationshipType, count(r) as Count
```

### 10. 最依赖的文件
```cypher
MATCH (a:File)-[:DEPENDS_ON]->(b)
RETURN a.file as File, count(b) as Dependencies
ORDER BY Dependencies DESC
```

### 11. 最被依赖的文件
```cypher
MATCH (a)-[:DEPENDS_ON]->(b:File)
RETURN b.file as File, count(a) as Dependents
ORDER BY Dependents DESC
```

## 可视化查询

### 12. 完整依赖图（限制50个节点）
```cypher
MATCH (a)-[r:DEPENDS_ON]->(b)
RETURN a, r, b
LIMIT 50
```

### 13. 特定文件的依赖树
```cypher
MATCH path = (start:File {file: 'src/index.js'})-[:DEPENDS_ON*]->(end)
RETURN path
```

### 14. 循环依赖检测
```cypher
MATCH (a)-[:DEPENDS_ON*]->(a)
RETURN a.file as CircularDependency
```

## 清理数据

### 15. 删除所有数据
```cypher
MATCH (n) DETACH DELETE n
```

## 使用提示

1. 在Neo4j Browser中，点击节点可以查看其属性
2. 使用鼠标滚轮可以缩放图
3. 拖拽可以移动节点位置
4. 双击节点可以固定其位置
5. 使用 `LIMIT` 子句可以限制返回的节点数量，提高性能 