# Neo4j 查询示例 - 完整流程演示

## 🚀 快速开始

### 1. 打开Neo4j Browser
访问: `http://localhost:7474`

### 2. 切换到MAPdatabase
```cypher
:use MAPdatabase
```

### 3. 验证数据已导入
```cypher
MATCH (n) RETURN count(n) as NodeCount
```

## 📊 基础查询

### 查看所有节点
```cypher
MATCH (n) RETURN n
```
**结果**: 显示8个节点（6个文件 + 2个包）

### 查看所有关系
```cypher
MATCH (a)-[r]->(b) RETURN a, r, b
```
**结果**: 显示8个依赖关系

### 查看节点类型统计
```cypher
MATCH (n) 
RETURN labels(n) as NodeType, count(n) as Count
```
**预期结果**:
- File: 6
- Package: 2

## 🔗 依赖关系分析

### 查看所有文件依赖
```cypher
MATCH (a:File)-[r:DEPENDS_ON]->(b) 
RETURN a.file as From, b.file as To, r.type as Type
```

### 查看包依赖
```cypher
MATCH (a:File)-[r:DEPENDS_ON]->(b:Package) 
RETURN a.file as File, b.file as Package
```

### 查看特定文件的依赖
```cypher
MATCH (a:File {file: 'src/index.js'})-[:DEPENDS_ON]->(b)
RETURN a.file as From, b.file as To
```

## 🎨 可视化查询

### 完整依赖图
```cypher
MATCH (a)-[r:DEPENDS_ON]->(b)
RETURN a, r, b
```

### 文件依赖图（排除包）
```cypher
MATCH (a:File)-[r:DEPENDS_ON]->(b:File)
RETURN a, r, b
```

### 包依赖图
```cypher
MATCH (a:File)-[r:DEPENDS_ON]->(b:Package)
RETURN a, r, b
```

## 📈 高级分析

### 依赖深度分析
```cypher
MATCH path = (start:File)-[:DEPENDS_ON*]->(end)
RETURN start.file as StartFile, end.file as EndFile, length(path) as Depth
ORDER BY Depth DESC
```

### 最依赖的文件
```cypher
MATCH (a:File)-[:DEPENDS_ON]->(b)
RETURN a.file as File, count(b) as Dependencies
ORDER BY Dependencies DESC
```

### 最被依赖的文件
```cypher
MATCH (a)-[:DEPENDS_ON]->(b:File)
RETURN b.file as File, count(a) as Dependents
ORDER BY Dependents DESC
```

### 循环依赖检测
```cypher
MATCH (a)-[:DEPENDS_ON*]->(a)
RETURN a.file as CircularDependency
```

## 🔍 特定场景查询

### 查看index.js的完整依赖树
```cypher
MATCH path = (start:File {file: 'src/index.js'})-[:DEPENDS_ON*]->(end)
RETURN path
```

### 查看Button组件的依赖
```cypher
MATCH (a:File {file: 'src/components/Button.jsx'})-[:DEPENDS_ON]->(b)
RETURN a.file as From, b.file as To, type(r) as Type
```

### 查看utils模块的被依赖情况
```cypher
MATCH (a)-[:DEPENDS_ON]->(b:File)
WHERE b.file CONTAINS 'utils'
RETURN b.file as UtilsFile, count(a) as Dependents
ORDER BY Dependents DESC
```

## 🛠️ 数据管理

### 查看数据库信息
```cypher
CALL db.info() YIELD name, version, edition
RETURN name, version, edition
```

### 查看数据库统计
```cypher
CALL db.stats.retrieve('MAPdatabase') YIELD data
RETURN data
```

### 清空数据（谨慎使用）
```cypher
MATCH (n) DETACH DELETE n
```

## 💡 使用技巧

1. **性能优化**: 对于大型图，使用 `LIMIT` 子句
2. **可视化设置**: 在Neo4j Browser中可以调整节点颜色和大小
3. **导出数据**: 可以使用 `CALL apoc.export.csv.query()` 导出查询结果
4. **快捷键**: 
   - `Ctrl+Enter`: 执行查询
   - `Ctrl+L`: 清空编辑器
   - `Ctrl+Up/Down`: 浏览历史查询

## 🎯 预期结果

执行完整依赖图查询后，你应该看到：
- 6个文件节点（蓝色）
- 2个包节点（绿色）
- 8个依赖关系（箭头）
- 清晰的依赖层次结构 