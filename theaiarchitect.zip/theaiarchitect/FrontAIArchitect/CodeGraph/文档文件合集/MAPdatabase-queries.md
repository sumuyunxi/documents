# MAPdatabase 查询指南

## 数据库连接信息
- 数据库名称: `MAPdatabase`
- 连接地址: `bolt://localhost:7687`
- 用户名: `neo4j`

## 在Neo4j Browser中查看MAPdatabase

1. 打开Neo4j Browser: `http://localhost:7474`
2. 在浏览器顶部的数据库选择器中，选择 `MAPdatabase`
3. 或者使用命令切换数据库: `:use MAPdatabase`

## 基础查询

### 1. 重连数据库
:use MAPdatabase(数据库名称)

### 1. 查看所有节点
```cypher
MATCH (n) RETURN n
```

### 2. 查看所有关系
```cypher
MATCH (a)-[r]->(b) RETURN a, r, b
```

### 3. 查看文件节点
```cypher
MATCH (n:File) RETURN n
```

### 4. 查看包节点
```cypher
MATCH (n:Package) RETURN n
```

## 依赖关系分析

### 5. 查看所有依赖关系
```cypher
MATCH (a)-[r:DEPENDS_ON]->(b) 
RETURN a.file as From, b.file as To, r.type as Type
```

### 6. 查看文件对包的依赖
```cypher
MATCH (a:File)-[r:DEPENDS_ON]->(b:Package) 
RETURN a.file as File, b.file as Package
```

### 7. 查看特定文件的依赖
```cypher
MATCH (a:File {file: 'src/index.js'})-[:DEPENDS_ON]->(b)
RETURN a.file as From, b.file as To
```

## 统计分析

### 8. 节点统计
```cypher
MATCH (n) 
RETURN labels(n) as NodeType, count(n) as Count
```

### 9. 关系统计
```cypher
MATCH ()-[r]->() 
RETURN type(r) as RelationshipType, count(r) as Count
```

### 10. 依赖深度分析
```cypher
MATCH path = (start:File)-[:DEPENDS_ON*]->(end)
RETURN start.file as StartFile, end.file as EndFile, length(path) as Depth
ORDER BY Depth DESC
```

## 可视化查询

### 11. 完整依赖图
```cypher
MATCH (a)-[r:DEPENDS_ON]->(b)
RETURN a, r, b
```

### 12. 特定文件的依赖树
```cypher
MATCH path = (start:File {file: 'src/index.js'})-[:DEPENDS_ON*]->(end)
RETURN path
```

### 13. 包依赖可视化
```cypher
MATCH (a:File)-[r:DEPENDS_ON]->(b:Package)
RETURN a, r, b
```

## 高级分析

### 14. 循环依赖检测
```cypher
MATCH (a)-[:DEPENDS_ON*]->(a)
RETURN a.file as CircularDependency
```

### 15. 最核心的文件（被依赖最多的）
```cypher
MATCH (a)-[:DEPENDS_ON]->(b:File)
RETURN b.file as File, count(a) as Dependents
ORDER BY Dependents DESC
```

### 16. 最依赖其他文件的文件
```cypher
MATCH (a:File)-[:DEPENDS_ON]->(b)
RETURN a.file as File, count(b) as Dependencies
ORDER BY Dependencies DESC
```

## 数据管理

### 17. 查看数据库信息
```cypher
CALL db.info() YIELD name, version, edition
RETURN name, version, edition
```

### 18. 清空数据库（谨慎使用）
```cypher
MATCH (n) DETACH DELETE n
```

### 19. 查看数据库统计
```cypher
CALL db.stats.retrieve('MAPdatabase') YIELD data
RETURN data
```

## 使用技巧

1. **切换数据库**: 在Neo4j Browser中使用 `:use MAPdatabase`
2. **查看数据库列表**: 使用 `:dbs` 命令
3. **性能优化**: 对于大型图，使用 `LIMIT` 子句
4. **可视化设置**: 在Neo4j Browser中可以调整节点颜色和大小
5. **导出数据**: 可以使用 `CALL apoc.export.csv.query()` 导出查询结果

## 常用快捷键

- `Ctrl+Enter`: 执行查询
- `Ctrl+Shift+Enter`: 执行多行查询
- `Ctrl+L`: 清空编辑器
- `Ctrl+Up/Down`: 浏览历史查询 