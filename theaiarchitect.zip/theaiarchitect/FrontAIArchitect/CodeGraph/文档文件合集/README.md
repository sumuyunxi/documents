# 代码依赖图生成与分析工具

这是一个用于分析JavaScript/TypeScript项目依赖关系并生成可视化图表的工具集。通过解析代码文件，提取依赖关系，并将结果存储到Neo4j图数据库中，实现代码结构的可视化分析。

## 📁 项目结构

### 🔧 核心脚本文件

#### 图构建脚本
- **`build-graph.js`** - 原始图构建脚本，支持MongoDB存储AST数据
- **`build-graph-simple.js`** - 简化版图构建脚本，只生成图数据，不使用MongoDB
- **`build-graph-any-project.js`** - 通用项目分析脚本，支持分析任意路径的项目
- **`build-graph-all-files.js`** - 全文件类型分析脚本，支持分析所有类型的文件

#### 数据存储脚本
- **`save-to-neo4j.js`** - 将JSON数据保存到Neo4j数据库的脚本

#### 验证和调试脚本
- **`test-neo4j-data.js`** - Neo4j数据验证脚本，检查数据是否正确导入
- **`debug-neo4j.js`** - 详细的Neo4j诊断脚本，用于排查问题
- **`verify-neo4j.js`** - 简化的Neo4j验证脚本

#### 可视化脚本
- **`visualize-graph.js`** - 在控制台显示图结构统计信息的脚本

#### MongoDB相关脚本
- **`view-mongo.js`** - 查看MongoDB中存储的AST数据
- **`mongo-test.js`** - MongoDB连接测试脚本

### 📚 文档文件

#### 查询指南
- **`neo4j-queries.md`** - 基础Neo4j查询指南
- **`MAPdatabase-queries.md`** - 专门针对MAPdatabase数据库的查询指南
- **`neo4j-queries-examples.md`** - Neo4j查询示例和完整流程演示
- **`neo4j-queries-practical.md`** - 实用的Neo4j查询示例

#### 使用指南
- **`项目分析指南.md`** - 项目依赖图分析的完整使用指南
- **`代码图生成技术方案.md`** - 百万级前端项目代码图生成技术方案文档

### 📦 配置文件
- **`package.json`** - 项目依赖配置
- **`package-lock.json`** - 依赖锁定文件

### 📂 数据目录
- **`output/`** - 输出数据目录
  - `nodes.json` - 节点数据文件
  - `edges.json` - 边数据文件

### 🗂️ 示例代码
- **`src/`** - 示例源代码目录
  - `index.js` - 主入口文件
  - `components/` - React组件目录
  - `services/` - 服务层目录
  - `utils/` - 工具函数目录
  - `legacy/` - 遗留代码目录

## 🚀 快速开始

### 1. 安装依赖
```bash
npm install
```

### 2. 启动Neo4j数据库
确保Neo4j Desktop正在运行，并创建了名为`MAPdatabase`的数据库。

### 3. 分析项目
```bash
# 分析当前目录的项目
node build-graph-any-project.js

# 分析指定路径的项目
node build-graph-any-project.js "C:\path\to\your\project"

# 分析所有文件类型（推荐用于完整项目分析）
node build-graph-all-files.js

# 分析指定路径的所有文件类型
node build-graph-all-files.js "C:\path\to\your\project"
```

### 4. 查看结果
1. 打开Neo4j Browser: `http://localhost:7474`
2. 切换到MAPdatabase: `:use MAPdatabase`
3. 查看完整图: `MATCH (a)-[r:DEPENDS_ON]->(b) RETURN a, r, b`
4. 查看文件类型统计: `MATCH (n:File) RETURN n.fileType, count(n) ORDER BY count(n) DESC`

## 🛠️ 脚本详细说明

### 图构建脚本

#### `build-graph.js`
- **功能**: 完整的图构建流程，包含AST解析和MongoDB存储
- **特点**: 支持存储完整的AST数据，适合深度代码分析
- **输出**: JSON文件 + MongoDB + Neo4j

#### `build-graph-simple.js`
- **功能**: 简化版图构建，只生成依赖关系图
- **特点**: 不依赖MongoDB，更轻量级
- **输出**: JSON文件 + Neo4j

#### `build-graph-any-project.js`
- **功能**: 通用项目分析工具
- **特点**: 支持任意项目路径，自动排除无关目录
- **输出**: JSON文件 + Neo4j

#### `build-graph-all-files.js`
- **功能**: 全文件类型分析工具
- **特点**: 支持80+种文件类型，包含文件类型分类和统计
- **输出**: JSON文件 + Neo4j + 文件类型统计

### 数据存储脚本

#### `save-to-neo4j.js`
- **功能**: 将JSON数据导入到Neo4j数据库
- **特点**: 自动处理节点标签和关系类型
- **使用**: 在生成JSON文件后运行

### 验证脚本

#### `test-neo4j-data.js`
- **功能**: 验证Neo4j中的数据完整性
- **输出**: 显示节点数量、关系数量、依赖类型统计

#### `debug-neo4j.js`
- **功能**: 详细的Neo4j诊断工具
- **输出**: 详细的节点和关系信息，用于排查问题

#### `verify-neo4j.js`
- **功能**: 简化的数据验证
- **输出**: 基本统计信息和关系详情

### 可视化脚本

#### `visualize-graph.js`
- **功能**: 在控制台显示图结构统计
- **输出**: 节点类型分布、关系类型分布、依赖关系列表

### MongoDB脚本

#### `view-mongo.js`
- **功能**: 查看MongoDB中存储的AST数据
- **用途**: 调试AST解析结果

#### `mongo-test.js`
- **功能**: 测试MongoDB连接
- **用途**: 验证数据库连接配置

## 📊 支持的文件类型

### 基础脚本支持
- `.js` - JavaScript文件
- `.jsx` - React JSX文件
- `.ts` - TypeScript文件
- `.tsx` - TypeScript React文件
- `.json` - JSON配置文件

### 全文件类型脚本支持（`build-graph-all-files.js`）
支持80+种文件类型，包括：

#### 编程语言
- **前端**: `.js`, `.jsx`, `.ts`, `.tsx`, `.vue`, `.svelte`
- **后端**: `.py`, `.java`, `.cpp`, `.c`, `.cs`, `.go`, `.rs`, `.php`, `.rb`
- **移动端**: `.swift`, `.kt`, `.dart`
- **其他**: `.scala`, `.r`, `.m`, `.pl`, `.sh`

#### 标记语言和样式
- **标记**: `.html`, `.xml`, `.md`
- **样式**: `.css`, `.scss`, `.sass`, `.less`

#### 配置文件
- **配置**: `.json`, `.yml`, `.yaml`, `.toml`, `.ini`, `.cfg`
- **环境**: `.env`, `.env.local`, `.env.production`
- **Git**: `.gitignore`, `.gitattributes`
- **Docker**: `.dockerfile`, `.dockerignore`

#### 媒体文件
- **图片**: `.png`, `.jpg`, `.jpeg`, `.gif`, `.svg`, `.ico`, `.webp`
- **音频**: `.mp3`, `.wav`, `.ogg`, `.flac`
- **视频**: `.mp4`, `.avi`, `.mov`, `.wmv`, `.flv`
- **字体**: `.woff`, `.woff2`, `.ttf`, `.eot`, `.otf`

#### 文档和数据
- **文档**: `.txt`, `.log`, `.pdf`, `.doc`, `.docx`, `.xls`, `.xlsx`
- **数据**: `.csv`, `.tsv`, `.xml`, `.json`, `.yaml`
- **压缩**: `.zip`, `.tar`, `.gz`, `.rar`, `.7z`

## 🔍 自动排除的目录

- `node_modules/` - npm包
- `dist/` - 构建输出
- `build/` - 构建输出
- `.git/` - Git仓库
- `coverage/` - 测试覆盖率

## 🎯 主要功能

### 依赖分析
- 静态导入 (`import` 语句)
- 动态导入 (`import()` 函数)
- CommonJS (`require()` 调用)
- 相对路径解析
- npm包依赖识别

### 图数据库存储
- 节点: 文件节点和包节点
- 关系: 依赖关系，包含类型信息
- 标签: File和Package标签
- 属性: 文件路径、依赖类型、文件类型等

### 可视化查询
- 完整依赖图查看
- 文件间依赖分析
- 包依赖分析
- 文件类型统计
- 依赖统计和报告

## 💡 使用场景

### 代码重构
- 识别高度耦合的模块
- 发现循环依赖
- 分析模块间依赖关系

### 架构分析
- 理解项目结构
- 识别核心模块
- 分析依赖层次

### 性能优化
- 识别大型依赖
- 分析影响范围
- 优化导入路径

## 🔧 配置选项

### Neo4j连接配置
```javascript
const NEO4J_URI = 'bolt://localhost:7687';
const NEO4J_USER = 'neo4j';
const NEO4J_PASS = 'your-password';
```

### 文件模式配置
```javascript
const patterns = [
  '**/*.{js,jsx,ts,tsx}',
  '!node_modules/**',
  '!dist/**',
  '!build/**',
  '!.git/**',
  '!coverage/**'
];
```

## 📈 性能特点

- **并行处理**: 支持多线程文件解析
- **流式处理**: 避免内存溢出
- **按需加载**: 支持大型项目分析
- **增量更新**: 支持数据更新和重新分析

## ⚠️ 注意事项

1. **确保Neo4j正在运行**
2. **检查数据库连接配置**
3. **大型项目可能需要较长时间**
4. **某些复杂的依赖可能无法解析**
5. **建议在项目根目录运行脚本**

## 🎯 预期结果

分析完成后，你将获得：
- 完整的项目依赖图
- 文件间的依赖关系
- npm包的依赖关系
- 文件类型统计和分类
- 依赖类型统计
- 可视化展示

## 📚 相关文档

- [项目分析指南](项目分析指南.md) - 详细的使用指南
- [Neo4j查询示例](neo4j-queries-examples.md) - 查询示例和技巧
- [技术方案文档](代码图生成技术方案.md) - 技术实现细节

## 🤝 贡献

欢迎提交Issue和Pull Request来改进这个工具！

## �� 许可证

MIT License 