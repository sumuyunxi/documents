package com.aiarchitect.core.analyzer.javaparser;

import com.aiarchitect.core.AnalysisConfig;
import com.aiarchitect.model.analysis.FileAnalysisResult;
import com.aiarchitect.model.dependency.BaseDependencyInfo;
import com.alibaba.fastjson2.JSONObject;

import java.nio.file.Path;
import java.nio.file.Paths;

public class ValidationTest {
    public static void main(String[] args) {
        try {

            // 测试我们的实现
            JavaAstCodeAnalyzerImpl analyzer = new JavaAstCodeAnalyzerImpl();
            AnalysisConfig config = new AnalysisConfig();
            
            // 创建专门的import测试文件
            // /Users/wq/Git/pri-infra/theaiarchitect/AiArchitect/src/main/java/com/aiarchitect/service/FileAnalysisService.java
            Path testDir = Paths.get("/Users/wq/Git/pri-infra/theaiarchitect/AiArchitect/src/main/java/com/aiarchitect/service/FileAnalysisService.java");
            
            // 测试专门的import文件
            FileAnalysisResult result = analyzer.analyzeFile(testDir, config);

            int simpleImportCount = 0;
            int wildcardImportCount = 0;
            int inheritanceCount = 0;
            
            for (BaseDependencyInfo dependency : result.getDependencies()) {
                String depType = dependency.getDependencyType() != null ? dependency.getDependencyType().toString() : "UNKNOWN";
                if (depType.contains("WILDCARD")) {
                    wildcardImportCount++;
                    System.out.printf( depType + " Import #%d: %s\n", wildcardImportCount, dependency.getFullyQualifiedName());
                } else if (depType.contains("INHERITANCE")) {
                    inheritanceCount++;
                    System.out.printf("Inheritance Import #%d: %s (Context: %s)\n", inheritanceCount, dependency.getFullyQualifiedName(), dependency.getUsageContext());
                } else {
                    simpleImportCount++;
                    System.out.printf(depType + " Import #%d: %s\n", simpleImportCount, dependency.getFullyQualifiedName());
                }
            }

            result.setDependencies(null);
            System.out.println(JSONObject.toJSONString(result));

        } catch (Exception e) {
            System.out.println("❌ 验证失败: " + e.getMessage());
        }
    }
}
