package com.aiarchitect.service;

import com.aiarchitect.core.progress.AnalysisException;
import com.aiarchitect.model.analysis.ProjectAnalysisResult;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
public class ProjectAnalysisServiceTest {

    @Autowired
    private ProjectAnalysisService projectAnalysisService;

    @Test
    public void testValidateProjectPath() {
        // 测试空路径
        assertThrows(AnalysisException.class, () -> {
            projectAnalysisService.analyzeProject("", "test", "main");
        });

        // 测试null路径
        assertThrows(AnalysisException.class, () -> {
            projectAnalysisService.analyzeProject(null, "test", "main");
        });

        // 测试不存在的路径
        assertThrows(AnalysisException.class, () -> {
            projectAnalysisService.analyzeProject("/non/existent/path", "test", "main");
        });
    }

    @Test
    public void testProjectAnalysisResultInitialization() {
        ProjectAnalysisResult result = new ProjectAnalysisResult();
        result.setProjectPath("/test/path");
        result.setProjectKey("test-project");
        result.setBranch("main");
        result.startAnalysis();

        assertEquals("RUNNING", result.getStatus());
        assertEquals("/test/path", result.getProjectPath());
        assertEquals("test-project", result.getProjectKey());
        assertEquals("main", result.getBranch());
        assertNotNull(result.getAnalysisStartTime());
        assertEquals(0.0, result.getProgressPercentage());
    }

    @Test
    public void testProjectAnalysisResultProgress() {
        ProjectAnalysisResult result = new ProjectAnalysisResult();
        result.setTotalFileCount(10);
        result.startAnalysis();

        // 模拟文件分析成功
        result.recordFileSuccess(createMockFileResult());
        assertEquals(1, result.getProcessedFiles().get());
        assertEquals(1, result.getSuccessFiles().get());
        assertEquals(0, result.getFailedFiles().get());
        assertEquals(10.0, result.getProgressPercentage());

        // 模拟文件分析失败
        result.recordFileFailure("/test/file2.java", "Test error");
        assertEquals(2, result.getProcessedFiles().get());
        assertEquals(1, result.getSuccessFiles().get());
        assertEquals(1, result.getFailedFiles().get());
        assertEquals(20.0, result.getProgressPercentage());
    }

    @Test
    public void testProjectAnalysisCompletion() {
        ProjectAnalysisResult result = new ProjectAnalysisResult();
        result.setTotalFileCount(5);
        result.startAnalysis();

        // 模拟分析完成
        for (int i = 0; i < 5; i++) {
            result.recordFileSuccess(createMockFileResult());
        }

        result.completeAnalysis();

        assertEquals("COMPLETED", result.getStatus());
        assertEquals(100.0, result.getProgressPercentage());
        assertNotNull(result.getAnalysisEndTime());
        assertNotNull(result.getTotalAnalysisTimeMs());
    }

    @Test
    public void testProjectAnalysisFailure() {
        ProjectAnalysisResult result = new ProjectAnalysisResult();
        result.startAnalysis();

        result.markAsFailed("Test error message");

        assertEquals("FAILED", result.getStatus());
        assertEquals("Test error message", result.getErrorMessage());
        assertNotNull(result.getAnalysisEndTime());
    }

    @Test
    public void testProjectAnalysisCancellation() {
        ProjectAnalysisResult result = new ProjectAnalysisResult();
        result.startAnalysis();

        result.markAsCancelled();

        assertEquals("CANCELLED", result.getStatus());
        assertNotNull(result.getAnalysisEndTime());
    }

    @Test
    public void testTaskManagement() {
        // 测试任务状态管理
        assertNotNull(projectAnalysisService.getAllTaskStatus());
        
        // 清理任务
        projectAnalysisService.cleanupCompletedTasks();
        
        // 验证清理后的状态
        assertTrue(projectAnalysisService.getAllTaskStatus().isEmpty() || 
                  projectAnalysisService.getAllTaskStatus().values().stream()
                      .allMatch(task -> "RUNNING".equals(task.getStatus())));
    }

    private com.aiarchitect.model.analysis.FileAnalysisResult createMockFileResult() {
        com.aiarchitect.model.analysis.FileAnalysisResult fileResult = 
            new com.aiarchitect.model.analysis.FileAnalysisResult();
        fileResult.setFileName("TestFile.java");
        fileResult.setDependencyCount(5);
        fileResult.setErrorCount(0);
        fileResult.setLineCount(100);
        fileResult.setFileSize(2048L);
        
        // 模拟类名集合
        java.util.Set<String> classNames = new java.util.HashSet<>();
        classNames.add("TestClass");
        classNames.add("InnerClass");
        fileResult.setAllClassNames(classNames);
        
        return fileResult;
    }
}
