package com.aiarchitect.model.analysis;

import com.aiarchitect.model.dependency.BaseDependencyInfo;
import com.aiarchitect.util.JsonUtil;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@Data
public class FileAnalysisResult {
    // 基础文件信息
    private Long id;                                    // 主键ID
    private String filePath;                        // 相对路径
    private String fileName;                        // 文件名
    private String packageName;                     // 包名
    private String mainClassName;                   // 主类名
    private ClassType classType;
    
    // 分析元数据
    private LocalDateTime analysisTime;             // 分析时间
    private String analyzerVersion;                 // 分析器版本
    private Long fileSize;                          // 文件大小
    private Integer lineCount;                      // 代码行数

    // 性能指标
    private Long parseTimeMs;                       // 解析耗时
    private Long extractTimeMs;                     // 提取耗时
    private Long allResolveTimeMs;                  // 解析耗时
    private Long maxMemoryUsed;                     // 峰值内存
    
    // 版本控制
    private String checksum;                        // 文件校验和
    private String version;                        // 结果版本号
    
    // 业务字段
    private Integer dependencyCount;               // 依赖数量
    private Integer errorCount;                    // 错误数量
    private String projectKey;                     // 项目标识
    private String branch;                         // 分支名称
    private LocalDateTime createdAt;               // 创建时间
    private LocalDateTime updatedAt;               // 更新时间
    
    // 非数据库字段
    private Set<String> allClassNames;              // 所有类名, 子类
    private List<BaseDependencyInfo> dependencies;  // 所有其他依赖
    private List<AnalysisError> errors;             // 错误列表
}