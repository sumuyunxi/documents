package com.aiarchitect.mapper;

import com.aiarchitect.model.analysis.ProjectAnalysisResult;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ProjectAnalysisResultMapper {
    
    /**
     * 插入项目分析结果
     */
    int insert(ProjectAnalysisResult projectAnalysisResult);
    
    /**
     * 根据ID查找项目分析结果
     */
    ProjectAnalysisResult findById(Long id);
    
    /**
     * 根据项目路径和项目标识查找分析结果
     */
    ProjectAnalysisResult findByProjectPathAndKey(@Param("projectPath") String projectPath, 
                                                 @Param("projectKey") String projectKey, 
                                                 @Param("branch") String branch);
    
    /**
     * 根据项目标识和分支查找所有分析结果
     */
    List<ProjectAnalysisResult> findByProjectAndBranch(@Param("projectKey") String projectKey, 
                                                      @Param("branch") String branch);
    
    /**
     * 查找最近的项目分析结果
     */
    List<ProjectAnalysisResult> findRecentAnalysis(@Param("limit") int limit);
    
    /**
     * 根据状态查找项目分析结果
     */
    List<ProjectAnalysisResult> findByStatus(@Param("status") String status);
    
    /**
     * 更新项目分析结果
     */
    int update(ProjectAnalysisResult projectAnalysisResult);
    
    /**
     * 根据ID删除项目分析结果
     */
    int deleteById(Long id);
    
    /**
     * 根据项目标识和分支删除分析结果
     */
    int deleteByProjectAndBranch(@Param("projectKey") String projectKey, @Param("branch") String branch);
    
    /**
     * 删除指定时间之前的分析结果
     */
    int deleteOldAnalysis(@Param("beforeDate") String beforeDate);
    
    /**
     * 统计项目分析结果数量
     */
    int countByProjectAndBranch(@Param("projectKey") String projectKey, @Param("branch") String branch);
    
    /**
     * 获取项目分析统计信息
     */
    ProjectAnalysisStats getProjectAnalysisStats(@Param("projectKey") String projectKey, 
                                               @Param("branch") String branch);
    
    /**
     * 项目分析统计信息内部类
     */
    class ProjectAnalysisStats {
        private String projectKey;
        private String branch;
        private Integer totalAnalysisCount;
        private Integer successAnalysisCount;
        private Integer failedAnalysisCount;
        private Long avgAnalysisTimeMs;
        private Integer avgFileCount;
        private Integer avgDependencyCount;
        private String lastAnalysisTime;
        
        // Getters and Setters
        public String getProjectKey() { return projectKey; }
        public void setProjectKey(String projectKey) { this.projectKey = projectKey; }
        
        public String getBranch() { return branch; }
        public void setBranch(String branch) { this.branch = branch; }
        
        public Integer getTotalAnalysisCount() { return totalAnalysisCount; }
        public void setTotalAnalysisCount(Integer totalAnalysisCount) { this.totalAnalysisCount = totalAnalysisCount; }
        
        public Integer getSuccessAnalysisCount() { return successAnalysisCount; }
        public void setSuccessAnalysisCount(Integer successAnalysisCount) { this.successAnalysisCount = successAnalysisCount; }
        
        public Integer getFailedAnalysisCount() { return failedAnalysisCount; }
        public void setFailedAnalysisCount(Integer failedAnalysisCount) { this.failedAnalysisCount = failedAnalysisCount; }
        
        public Long getAvgAnalysisTimeMs() { return avgAnalysisTimeMs; }
        public void setAvgAnalysisTimeMs(Long avgAnalysisTimeMs) { this.avgAnalysisTimeMs = avgAnalysisTimeMs; }
        
        public Integer getAvgFileCount() { return avgFileCount; }
        public void setAvgFileCount(Integer avgFileCount) { this.avgFileCount = avgFileCount; }
        
        public Integer getAvgDependencyCount() { return avgDependencyCount; }
        public void setAvgDependencyCount(Integer avgDependencyCount) { this.avgDependencyCount = avgDependencyCount; }
        
        public String getLastAnalysisTime() { return lastAnalysisTime; }
        public void setLastAnalysisTime(String lastAnalysisTime) { this.lastAnalysisTime = lastAnalysisTime; }
    }
}
