package com.aiarchitect.model.dependency;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public abstract class BaseDependencyInfo {
    // 数据库主键
    private Long id;                                    // 主键ID
    private Long fileAnalysisId;                       // 关联的文件分析结果ID
    
    // 依赖基础信息
    private String className;                       // 依赖类名
    private String packageName;                     // 依赖包名
    private String fullyQualifiedName;              // 完全限定名
    private String sourceCode;
    
    private String filePath;
    private Integer startLine;
    private Integer endLine;
    
    // 分析信息
    private DependencyType dependencyType;          // 依赖类型
    private Double confidence;                      // 置信度 0-1
    private String usageContext;                    // 使用上下文
    private String resolvedFrom;                    // 解析来源
    
    private String extractorVersion;                // 提取器版本
    
    // 业务字段
    private String projectKey;                     // 项目标识
    private String branch;                         // 分支名称
    private LocalDateTime createdAt;               // 创建时间
    private LocalDateTime updatedAt;               // 更新时间
    
    // 子类型标识
    private String dependencySubType;              // 依赖子类型，用于区分具体实现
    
    // 扩展字段，存储子类型特定属性的JSON
    private String extensionData;                  // 扩展数据JSON
    
    public abstract String getDependencySubType();
}