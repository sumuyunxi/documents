package com.aiarchitect.model.analysis;

public enum ClassType {
    CLASS,                // 普通类
    INTERFACE,            // 接口
    ENUM,                 // 枚举
    ANNOTATION,           // 注解
    INNER_CLASS
}