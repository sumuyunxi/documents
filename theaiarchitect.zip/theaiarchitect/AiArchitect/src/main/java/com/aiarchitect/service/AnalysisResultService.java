package com.aiarchitect.service;

import com.aiarchitect.mapper.FileAnalysisResultMapper;
import com.aiarchitect.mapper.BaseDependencyInfoMapper;
import com.aiarchitect.model.analysis.FileAnalysisResult;
import com.aiarchitect.model.dependency.BaseDependencyInfo;
import com.aiarchitect.model.dependency.subtype.*;
import com.aiarchitect.util.JsonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AnalysisResultService {
    
    @Autowired
    private FileAnalysisResultMapper fileAnalysisResultMapper;
    
    @Autowired
    private BaseDependencyInfoMapper baseDependencyInfoMapper;
    
    @Transactional
    public void saveAnalysisResult(FileAnalysisResult result) {
        // 设置创建和更新时间
        result.setCreatedAt(LocalDateTime.now());
        result.setUpdatedAt(LocalDateTime.now());
        
        // 保存文件分析结果
        fileAnalysisResultMapper.insert(result);
        
        // 保存依赖信息
        if (result.getDependencies() != null) {
            result.setDependencyCount(result.getDependencies().size());
            
            for (BaseDependencyInfo dependency : result.getDependencies()) {
                dependency.setFileAnalysisId(result.getId());
                dependency.setProjectKey(result.getProjectKey());
                dependency.setBranch(result.getBranch());
                dependency.setCreatedAt(LocalDateTime.now());
                dependency.setUpdatedAt(LocalDateTime.now());
                
                // 设置扩展数据
                setExtensionData(dependency);

                // 根据子类型插入
                baseDependencyInfoMapper.insert(dependency);
            }
        }
        
        // 保存错误信息（如果有的话）
        if (result.getErrors() != null) {
            result.setErrorCount(result.getErrors().size());
            // TODO: 实现错误信息的保存
        }
    }
    
    @Transactional
    public FileAnalysisResult getAnalysisResult(Long id) {
        FileAnalysisResult result = fileAnalysisResultMapper.findById(id);
        if (result != null) {
            List<BaseDependencyInfo> dependencies = baseDependencyInfoMapper.findByFileAnalysisId(id);
            result.setDependencies(dependencies);
        }
        return result;
    }
    
    @Transactional
    public List<FileAnalysisResult> getAnalysisResultsByProject(String projectKey, String branch) {
        return fileAnalysisResultMapper.findByProjectAndBranch(projectKey, branch);
    }
    
    @Transactional
    public void deleteAnalysisResultsByProject(String projectKey, String branch) {
        baseDependencyInfoMapper.deleteByProjectAndBranch(projectKey, branch);
        fileAnalysisResultMapper.deleteByProjectAndBranch(projectKey, branch);
    }
    
    private void setExtensionData(BaseDependencyInfo dependency) {
        // 根据子类型设置扩展数据
        switch (dependency.getDependencySubType()) {
            case "GENERIC":
                setGenericExtensionData((GenericDependency) dependency);
                break;
            case "REFLECTION":
                setReflectionExtensionData((ReflectionDependency) dependency);
                break;
            case "IMPORT":
                setImportExtensionData((ImportDependency) dependency);
                break;
            case "FULL_NAME_CALL":
                // FullNameCallDependency没有额外字段
                break;
            case "INHERITANCE_IMPORT":
                setInheritanceImportExtensionData((InheritanceImportDependency) dependency);
                break;
            case "SAME_PACK":
                // SamePackDependency没有额外字段
                break;
            case "WILDCARD_IMPORT":
                setWildcardImportExtensionData((WildcardImportDependency) dependency);
                break;
        }
    }
    
    private void setGenericExtensionData(GenericDependency dependency) {
        // 只序列化额外字段
        GenericExtensionData extensionData = new GenericExtensionData();
        extensionData.setContainerType(dependency.getContainerType());
        extensionData.setNestedLevel(dependency.getNestedLevel());
        extensionData.setWildcardBound(dependency.getWildcardBound());
        extensionData.setTypeParameters(dependency.getTypeParameters());
        dependency.setExtensionData(JsonUtil.toJson(extensionData));
    }
    
    private void setReflectionExtensionData(ReflectionDependency dependency) {
        // 只序列化额外字段
        ReflectionExtensionData extensionData = new ReflectionExtensionData();
        extensionData.setMethodName(dependency.getMethodName());
        extensionData.setTargetExpression(dependency.getTargetExpression());
        extensionData.setReflectionType(dependency.getReflectionType());
        extensionData.setStringLiteral(dependency.getStringLiteral());
        dependency.setExtensionData(JsonUtil.toJson(extensionData));
    }
    
    private void setImportExtensionData(ImportDependency dependency) {
        // 只序列化额外字段
        ImportExtensionData extensionData = new ImportExtensionData();
        extensionData.setStatic(dependency.isStatic());
        extensionData.setSamePackage(dependency.isSamePackage());
        dependency.setExtensionData(JsonUtil.toJson(extensionData));
    }
    
    private void setInheritanceImportExtensionData(InheritanceImportDependency dependency) {
        // 只序列化额外字段
        InheritanceImportExtensionData extensionData = new InheritanceImportExtensionData();
        extensionData.setProcessed(dependency.isProcessed());
        dependency.setExtensionData(JsonUtil.toJson(extensionData));
    }
    
    private void setWildcardImportExtensionData(WildcardImportDependency dependency) {
        // 只序列化额外字段
        WildcardImportExtensionData extensionData = new WildcardImportExtensionData();
        extensionData.setProcessed(dependency.isProcessed());
        dependency.setExtensionData(JsonUtil.toJson(extensionData));
    }
    
    // 扩展数据类定义
    static class GenericExtensionData {
        private String containerType;
        private Integer nestedLevel;
        private String wildcardBound;
        private List<String> typeParameters;
        
        public String getContainerType() { return containerType; }
        public void setContainerType(String containerType) { this.containerType = containerType; }
        public Integer getNestedLevel() { return nestedLevel; }
        public void setNestedLevel(Integer nestedLevel) { this.nestedLevel = nestedLevel; }
        public String getWildcardBound() { return wildcardBound; }
        public void setWildcardBound(String wildcardBound) { this.wildcardBound = wildcardBound; }
        public List<String> getTypeParameters() { return typeParameters; }
        public void setTypeParameters(List<String> typeParameters) { this.typeParameters = typeParameters; }
    }
    
    static class ReflectionExtensionData {
        private String methodName;
        private String targetExpression;
        private ReflectionDependency.ReflectionType reflectionType;
        private String stringLiteral;
        
        public String getMethodName() { return methodName; }
        public void setMethodName(String methodName) { this.methodName = methodName; }
        public String getTargetExpression() { return targetExpression; }
        public void setTargetExpression(String targetExpression) { this.targetExpression = targetExpression; }
        public ReflectionDependency.ReflectionType getReflectionType() { return reflectionType; }
        public void setReflectionType(ReflectionDependency.ReflectionType reflectionType) { this.reflectionType = reflectionType; }
        public String getStringLiteral() { return stringLiteral; }
        public void setStringLiteral(String stringLiteral) { this.stringLiteral = stringLiteral; }
    }
    
    static class ImportExtensionData {
        private boolean isStatic;
        private boolean isSamePackage;
        
        public boolean isStatic() { return isStatic; }
        public void setStatic(boolean isStatic) { this.isStatic = isStatic; }
        public boolean isSamePackage() { return isSamePackage; }
        public void setSamePackage(boolean isSamePackage) { this.isSamePackage = isSamePackage; }
    }
    
    static class InheritanceImportExtensionData {
        private boolean processed;
        
        public boolean isProcessed() { return processed; }
        public void setProcessed(boolean processed) { this.processed = processed; }
    }
    
    static class WildcardImportExtensionData {
        private boolean processed;
        
        public boolean isProcessed() { return processed; }
        public void setProcessed(boolean processed) { this.processed = processed; }
    }
}