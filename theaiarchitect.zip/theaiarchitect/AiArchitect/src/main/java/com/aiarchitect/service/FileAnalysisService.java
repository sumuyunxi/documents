package com.aiarchitect.service;

import com.aiarchitect.core.*;
import com.aiarchitect.core.CodeFileAnalyzer;
import com.aiarchitect.core.progress.AnalysisException;
import com.aiarchitect.model.analysis.FileAnalysisResult;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@Service
@Slf4j
public class FileAnalysisService {

    @Autowired
    private CodeFileAnalyzer codeFileAnalyzer;

    @Autowired
    private AnalysisResultService analysisResultService;

    // 存储异步任务状态
    private final ConcurrentMap<String, AnalysisTask> taskMap = new ConcurrentHashMap<>();

    /**
     * 分析单个文件
     */
    public FileAnalysisResult analyzeFile(String filePath, String projectKey, String branch) {

        try {
            validateFile(filePath);

            Path path = Paths.get(filePath);
            AnalysisConfig config = createAnalysisConfig(projectKey);

            FileAnalysisResult result = codeFileAnalyzer.analyzeFile(path, config);

            // 设置项目信息
            result.setProjectKey(projectKey);
            result.setBranch(branch);
            result.setFilePath(filePath);

            // 保存结果
            analysisResultService.saveAnalysisResult(result);

            return result;
        } catch (Exception e) {
            log.error("文件分析失败: {}", filePath, e);
            return null;
        }
    }

    /**
     * 异步分析文件
     */
    public String analyzeFileAsync(String filePath, String projectKey, String branch) throws AnalysisException {
        validateFile(filePath);
        
        String taskId = UUID.randomUUID().toString();
        Path path = Paths.get(filePath);
        AnalysisConfig config = createAnalysisConfig(projectKey);
        
        // 创建任务记录
        AnalysisTask task = new AnalysisTask(taskId, filePath, projectKey, branch);
        task.setStatus("RUNNING");
        taskMap.put(taskId, task);
        
        // 使用CompletableFuture模拟异步分析
        CompletableFuture<FileAnalysisResult> future = CompletableFuture.supplyAsync(() -> {
            try {
                return codeFileAnalyzer.analyzeFile(path, config);
            } catch (AnalysisException e) {
                throw new RuntimeException(e);
            }
        });
        
        future.thenAccept(result -> {
            try {
                // 设置项目信息
                result.setProjectKey(projectKey);
                result.setBranch(branch);
                result.setFilePath(filePath);
                
                // 保存结果
                analysisResultService.saveAnalysisResult(result);
                
                task.setStatus("COMPLETED");
                task.setResult(result);
                
            } catch (Exception e) {
                task.setStatus("FAILED");
                task.setError(e.getMessage());
            }
        }).exceptionally(throwable -> {
            task.setStatus("FAILED");
            task.setError(throwable.getMessage());
            return null;
        });
        
        return taskId;
    }

    /**
     * 获取任务状态
     */
    public AnalysisTask getTaskStatus(String taskId) {
        return taskMap.get(taskId);
    }

    /**
     * 根据ID获取分析结果
     */
    public FileAnalysisResult getAnalysisResult(Long id) {
        return analysisResultService.getAnalysisResult(id);
    }

    /**
     * 验证文件
     */
    private void validateFile(String filePath) throws AnalysisException {
        if (filePath == null || filePath.trim().isEmpty()) {
            throw new AnalysisException("文件路径不能为空");
        }

        Path path = Paths.get(filePath);
        if (!Files.exists(path)) {
            throw new AnalysisException("文件不存在: " + filePath);
        }

        if (!filePath.endsWith(".java")) {
            throw new AnalysisException("只支持Java文件分析");
        }

        if (!Files.isReadable(path)) {
            throw new AnalysisException("文件不可读: " + filePath);
        }
    }

    /**
     * 创建分析配置
     */
    private AnalysisConfig createAnalysisConfig(String projectKey) {
        AnalysisConfig config = new AnalysisConfig();
        config.setIncrementalEnabled(false);
        config.setParallelEnabled(false);
        config.setCacheEnabled(false);
        return config;
    }

    /**
     * 分析任务类
     */
    @Data
    public static class AnalysisTask {
        private String taskId;
        private String filePath;
        private String projectKey;
        private String branch;
        private String status;
        private FileAnalysisResult result;
        private String error;
        private long startTime;
        private long endTime;

        public AnalysisTask(String taskId, String filePath, String projectKey, String branch) {
            this.taskId = taskId;
            this.filePath = filePath;
            this.projectKey = projectKey;
            this.branch = branch;
            this.startTime = System.currentTimeMillis();
        }
    }
}