package com.aiarchitect.service;

import com.aiarchitect.core.progress.AnalysisException;
import com.aiarchitect.mapper.ProjectAnalysisResultMapper;
import com.aiarchitect.model.analysis.FileAnalysisResult;
import com.aiarchitect.model.analysis.ProjectAnalysisResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ProjectAnalysisService {

    @Autowired
    private FileAnalysisService fileAnalysisService;

    @Autowired
    private ProjectAnalysisResultMapper projectAnalysisResultMapper;

    // 存储项目分析任务状态
    private final ConcurrentMap<String, ProjectAnalysisResult> projectTaskMap = new ConcurrentHashMap<>();
    
    // 线程池用于异步分析
    private final ExecutorService executorService = Executors.newFixedThreadPool(
        Runtime.getRuntime().availableProcessors()
    );

    /**
     * 同步分析整个项目
     */
    @Transactional
    public ProjectAnalysisResult analyzeProject(String projectPath, String projectKey, String branch)
            throws AnalysisException {
        
        validateProjectPath(projectPath);
        
        ProjectAnalysisResult result = new ProjectAnalysisResult();
        result.setProjectPath(projectPath);
        result.setProjectKey(projectKey);
        result.setBranch(branch);
        result.startAnalysis();
        
        try {
            // 扫描项目文件
            List<Path> javaFiles = scanJavaFiles(Paths.get(projectPath));
            result.setTotalFileCount(javaFiles.size());
            
            log.info("开始分析项目: {}, 共找到 {} 个Java文件", projectPath, javaFiles.size());
            
            // 逐个分析文件
            for (Path javaFile : javaFiles) {
                try {
                    result.setCurrentAnalyzingFile(javaFile.toString());
                    
                    FileAnalysisResult fileResult = fileAnalysisService.analyzeFile(
                        javaFile.toString(), projectKey, branch
                    );
                    
                    if (fileResult != null) {
                        result.recordFileSuccess(fileResult);
                        log.debug("成功分析文件: {}", javaFile);
                    } else {
                        result.recordFileFailure(javaFile.toString(), "分析返回null结果");
                        log.warn("文件分析返回null: {}", javaFile);
                    }
                    
                } catch (Exception e) {
                    result.recordFileFailure(javaFile.toString(), e.getMessage());
                    log.error("分析文件失败: {}", javaFile, e);
                }
            }
            
            result.completeAnalysis();

            // 暂时禁用数据库保存，避免表不存在的错误
            // saveProjectAnalysisResult(result);

            log.info("项目分析完成: {}, 成功: {}, 失败: {}",
                projectPath, result.getSuccessFileCount(), result.getFailedFileCount());

            return result;
            
        } catch (Exception e) {
            result.markAsFailed(e.getMessage());
            log.error("项目分析失败: {}", projectPath, e);
            throw new AnalysisException("项目分析失败: " + e.getMessage(), e);
        }
    }

    /**
     * 异步分析整个项目
     */
    public String analyzeProjectAsync(String projectPath, String projectKey, String branch) 
            throws AnalysisException {
        
        validateProjectPath(projectPath);
        
        String taskId = UUID.randomUUID().toString();
        
        ProjectAnalysisResult result = new ProjectAnalysisResult();
        result.setProjectPath(projectPath);
        result.setProjectKey(projectKey);
        result.setBranch(branch);
        result.startAnalysis();
        
        // 存储任务状态
        projectTaskMap.put(taskId, result);
        
        // 异步执行分析
        CompletableFuture.runAsync(() -> {
            try {
                // 扫描项目文件
                List<Path> javaFiles = scanJavaFiles(Paths.get(projectPath));
                result.setTotalFileCount(javaFiles.size());
                
                log.info("开始异步分析项目: {}, 任务ID: {}, 共找到 {} 个Java文件", 
                    projectPath, taskId, javaFiles.size());
                
                // 并行分析文件
                analyzeFilesInParallel(javaFiles, result, projectKey, branch);
                
                result.completeAnalysis();
                log.info("异步项目分析完成: {}, 任务ID: {}, 成功: {}, 失败: {}", 
                    projectPath, taskId, result.getSuccessFileCount(), result.getFailedFileCount());
                
            } catch (Exception e) {
                result.markAsFailed(e.getMessage());
                log.error("异步项目分析失败: {}, 任务ID: {}", projectPath, taskId, e);
            }
        }, executorService);
        
        return taskId;
    }

    /**
     * 并行分析文件列表
     */
    private void analyzeFilesInParallel(List<Path> javaFiles, ProjectAnalysisResult result, 
                                      String projectKey, String branch) {
        
        // 使用并行流处理文件分析
        javaFiles.parallelStream().forEach(javaFile -> {
            try {
                result.setCurrentAnalyzingFile(javaFile.toString());
                
                FileAnalysisResult fileResult = fileAnalysisService.analyzeFile(
                    javaFile.toString(), projectKey, branch
                );
                
                if (fileResult != null) {
                    result.recordFileSuccess(fileResult);
                    log.debug("成功分析文件: {}", javaFile);
                } else {
                    result.recordFileFailure(javaFile.toString(), "分析返回null结果");
                    log.warn("文件分析返回null: {}", javaFile);
                }
                
            } catch (Exception e) {
                result.recordFileFailure(javaFile.toString(), e.getMessage());
                log.error("分析文件失败: {}", javaFile, e);
            }
        });
    }

    /**
     * 获取项目分析任务状态
     */
    public ProjectAnalysisResult getProjectTaskStatus(String taskId) {
        return projectTaskMap.get(taskId);
    }

    /**
     * 取消项目分析任务
     */
    public boolean cancelProjectTask(String taskId) {
        ProjectAnalysisResult result = projectTaskMap.get(taskId);
        if (result != null && "RUNNING".equals(result.getStatus())) {
            result.markAsCancelled();
            log.info("项目分析任务已取消: {}", taskId);
            return true;
        }
        return false;
    }

    /**
     * 清理已完成的任务
     */
    public void cleanupCompletedTasks() {
        projectTaskMap.entrySet().removeIf(entry -> {
            String status = entry.getValue().getStatus();
            return "COMPLETED".equals(status) || "FAILED".equals(status) || "CANCELLED".equals(status);
        });
    }

    /**
     * 获取所有任务状态
     */
    public Map<String, ProjectAnalysisResult> getAllTaskStatus() {
        return new HashMap<>(projectTaskMap);
    }

    /**
     * 递归扫描项目目录，查找所有Java文件
     */
    private List<Path> scanJavaFiles(Path projectPath) throws IOException {
        List<Path> javaFiles = new ArrayList<>();
        
        Files.walkFileTree(projectPath, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                if (file.toString().endsWith(".java")) {
                    javaFiles.add(file);
                }
                return FileVisitResult.CONTINUE;
            }
            
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                // 跳过常见的非源码目录
                String dirName = dir.getFileName().toString();
                if (dirName.equals("target") || dirName.equals("build") || 
                    dirName.equals(".git") || dirName.equals(".idea") || 
                    dirName.equals("node_modules") || dirName.startsWith(".")) {
                    return FileVisitResult.SKIP_SUBTREE;
                }
                return FileVisitResult.CONTINUE;
            }
            
            @Override
            public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
                log.warn("无法访问文件: {}, 错误: {}", file, exc.getMessage());
                return FileVisitResult.CONTINUE;
            }
        });
        
        return javaFiles;
    }

    /**
     * 验证项目路径
     */
    private void validateProjectPath(String projectPath) throws AnalysisException {
        if (projectPath == null || projectPath.trim().isEmpty()) {
            throw new AnalysisException("项目路径不能为空");
        }

        Path path = Paths.get(projectPath);
        if (!Files.exists(path)) {
            throw new AnalysisException("项目路径不存在: " + projectPath);
        }

        if (!Files.isDirectory(path)) {
            throw new AnalysisException("项目路径必须是目录: " + projectPath);
        }

        if (!Files.isReadable(path)) {
            throw new AnalysisException("项目路径不可读: " + projectPath);
        }
    }

    /**
     * 获取项目分析统计信息
     */
    public Map<String, Object> getProjectAnalysisStats(String projectKey, String branch) {
        try {
            ProjectAnalysisResultMapper.ProjectAnalysisStats stats =
                projectAnalysisResultMapper.getProjectAnalysisStats(projectKey, branch);

            Map<String, Object> result = new HashMap<>();
            result.put("projectKey", projectKey);
            result.put("branch", branch);

            if (stats != null) {
                result.put("totalAnalysisCount", stats.getTotalAnalysisCount());
                result.put("successAnalysisCount", stats.getSuccessAnalysisCount());
                result.put("failedAnalysisCount", stats.getFailedAnalysisCount());
                result.put("avgAnalysisTimeMs", stats.getAvgAnalysisTimeMs());
                result.put("avgFileCount", stats.getAvgFileCount());
                result.put("avgDependencyCount", stats.getAvgDependencyCount());
                result.put("lastAnalysisTime", stats.getLastAnalysisTime());
            }

            return result;
        } catch (Exception e) {
            log.error("获取项目分析统计信息失败", e);
            Map<String, Object> result = new HashMap<>();
            result.put("projectKey", projectKey);
            result.put("branch", branch);
            result.put("error", e.getMessage());
            return result;
        }
    }

    /**
     * 保存项目分析结果到数据库
     */
    @Transactional
    private void saveProjectAnalysisResult(ProjectAnalysisResult result) {
        try {
            projectAnalysisResultMapper.insert(result);
            log.debug("项目分析结果已保存到数据库: {}", result.getId());
        } catch (Exception e) {
            log.error("保存项目分析结果失败", e);
            // 不抛出异常，避免影响主要分析流程
        }
    }

    /**
     * 从数据库获取项目分析结果
     */
    public ProjectAnalysisResult getProjectAnalysisResult(Long id) {
        try {
            return projectAnalysisResultMapper.findById(id);
        } catch (Exception e) {
            log.error("获取项目分析结果失败: {}", id, e);
            return null;
        }
    }

    /**
     * 获取项目的历史分析结果
     */
    public List<ProjectAnalysisResult> getProjectAnalysisHistory(String projectKey, String branch) {
        try {
            return projectAnalysisResultMapper.findByProjectAndBranch(projectKey, branch);
        } catch (Exception e) {
            log.error("获取项目分析历史失败: {} - {}", projectKey, branch, e);
            return new ArrayList<>();
        }
    }

    /**
     * 删除项目的分析结果
     */
    @Transactional
    public boolean deleteProjectAnalysisResults(String projectKey, String branch) {
        try {
            int deleted = projectAnalysisResultMapper.deleteByProjectAndBranch(projectKey, branch);
            log.info("删除项目分析结果: {} - {}, 删除数量: {}", projectKey, branch, deleted);
            return deleted > 0;
        } catch (Exception e) {
            log.error("删除项目分析结果失败: {} - {}", projectKey, branch, e);
            return false;
        }
    }

    /**
     * 清理旧的分析结果
     */
    @Transactional
    public int cleanupOldAnalysisResults(int daysToKeep) {
        try {
            String beforeDate = java.time.LocalDateTime.now()
                .minusDays(daysToKeep)
                .toString();

            int deleted = projectAnalysisResultMapper.deleteOldAnalysis(beforeDate);
            log.info("清理旧的项目分析结果，保留{}天，删除数量: {}", daysToKeep, deleted);
            return deleted;
        } catch (Exception e) {
            log.error("清理旧的分析结果失败", e);
            return 0;
        }
    }
}
