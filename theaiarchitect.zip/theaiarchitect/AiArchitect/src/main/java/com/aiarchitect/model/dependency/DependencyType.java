package com.aiarchitect.model.dependency;

public enum DependencyType {
    SIMPLE_IMPORT,  // Java官方包过滤
    SAME_PACKAGE_CLASS,     // 同包类依赖检测
    WILDCARD_IMPORT,        // 星号导入处理
    INHERITANCE,            // 继承关系依赖
    FULLY_QUALIFIED_NAME,   // 全限定类名调用
    REFLECTION,             // 反射动态加载
    INNER_CLASS,            // 内部类和嵌套类
    GENERIC_PARAMETER,      // 泛型类型参数
    MODULE_DEPENDENCY,      // 模块化依赖
    ANNOTATION_GENERATED    // 如Lombok注解依赖
}