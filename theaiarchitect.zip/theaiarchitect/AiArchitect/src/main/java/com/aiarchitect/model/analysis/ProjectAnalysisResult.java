package com.aiarchitect.model.analysis;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

@Data
public class ProjectAnalysisResult {
    // 基础项目信息
    private Long id;                                    // 主键ID
    private String projectPath;                         // 项目根路径
    private String projectKey;                          // 项目标识
    private String branch;                              // 分支名称
    
    // 分析元数据
    private LocalDateTime analysisStartTime;            // 分析开始时间
    private LocalDateTime analysisEndTime;              // 分析结束时间
    private Long totalAnalysisTimeMs;                   // 总分析耗时
    private String analyzerVersion;                     // 分析器版本
    
    // 项目统计信息
    private Integer totalFileCount;                     // 总文件数量
    private Integer analyzedFileCount;                  // 已分析文件数量
    private Integer successFileCount;                   // 成功分析文件数量
    private Integer failedFileCount;                    // 失败文件数量
    private Integer skippedFileCount;                   // 跳过文件数量
    
    // 代码统计
    private Long totalFileSize;                         // 总文件大小
    private Integer totalLineCount;                     // 总代码行数
    private Integer totalDependencyCount;               // 总依赖数量
    private Integer totalErrorCount;                    // 总错误数量
    private Integer totalClassCount;                    // 总类数量
    
    // 性能指标
    private Long maxMemoryUsed;                         // 峰值内存使用
    private Long avgFileAnalysisTimeMs;                 // 平均文件分析耗时
    private Double analysisSpeed;                       // 分析速度(文件/秒)
    
    // 分析状态
    private String status;                              // 分析状态: RUNNING, COMPLETED, FAILED, CANCELLED
    private Double progressPercentage;                  // 进度百分比
    private String currentAnalyzingFile;                // 当前正在分析的文件
    
    // 错误信息
    private String errorMessage;                        // 错误消息
    private Map<String, String> fileErrors;             // 文件错误详情
    
    // 业务字段
    private LocalDateTime createdAt;                    // 创建时间
    private LocalDateTime updatedAt;                    // 更新时间
    
    // 非数据库字段 - 运行时状态
    private final AtomicInteger processedFiles = new AtomicInteger(0);
    private final AtomicInteger successFiles = new AtomicInteger(0);
    private final AtomicInteger failedFiles = new AtomicInteger(0);
    private final AtomicLong totalDependencies = new AtomicLong(0);
    private final AtomicLong totalErrors = new AtomicLong(0);
    private final AtomicLong totalLines = new AtomicLong(0);
    private final AtomicLong totalSize = new AtomicLong(0);
    private final AtomicInteger totalClasses = new AtomicInteger(0);
    
    // 线程安全的错误收集
    private final Map<String, String> concurrentFileErrors = new ConcurrentHashMap<>();
    
    // 文件分析结果列表（可选，用于详细查看）
    private List<FileAnalysisResult> fileResults;
    
    /**
     * 更新分析进度
     */
    public void updateProgress() {
        this.analyzedFileCount = processedFiles.get();
        this.successFileCount = successFiles.get();
        this.failedFileCount = failedFiles.get();
        this.totalDependencyCount = (int) totalDependencies.get();
        this.totalErrorCount = (int) totalErrors.get();
        this.totalLineCount = (int) totalLines.get();
        this.totalFileSize = totalSize.get();
        this.totalClassCount = totalClasses.get();
        
        if (totalFileCount != null && totalFileCount > 0) {
            this.progressPercentage = (double) analyzedFileCount / totalFileCount * 100;
        }
        
        // 复制并发错误映射到普通映射
        this.fileErrors = new ConcurrentHashMap<>(concurrentFileErrors);
        
        this.updatedAt = LocalDateTime.now();
    }
    
    /**
     * 记录文件分析成功
     */
    public void recordFileSuccess(FileAnalysisResult result) {
        processedFiles.incrementAndGet();
        successFiles.incrementAndGet();
        
        if (result.getDependencyCount() != null) {
            totalDependencies.addAndGet(result.getDependencyCount());
        }
        if (result.getErrorCount() != null) {
            totalErrors.addAndGet(result.getErrorCount());
        }
        if (result.getLineCount() != null) {
            totalLines.addAndGet(result.getLineCount());
        }
        if (result.getFileSize() != null) {
            totalSize.addAndGet(result.getFileSize());
        }
        if (result.getAllClassNames() != null) {
            totalClasses.addAndGet(result.getAllClassNames().size());
        }
        
        updateProgress();
    }
    
    /**
     * 记录文件分析失败
     */
    public void recordFileFailure(String filePath, String errorMessage) {
        processedFiles.incrementAndGet();
        failedFiles.incrementAndGet();
        concurrentFileErrors.put(filePath, errorMessage);
        updateProgress();
    }
    
    /**
     * 设置当前分析文件
     */
    public void setCurrentAnalyzingFile(String filePath) {
        this.currentAnalyzingFile = filePath;
        this.updatedAt = LocalDateTime.now();
    }
    
    /**
     * 完成分析
     */
    public void completeAnalysis() {
        this.analysisEndTime = LocalDateTime.now();
        if (this.analysisStartTime != null) {
            this.totalAnalysisTimeMs = java.time.Duration.between(
                this.analysisStartTime, this.analysisEndTime).toMillis();
        }
        
        // 计算平均分析时间和速度
        if (analyzedFileCount != null && analyzedFileCount > 0 && totalAnalysisTimeMs != null) {
            this.avgFileAnalysisTimeMs = totalAnalysisTimeMs / analyzedFileCount;
            this.analysisSpeed = (double) analyzedFileCount / (totalAnalysisTimeMs / 1000.0);
        }
        
        this.status = failedFileCount > 0 ? "COMPLETED_WITH_ERRORS" : "COMPLETED";
        this.progressPercentage = 100.0;
        updateProgress();
    }
    
    /**
     * 标记分析失败
     */
    public void markAsFailed(String errorMessage) {
        this.status = "FAILED";
        this.errorMessage = errorMessage;
        this.analysisEndTime = LocalDateTime.now();
        if (this.analysisStartTime != null) {
            this.totalAnalysisTimeMs = java.time.Duration.between(
                this.analysisStartTime, this.analysisEndTime).toMillis();
        }
        updateProgress();
    }
    
    /**
     * 标记分析取消
     */
    public void markAsCancelled() {
        this.status = "CANCELLED";
        this.analysisEndTime = LocalDateTime.now();
        if (this.analysisStartTime != null) {
            this.totalAnalysisTimeMs = java.time.Duration.between(
                this.analysisStartTime, this.analysisEndTime).toMillis();
        }
        updateProgress();
    }
    
    /**
     * 开始分析
     */
    public void startAnalysis() {
        this.status = "RUNNING";
        this.analysisStartTime = LocalDateTime.now();
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.progressPercentage = 0.0;
    }
}
