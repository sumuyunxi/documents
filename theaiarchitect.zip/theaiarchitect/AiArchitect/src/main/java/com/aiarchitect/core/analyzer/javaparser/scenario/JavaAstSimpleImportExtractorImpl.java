package com.aiarchitect.core.analyzer.javaparser.scenario;

import com.aiarchitect.core.AnalysisConfig;
import com.aiarchitect.core.ScenarioDependencyExtractor;
import com.aiarchitect.model.dependency.BaseDependencyInfo;
import com.aiarchitect.model.dependency.subtype.ImportDependency;
import com.aiarchitect.model.dependency.DependencyType;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import lombok.extern.log4j.Log4j2;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Set;
import java.util.ArrayList;
import java.util.HashSet;

/**
 * 基于Java AST的简单import语句提取器实现。
 * 该提取器专门处理Java源代码中的import声明，识别各种类型的import依赖关系。
 */
@Log4j2
public class JavaAstSimpleImportExtractorImpl implements ScenarioDependencyExtractor {

    @Override
    public List<BaseDependencyInfo> extract(Path filePath, AnalysisConfig config) {
        log.debug("开始提取import依赖: {}", filePath);
        
        List<BaseDependencyInfo> dependencies = new ArrayList<>();
        
        try {
            // 验证文件存在且可读
            if (!Files.exists(filePath)) {
                log.warn("文件不存在: {}", filePath);
                return dependencies;
            }
            
            // 使用JavaParser解析文件 - 使用实例方法
            JavaParser parser = new JavaParser();
            ParseResult<CompilationUnit> parseResult = parser.parse(filePath);
            if (!parseResult.isSuccessful()) {
                log.warn("解析失败: {}", filePath);
                return dependencies;
            }
            
            CompilationUnit compilationUnit = parseResult.getResult()
                .orElseGet(() -> {
                    log.warn("无法获取编译单元: {}", filePath);
                    return null;
                });
            
            if (compilationUnit == null) {
                return dependencies;
            }
            
            // 提取所有import声明
            compilationUnit.getImports().forEach(importDecl -> {
                try {
                    ImportDependency dependency = extractImportDependency(importDecl, config);
                    if (dependency != null) {
                        dependencies.add(dependency);
                    }
                } catch (Exception e) {
                    log.error("提取import依赖时出错", e);
                }
            });
            
            log.debug("提取完成，找到{}个import依赖", dependencies.size());
            return dependencies;
            
        } catch (Exception e) {
            log.error("文件解析错误: {}", filePath, e);
            return dependencies;
        }
    }

    /**
     * 常规在IMPORT中出现的有如下几种情况：
     *  import java.util.*; 常规引入，带星号。由于没有首字母大写的，因此认为是整个包下面的星号引入，需要后续单独处理。
     *  import org.junit.Assert.*; 虽然带星号，但是存在首字母大写的，因此认为第一个首字母大写的为类名，前序的是包名。这种不是星号引用，不需要后续处理。
     *  import com.aiarchitect.model.dependency.AClassName.BInnerClass; 认为B是A的子类，这就是对A的依赖。依然认为第一个首字母大写的为类名，前序的是包名。
     *  需要按照 AnalysisConfig 中的配置，过滤不需要的引入类。
     */
    private ImportDependency extractImportDependency(ImportDeclaration importDecl, AnalysisConfig config) {
        // 设置基础信息
        String fullName = importDecl.getName().toString();
        
        // 根据AnalysisConfig配置过滤不需要的引入类
        if (shouldFilterImport(fullName, config)) {
            log.debug("根据配置过滤import: {}", fullName);
            return null;
        }
        
        ImportDependency dependency = new ImportDependency();
        String[] parts = fullName.split("\\.");
        
        // 根据注释优化类名和包名的解析逻辑
        String className;
        String packageName;
        
        // 找到第一个首字母大写的部分作为类名
        int classNameIndex = findFirstCapitalizedIndex(parts);
        
        if (importDecl.isAsterisk() && !importDecl.isStatic()) {
            // 处理通配符import: java.util.*
            if (classNameIndex == -1) {
                // 没有首字母大写的部分，这是包级别的通配符import
                className = "*";
                packageName = fullName.substring(0, fullName.lastIndexOf('.'));
            } else {
                // 存在首字母大写的部分，按正常逻辑处理
                className = parts[classNameIndex];
                packageName = classNameIndex > 0 ?
                    String.join(".", java.util.Arrays.copyOfRange(parts, 0, classNameIndex)) : "";
            }
        } else if (importDecl.isAsterisk() && importDecl.isStatic()) {
            // 处理静态通配符import: org.junit.Assert.*
            // 静态通配符import中，星号前应该是类名
            if (classNameIndex != -1 && classNameIndex < parts.length - 1) {
                className = parts[classNameIndex];
                packageName = classNameIndex > 0 ?
                    String.join(".", java.util.Arrays.copyOfRange(parts, 0, classNameIndex)) : "";
            } else {
                // 回退到倒数第二部分作为类名
                className = parts.length > 1 ? parts[parts.length - 2] : parts[0];
                packageName = parts.length > 2 ?
                    String.join(".", java.util.Arrays.copyOfRange(parts, 0, parts.length - 2)) : "";
            }
        } else {
            // 处理普通import: com.aiarchitect.model.dependency.AClassName.BInnerClass
            if (classNameIndex != -1) {
                className = parts[classNameIndex];
                packageName = classNameIndex > 0 ?
                    String.join(".", java.util.Arrays.copyOfRange(parts, 0, classNameIndex)) : "";
            } else {
                // 没有大写部分，使用最后一部分作为类名
                className = parts[parts.length - 1];
                packageName = parts.length > 1 ?
                    String.join(".", java.util.Arrays.copyOfRange(parts, 0, parts.length - 1)) : "";
            }
        }
        
        dependency.setClassName(className);
        dependency.setPackageName(packageName);
        dependency.setFullyQualifiedName(fullName);
        
        // 设置import特性
        dependency.setStatic(importDecl.isStatic());
        dependency.setSamePackage(isSamePackage(fullName, config));
        
        // 设置依赖类型
        if (importDecl.isStatic()) {
            dependency.setDependencyType(DependencyType.SIMPLE_IMPORT);
        } else if (importDecl.isAsterisk()) {
            dependency.setDependencyType(DependencyType.WILDCARD_IMPORT);
        } else {
            dependency.setDependencyType(DependencyType.SIMPLE_IMPORT);
        }
        
        // 设置位置和上下文 - 使用Position API获取行号
        dependency.setStartLine(importDecl.getBegin().get().line);
        dependency.setEndLine(importDecl.getEnd().get().line);
        dependency.setUsageContext("import declaration");
        dependency.setResolvedFrom("Java AST import extraction");
        dependency.setConfidence(1.0); // import声明的置信度为100%

        return dependency;
    }
    
    /**
     * 查找第一个首字母大写的部分索引
     */
    private int findFirstCapitalizedIndex(String[] parts) {
        for (int i = 0; i < parts.length; i++) {
            if (!parts[i].isEmpty() && Character.isUpperCase(parts[i].charAt(0))) {
                return i;
            }
        }
        return -1;
    }

    /**
     * 根据AnalysisConfig配置判断是否应过滤该import
     */
    private boolean shouldFilterImport(String fullName, AnalysisConfig config) {
        if (config == null || config.getPackageFilter() == null) {
            return false;
        }
        
        AnalysisConfig.PackageFilterConfig filter = config.getPackageFilter();
        
        // 检查强制包含的优先级最高
        if (filter.getForceIncludePatterns() != null) {
            for (String pattern : filter.getForceIncludePatterns()) {
                if (matchesPattern(fullName, pattern)) {
                    log.debug("强制包含: {} (模式: {})", fullName, pattern);
                    return false; // 强制包含，不过滤
                }
            }
        }
        
        // 检查排除模式
        if (filter.getExcludePatterns() != null) {
            for (String pattern : filter.getExcludePatterns()) {
                if (matchesPattern(fullName, pattern)) {
                    log.debug("根据排除模式过滤: {} (模式: {})", fullName, pattern);
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * 使用通配符模式匹配包名
     */
    private boolean matchesPattern(String fullName, String pattern) {
        if (pattern == null || pattern.isEmpty()) {
            return false;
        }
        
        // 将通配符模式转换为正则表达式
        String regex = pattern
            .replace(".", "\\.")
            .replace("*", ".*");
        
        return fullName.matches(regex);
    }

    private boolean isSamePackage(String fullyQualifiedName, AnalysisConfig config) {
        // 检查是否属于官方包过滤
        if (config.getPackageFilter() != null &&
            config.getPackageFilter().getOfficialPackages() != null) {
            for (String pattern : config.getPackageFilter().getOfficialPackages()) {
                if (matchesPattern(fullyQualifiedName, pattern)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public Set<String> getSupportedDependencyTypes() {
        Set<String> types = new HashSet<>();
        types.add("SIMPLE_IMPORT");
        types.add("STATIC_IMPORT");
        return types;
    }

    @Override
    public int getPriority() {
        return 1; // 提高优先级，import提取应该优先处理
    }

    @Override
    public boolean validate(BaseDependencyInfo dependencyInfo) {
        if (!(dependencyInfo instanceof ImportDependency)) {
            log.warn("不是ImportStatementDependency类型");
            return false;
        }
        
        ImportDependency importDep = (ImportDependency) dependencyInfo;
        
        // 验证必填字段
        if (importDep.getClassName() == null || importDep.getClassName().isEmpty()) {
            log.warn("类名不能为空");
            return false;
        }
        
        if (importDep.getFullyQualifiedName() == null || importDep.getFullyQualifiedName().isEmpty()) {
            log.warn("完全限定名不能为空");
            return false;
        }
        
        // 验证包名格式
        String packageName = importDep.getPackageName();
        if (packageName != null && !packageName.isEmpty()) {
            // 支持多段包名格式，如：java.io, java.nio.file, org.junit等
            if (!packageName.matches("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)*$")) {
                log.warn(packageName + "包名格式不合法");
                return false;
            }
        }
        
        return true;
    }

    @Override
    public List<BaseDependencyInfo> postprocess(List<BaseDependencyInfo> dependencies) {
        log.debug("开始import依赖后处理");
        
        // 过滤重复依赖
        Set<String> uniqueImports = new HashSet<>();
        List<BaseDependencyInfo> processed = new ArrayList<>();
        
        for (BaseDependencyInfo dep : dependencies) {
            String key = dep.getFullyQualifiedName();
            
            if (!uniqueImports.contains(key)) {
                uniqueImports.add(key);
                processed.add(dep);
            } else {
                log.debug("跳过重复import: {}", key);
            }
        }
        
        // 按包名排序
        processed.sort((a, b) -> {
            String aPackage = a.getPackageName();
            String bPackage = b.getPackageName();
            return aPackage.compareTo(bPackage);
        });
        
        log.debug("后处理完成，保留{}个唯一import依赖", processed.size());
        return processed;
    }
}