package com.aiarchitect.core;

import com.aiarchitect.core.progress.AnalysisException;
import com.aiarchitect.model.analysis.FileAnalysisResult;
import com.aiarchitect.model.dependency.BaseDependencyInfo;
import java.nio.file.Path;
import java.util.List;
import java.util.Set;

public interface CodeFileAnalyzer {
    void scenarioDependencyExecutorRegister(ScenarioDependencyExtractor scenarioDependencyExtractor);

    FileAnalysisResult analyzeFile(Path filePath, AnalysisConfig config) throws AnalysisException;

    /**
     * 提取指定Java文件中的所有依赖信息。
     * @param filePath Java源文件路径。
     * @param config 分析配置。
     * @return 提取到的依赖信息列表。
     * @throws AnalysisException 如果在提取过程中发生错误。
     */
    List<BaseDependencyInfo> extractDependencies(Path filePath, AnalysisConfig config) throws AnalysisException;

    /**
     * 提取指定Java文件中的所有类名（包括主类、内部类、匿名类等）。
     * @param filePath Java源文件路径。
     * @return 提取到的所有类名的集合。
     * @throws AnalysisException 如果在提取过程中发生错误。
     */
    Set<String> extractAllClassNames(Path filePath) throws AnalysisException;

    /**
     * 提取指定Java文件的主类名。
     * @param filePath Java源文件路径。
     * @return 主类名，如果不存在则返回null。
     * @throws AnalysisException 如果在提取过程中发生错误。
     */
    String extractMainClassName(Path filePath) throws AnalysisException;

    /**
     * 提取指定Java文件的包名。
     * @param filePath Java源文件路径。
     * @return 包名，如果不存在则返回空字符串。
     * @throws AnalysisException 如果在提取过程中发生错误。
     */
    String extractPackageName(Path filePath) throws AnalysisException;

    /**
     * 获取该提取器支持的文件扩展名。
     * @return 支持的文件扩展名列表，例如 ["java"]。
     */
    List<String> getSupportedFileExtensions();
}