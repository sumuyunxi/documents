package com.aiarchitect.core;


import com.aiarchitect.model.dependency.BaseDependencyInfo;

import java.nio.file.Path;
import java.util.List;
import java.util.Set;

/**
 * 定义了特定场景下依赖提取器的通用接口。
 * 每个实现类负责处理一种或多种特定类型的依赖。
 */
public interface ScenarioDependencyExtractor {

    /**
     * 从给定的AST中提取特定场景的依赖信息。
     * @return 提取到的依赖信息列表。
     */
    List<BaseDependencyInfo> extract(Path filePath, AnalysisConfig config);

    /**
     * 获取此提取器支持的依赖类型。
     * @return 支持的依赖类型集合。
     */
    Set<String> getSupportedDependencyTypes();

    /**
     * 获取此提取器的优先级。优先级高的提取器会先执行。
     * @return 提取器的优先级。
     */
    int getPriority();

    /**
     * 验证提取出的依赖信息是否有效或符合特定规则。
     * @param dependencyInfo 待验证的依赖信息。
     * @return 如果依赖信息有效则返回true，否则返回false。
     */
    boolean validate(BaseDependencyInfo dependencyInfo);

    /**
     * 对提取出的依赖信息进行后处理，例如，过滤或合并。
     * @param dependencies 提取出的依赖信息列表。
     * @return 后处理后的依赖信息列表。
     */
    List<BaseDependencyInfo> postprocess(List<BaseDependencyInfo> dependencies);
}