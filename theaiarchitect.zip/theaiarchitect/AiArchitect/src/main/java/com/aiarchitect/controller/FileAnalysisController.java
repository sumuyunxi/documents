package com.aiarchitect.controller;

import com.aiarchitect.model.analysis.FileAnalysisResult;
import com.aiarchitect.service.FileAnalysisService;
import com.aiarchitect.service.FileAnalysisService.AnalysisTask;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/analysis")
@CrossOrigin(origins = "*")
public class FileAnalysisController {

    @Autowired
    private FileAnalysisService fileAnalysisService;

    /**
     * 通过文件路径分析单个Java文件
     */
    @PostMapping("/analyze-by-path")
    public ResponseEntity<Map<String, Object>> analyzeByPath(@RequestBody Map<String, String> request) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            String filePath = request.get("filePath");
            String projectKey = request.getOrDefault("projectKey", "default");
            String branch = request.getOrDefault("branch", "main");
            
            FileAnalysisResult result = fileAnalysisService.analyzeFile(filePath, projectKey, branch);
            
            response.put("success", true);
            response.put("message", "分析完成");
            response.put("data", result);
            
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "分析失败: " + e.getMessage());
            response.put("error", e.getMessage());
        }
        
        return ResponseEntity.ok(response);
    }

    /**
     * 异步分析文件
     */
    @PostMapping("/analyze-async")
    public ResponseEntity<Map<String, Object>> analyzeAsync(@RequestBody Map<String, String> request) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            String filePath = request.get("filePath");
            String projectKey = request.getOrDefault("projectKey", "default");
            String branch = request.getOrDefault("branch", "main");
            
            String taskId = fileAnalysisService.analyzeFileAsync(filePath, projectKey, branch);
            
            response.put("success", true);
            response.put("taskId", taskId);
            response.put("message", "分析任务已提交，请稍后查询结果");
            
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "提交分析任务失败: " + e.getMessage());
            response.put("error", e.getMessage());
        }
        
        return ResponseEntity.ok(response);
    }

    /**
     * 获取分析进度
     */
    @GetMapping("/progress/{taskId}")
    public ResponseEntity<Map<String, Object>> getProgress(@PathVariable String taskId) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            AnalysisTask task = fileAnalysisService.getTaskStatus(taskId);
            if (task != null) {
                response.put("success", true);
                response.put("data", task);
            } else {
                response.put("success", false);
                response.put("message", "任务不存在");
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "获取进度失败: " + e.getMessage());
        }
        
        return ResponseEntity.ok(response);
    }

    /**
     * 上传并分析文件
     */
    @PostMapping("/upload-and-analyze")
    public ResponseEntity<Map<String, Object>> uploadAndAnalyze(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "projectKey", defaultValue = "default") String projectKey,
            @RequestParam(value = "branch", defaultValue = "main") String branch) {
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            if (file.isEmpty()) {
                response.put("success", false);
                response.put("message", "文件不能为空");
                return ResponseEntity.badRequest().body(response);
            }

            if (!file.getOriginalFilename().endsWith(".java")) {
                response.put("success", false);
                response.put("message", "只支持Java文件");
                return ResponseEntity.badRequest().body(response);
            }

            // 这里简化处理，将上传的文件保存到临时路径后分析
            String tempDir = System.getProperty("java.io.tmpdir");
            java.nio.file.Path tempFile = java.nio.file.Paths.get(tempDir, file.getOriginalFilename());
            file.transferTo(tempFile.toFile());

            FileAnalysisResult result = fileAnalysisService.analyzeFile(
                tempFile.toString(), projectKey, branch);
            
            // 删除临时文件
            java.nio.file.Files.deleteIfExists(tempFile);
            
            response.put("success", true);
            response.put("message", "分析完成");
            response.put("data", result);
            
        } catch (IOException e) {
            response.put("success", false);
            response.put("message", "文件处理失败: " + e.getMessage());
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "分析失败: " + e.getMessage());
        }
        
        return ResponseEntity.ok(response);
    }

    /**
     * 根据ID获取分析结果
     */
    @GetMapping("/result/{id}")
    public ResponseEntity<Map<String, Object>> getResult(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            FileAnalysisResult result = fileAnalysisService.getAnalysisResult(id);
            if (result != null) {
                response.put("success", true);
                response.put("data", result);
            } else {
                response.put("success", false);
                response.put("message", "分析结果不存在");
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "获取结果失败: " + e.getMessage());
        }
        
        return ResponseEntity.ok(response);
    }
}