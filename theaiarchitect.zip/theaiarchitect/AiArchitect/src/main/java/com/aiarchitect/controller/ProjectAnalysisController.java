package com.aiarchitect.controller;

import com.aiarchitect.core.progress.AnalysisException;
import com.aiarchitect.model.analysis.ProjectAnalysisResult;
import com.aiarchitect.service.ProjectAnalysisService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/project-analysis")
@Slf4j
public class ProjectAnalysisController {

    @Autowired
    private ProjectAnalysisService projectAnalysisService;

    /**
     * 同步分析项目
     */
    @PostMapping("/analyze")
    public ResponseEntity<Map<String, Object>> analyzeProject(@RequestBody ProjectAnalysisRequest request) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("收到项目分析请求: {}", request);
            
            ProjectAnalysisResult result = projectAnalysisService.analyzeProject(
                request.getProjectPath(), 
                request.getProjectKey(), 
                request.getBranch()
            );
            
            response.put("success", true);
            response.put("message", "项目分析完成");
            response.put("data", result);
            
            return ResponseEntity.ok(response);
            
        } catch (AnalysisException e) {
            log.error("项目分析失败", e);
            response.put("success", false);
            response.put("message", "项目分析失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
            
        } catch (Exception e) {
            log.error("项目分析异常", e);
            response.put("success", false);
            response.put("message", "系统异常: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 异步分析项目
     */
    @PostMapping("/analyze-async")
    public ResponseEntity<Map<String, Object>> analyzeProjectAsync(@RequestBody ProjectAnalysisRequest request) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("收到异步项目分析请求: {}", request);
            
            String taskId = projectAnalysisService.analyzeProjectAsync(
                request.getProjectPath(), 
                request.getProjectKey(), 
                request.getBranch()
            );
            
            response.put("success", true);
            response.put("message", "项目分析任务已提交");
            response.put("taskId", taskId);
            
            return ResponseEntity.ok(response);
            
        } catch (AnalysisException e) {
            log.error("提交异步项目分析失败", e);
            response.put("success", false);
            response.put("message", "提交分析任务失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
            
        } catch (Exception e) {
            log.error("提交异步项目分析异常", e);
            response.put("success", false);
            response.put("message", "系统异常: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 查询项目分析任务进度
     */
    @GetMapping("/progress/{taskId}")
    public ResponseEntity<Map<String, Object>> getProjectAnalysisProgress(@PathVariable String taskId) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            ProjectAnalysisResult result = projectAnalysisService.getProjectTaskStatus(taskId);
            
            if (result == null) {
                response.put("success", false);
                response.put("message", "任务不存在: " + taskId);
                return ResponseEntity.notFound().build();
            }
            
            response.put("success", true);
            response.put("data", result);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("查询项目分析进度异常", e);
            response.put("success", false);
            response.put("message", "查询进度失败: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 取消项目分析任务
     */
    @PostMapping("/cancel/{taskId}")
    public ResponseEntity<Map<String, Object>> cancelProjectAnalysis(@PathVariable String taskId) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            boolean cancelled = projectAnalysisService.cancelProjectTask(taskId);
            
            if (cancelled) {
                response.put("success", true);
                response.put("message", "任务已取消");
            } else {
                response.put("success", false);
                response.put("message", "任务无法取消或不存在");
            }
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("取消项目分析任务异常", e);
            response.put("success", false);
            response.put("message", "取消任务失败: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 获取所有项目分析任务状态
     */
    @GetMapping("/tasks")
    public ResponseEntity<Map<String, Object>> getAllProjectTasks() {
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, ProjectAnalysisResult> tasks = projectAnalysisService.getAllTaskStatus();
            
            response.put("success", true);
            response.put("data", tasks);
            response.put("count", tasks.size());
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("获取所有项目分析任务异常", e);
            response.put("success", false);
            response.put("message", "获取任务列表失败: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 清理已完成的任务
     */
    @PostMapping("/cleanup")
    public ResponseEntity<Map<String, Object>> cleanupCompletedTasks() {
        Map<String, Object> response = new HashMap<>();
        
        try {
            projectAnalysisService.cleanupCompletedTasks();
            
            response.put("success", true);
            response.put("message", "已清理完成的任务");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("清理已完成任务异常", e);
            response.put("success", false);
            response.put("message", "清理任务失败: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 获取项目分析统计信息
     */
    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getProjectAnalysisStats(
            @RequestParam String projectKey,
            @RequestParam(required = false, defaultValue = "main") String branch) {
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> stats = projectAnalysisService.getProjectAnalysisStats(projectKey, branch);
            
            response.put("success", true);
            response.put("data", stats);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("获取项目分析统计信息异常", e);
            response.put("success", false);
            response.put("message", "获取统计信息失败: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 项目分析请求DTO
     */
    @Data
    public static class ProjectAnalysisRequest {
        private String projectPath;        // 项目根路径
        private String projectKey;         // 项目标识
        private String branch = "main";    // 分支名称，默认为main
        
        // 可选配置参数
        private Boolean parallelEnabled = true;     // 是否启用并行分析
        private Integer maxThreads;                 // 最大线程数
        private Boolean skipTests = true;           // 是否跳过测试文件
        private Boolean skipGenerated = true;       // 是否跳过生成的文件
    }

    /**
     * 获取项目分析历史
     */
    @GetMapping("/history")
    public ResponseEntity<Map<String, Object>> getProjectAnalysisHistory(
            @RequestParam String projectKey,
            @RequestParam(required = false, defaultValue = "main") String branch) {

        Map<String, Object> response = new HashMap<>();

        try {
            List<ProjectAnalysisResult> history = projectAnalysisService.getProjectAnalysisHistory(projectKey, branch);

            response.put("success", true);
            response.put("data", history);
            response.put("count", history.size());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("获取项目分析历史异常", e);
            response.put("success", false);
            response.put("message", "获取分析历史失败: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 获取项目分析结果详情
     */
    @GetMapping("/result/{id}")
    public ResponseEntity<Map<String, Object>> getProjectAnalysisResult(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();

        try {
            ProjectAnalysisResult result = projectAnalysisService.getProjectAnalysisResult(id);

            if (result == null) {
                response.put("success", false);
                response.put("message", "分析结果不存在: " + id);
                return ResponseEntity.notFound().build();
            }

            response.put("success", true);
            response.put("data", result);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("获取项目分析结果异常", e);
            response.put("success", false);
            response.put("message", "获取分析结果失败: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 删除项目分析结果
     */
    @DeleteMapping("/results")
    public ResponseEntity<Map<String, Object>> deleteProjectAnalysisResults(
            @RequestParam String projectKey,
            @RequestParam(required = false, defaultValue = "main") String branch) {

        Map<String, Object> response = new HashMap<>();

        try {
            boolean deleted = projectAnalysisService.deleteProjectAnalysisResults(projectKey, branch);

            if (deleted) {
                response.put("success", true);
                response.put("message", "分析结果已删除");
            } else {
                response.put("success", false);
                response.put("message", "没有找到要删除的分析结果");
            }

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("删除项目分析结果异常", e);
            response.put("success", false);
            response.put("message", "删除分析结果失败: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 清理旧的分析结果
     */
    @PostMapping("/cleanup-old")
    public ResponseEntity<Map<String, Object>> cleanupOldAnalysisResults(
            @RequestParam(required = false, defaultValue = "30") int daysToKeep) {

        Map<String, Object> response = new HashMap<>();

        try {
            int deletedCount = projectAnalysisService.cleanupOldAnalysisResults(daysToKeep);

            response.put("success", true);
            response.put("message", "已清理旧的分析结果");
            response.put("deletedCount", deletedCount);
            response.put("daysToKeep", daysToKeep);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("清理旧分析结果异常", e);
            response.put("success", false);
            response.put("message", "清理失败: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 健康检查
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "ProjectAnalysisService");
        response.put("timestamp", System.currentTimeMillis());
        return ResponseEntity.ok(response);
    }
}
