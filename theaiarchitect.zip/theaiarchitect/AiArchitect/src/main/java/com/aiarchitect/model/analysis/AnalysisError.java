package com.aiarchitect.model.analysis;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AnalysisError {
    private String code;
    private String message;
    private String location;

    public AnalysisError(String code, String message) {
        this.code = code;
        this.message = message;
    }
}