package com.aiarchitect.core.analyzer.javaparser;

import com.aiarchitect.core.AnalysisConfig;
import com.aiarchitect.core.CodeFileAnalyzer;
import com.aiarchitect.core.ScenarioDependencyExtractor;
import com.aiarchitect.core.analyzer.javaparser.scenario.JavaAstFullNameCallExtractorImpl;
import com.aiarchitect.core.analyzer.javaparser.scenario.JavaAstInheritExtractorImpl;
import com.aiarchitect.core.progress.AnalysisException;
import com.aiarchitect.core.analyzer.javaparser.scenario.JavaAstSimpleImportExtractorImpl;
import com.aiarchitect.model.analysis.ClassType;
import com.aiarchitect.model.analysis.FileAnalysisResult;
import com.aiarchitect.model.dependency.BaseDependencyInfo;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 基于Java AST的依赖提取器实现。
 * 该提取器利用JavaParser库解析Java源代码的抽象语法树（AST），
 * 从而识别和提取各种代码依赖关系。
 * 作为DependencyExtractor协调器，管理并调用各种ScenarioDependencyExtractor。
 */
@Log4j2
@Component
public class JavaAstCodeAnalyzerImpl implements CodeFileAnalyzer {
    
    // 注册的依赖提取器列表，按优先级排序
    private final List<ScenarioDependencyExtractor> scenarioExtractors = new ArrayList<>();
    
    // JavaParser实例
    private final JavaParser javaParser;

    public JavaAstCodeAnalyzerImpl() {
        // 初始化JavaParser
        this.javaParser = new JavaParser();
        log.info("JavaAstCodeAnalyzerImpl initialized");
        // 注册简单import依赖提取器
        scenarioDependencyExecutorRegister(new JavaAstSimpleImportExtractorImpl());
        scenarioDependencyExecutorRegister(new JavaAstInheritExtractorImpl());
        scenarioDependencyExecutorRegister(new JavaAstFullNameCallExtractorImpl());
    }
    
    @Override
    public void scenarioDependencyExecutorRegister(ScenarioDependencyExtractor scenarioDependencyExtractor) {
        scenarioExtractors.add(scenarioDependencyExtractor);
        // 按优先级排序，优先级高的先执行
        scenarioExtractors.sort(Comparator.comparingInt(ScenarioDependencyExtractor::getPriority).reversed());
        log.debug("Registered scenario extractor: {} with priority: {}",
                scenarioDependencyExtractor.getClass().getSimpleName(),
                scenarioDependencyExtractor.getPriority());
    }
    
    @Override
    public FileAnalysisResult analyzeFile(Path filePath, AnalysisConfig config) throws AnalysisException {
        log.info("Starting analysis for file: {}", filePath);
        long startTime = System.currentTimeMillis();
        
        try {
            // 验证文件
            validateFile(filePath);
            
            // 创建分析结果
            FileAnalysisResult result = new FileAnalysisResult();
            result.setFilePath(filePath.toString());
            result.setFileName(filePath.getFileName().toString());
            result.setAnalysisTime(LocalDateTime.now());
            result.setAnalyzerVersion("1.0.0");
            
            // 获取文件基本信息
            result.setFileSize(Files.size(filePath));
            result.setLineCount(countLines(filePath));
            
            // 解析Java文件
            ParseResult<CompilationUnit> parseResult = javaParser.parse(filePath);
            if (!parseResult.isSuccessful()) {
                throw new AnalysisException("Failed to parse Java file: " + filePath);
            }
            
            CompilationUnit compilationUnit = parseResult.getResult()
                .orElseThrow(() -> new AnalysisException("Failed to get compilation unit"));
            
            // 提取包名
            String packageName = extractPackageNameInternal(compilationUnit);
            result.setPackageName(packageName);
            
            // 提取类信息
            Set<String> allClassNames = extractAllClassNamesInternal(compilationUnit);
            result.setAllClassNames(allClassNames);
            
            String mainClassName = extractMainClassNameInternal(compilationUnit);
            result.setMainClassName(mainClassName);
            
            // 设置类类型
            result.setClassType(determineClassType(compilationUnit));
            
            // 提取依赖
            List<BaseDependencyInfo> dependencies = extractDependenciesInternal(filePath, config);
            result.setDependencies(dependencies);
            
            // 设置性能指标
            long endTime = System.currentTimeMillis();
            result.setParseTimeMs(endTime - startTime);
            result.setExtractTimeMs(endTime - startTime);
            result.setAllResolveTimeMs(endTime - startTime);
            
            log.info("Completed analysis for file: {} in {}ms", filePath, endTime - startTime);
            return result;
            
        } catch (IOException e) {
            log.error("IO error analyzing file: {}", filePath, e);
            throw new AnalysisException("Failed to read file: " + filePath, e);
        } catch (Exception e) {
            log.error("Error analyzing file: {}", filePath, e);
            throw new AnalysisException("Failed to analyze file: " + filePath, e);
        }
    }
    
    @Override
    public List<BaseDependencyInfo> extractDependencies(Path filePath, AnalysisConfig config) throws AnalysisException {
        log.debug("Extracting dependencies for file: {}", filePath);
        
        try {
            validateFile(filePath);
            
            ParseResult<CompilationUnit> parseResult = javaParser.parse(filePath);
            if (!parseResult.isSuccessful()) {
                throw new AnalysisException("Failed to parse Java file: " + filePath);
            }
            
            CompilationUnit compilationUnit = parseResult.getResult()
                .orElseThrow(() -> new AnalysisException("Failed to get compilation unit"));
            
            return extractDependenciesInternal(filePath, config);
            
        } catch (IOException e) {
            log.error("IO error extracting dependencies: {}", filePath, e);
            throw new AnalysisException("Failed to read file: " + filePath, e);
        } catch (Exception e) {
            log.error("Error extracting dependencies: {}", filePath, e);
            throw new AnalysisException("Failed to extract dependencies: " + filePath, e);
        }
    }
    
    @Override
    public Set<String> extractAllClassNames(Path filePath) throws AnalysisException {
        log.debug("Extracting all class names for file: {}", filePath);
        
        try {
            validateFile(filePath);
            
            ParseResult<CompilationUnit> parseResult = javaParser.parse(filePath);
            if (!parseResult.isSuccessful()) {
                throw new AnalysisException("Failed to parse Java file: " + filePath);
            }
            
            CompilationUnit compilationUnit = parseResult.getResult()
                .orElseThrow(() -> new AnalysisException("Failed to get compilation unit"));
            
            return extractAllClassNamesInternal(compilationUnit);
            
        } catch (IOException e) {
            log.error("IO error extracting class names: {}", filePath, e);
            throw new AnalysisException("Failed to read file: " + filePath, e);
        } catch (Exception e) {
            log.error("Error extracting class names: {}", filePath, e);
            throw new AnalysisException("Failed to extract class names: " + filePath, e);
        }
    }
    
    @Override
    public String extractMainClassName(Path filePath) throws AnalysisException {
        log.debug("Extracting main class name for file: {}", filePath);
        
        try {
            validateFile(filePath);
            
            ParseResult<CompilationUnit> parseResult = javaParser.parse(filePath);
            if (!parseResult.isSuccessful()) {
                throw new AnalysisException("Failed to parse Java file: " + filePath);
            }
            
            CompilationUnit compilationUnit = parseResult.getResult()
                .orElseThrow(() -> new AnalysisException("Failed to get compilation unit"));
            
            return extractMainClassNameInternal(compilationUnit);
            
        } catch (IOException e) {
            log.error("IO error extracting main class name: {}", filePath, e);
            throw new AnalysisException("Failed to read file: " + filePath, e);
        } catch (Exception e) {
            log.error("Error extracting main class name: {}", filePath, e);
            throw new AnalysisException("Failed to extract main class name: " + filePath, e);
        }
    }
    
    @Override
    public String extractPackageName(Path filePath) throws AnalysisException {
        log.debug("Extracting package name for file: {}", filePath);
        
        try {
            validateFile(filePath);
            
            ParseResult<CompilationUnit> parseResult = javaParser.parse(filePath);
            if (!parseResult.isSuccessful()) {
                throw new AnalysisException("Failed to parse Java file: " + filePath);
            }
            
            CompilationUnit compilationUnit = parseResult.getResult()
                .orElseThrow(() -> new AnalysisException("Failed to get compilation unit"));
            
            return extractPackageNameInternal(compilationUnit);
            
        } catch (IOException e) {
            log.error("IO error extracting package name: {}", filePath, e);
            throw new AnalysisException("Failed to read file: " + filePath, e);
        } catch (Exception e) {
            log.error("Error extracting package name: {}", filePath, e);
            throw new AnalysisException("Failed to extract package name: " + filePath, e);
        }
    }
    
    @Override
    public List<String> getSupportedFileExtensions() {
        return List.of("java");
    }
    
    /**
     * 验证文件是否有效
     */
    private void validateFile(Path filePath) throws AnalysisException {
        if (filePath == null) {
            throw new AnalysisException("File path cannot be null");
        }
        if (!Files.exists(filePath)) {
            throw new AnalysisException("File does not exist: " + filePath);
        }
        if (!Files.isRegularFile(filePath)) {
            throw new AnalysisException("Path is not a regular file: " + filePath);
        }
        if (!filePath.toString().endsWith(".java")) {
            throw new AnalysisException("File is not a Java file: " + filePath);
        }
    }
    
    /**
     * 计算文件行数
     */
    private int countLines(Path filePath) throws IOException {
        try (var lines = Files.lines(filePath)) {
            return (int) lines.count();
        }
    }
    
    /**
     * 内部方法：提取包名
     */
    private String extractPackageNameInternal(CompilationUnit compilationUnit) {
        return compilationUnit.getPackageDeclaration()
            .map(pd -> pd.getName().toString())
            .orElse("");
    }
    
    /**
     * 内部方法：提取所有类名
     */
    private Set<String> extractAllClassNamesInternal(CompilationUnit compilationUnit) {
        Set<String> classNames = new HashSet<>();
        
        // 获取所有类型声明（类、接口、枚举等）
        compilationUnit.findAll(TypeDeclaration.class).forEach(type -> {
            classNames.add(type.getNameAsString());
            
            // 添加内部类
            type.findAll(ClassOrInterfaceDeclaration.class).forEach(innerClass -> {
                if (innerClass != type) {
                    classNames.add(innerClass.getNameAsString());
                }
            });
        });
        
        return classNames;
    }
    
    /**
     * 内部方法：提取主类名
     */
    private String extractMainClassNameInternal(CompilationUnit compilationUnit) {
        // 查找public类
        Optional<ClassOrInterfaceDeclaration> publicClass = compilationUnit.findAll(ClassOrInterfaceDeclaration.class)
            .stream()
            .filter(ClassOrInterfaceDeclaration::isPublic)
            .findFirst();
        
        if (publicClass.isPresent()) {
            return publicClass.get().getNameAsString();
        }
        
        // 如果没有public类，返回第一个类
        return compilationUnit.findFirst(ClassOrInterfaceDeclaration.class)
            .map(c -> c.getNameAsString())
            .orElse("");
    }
    
    /**
     * 内部方法：确定类类型
     */
    private ClassType determineClassType(CompilationUnit compilationUnit) {
        List<ClassOrInterfaceDeclaration> classes = compilationUnit.findAll(ClassOrInterfaceDeclaration.class);
        
        if (classes.isEmpty()) {
            return ClassType.CLASS; // 默认返回CLASS类型
        }
        
        // 检查是否是接口
        boolean hasInterface = classes.stream().anyMatch(ClassOrInterfaceDeclaration::isInterface);
        
        if (hasInterface && classes.size() == 1) {
            return ClassType.INTERFACE;
        }
        
        // 检查是否是枚举
        boolean hasEnum = compilationUnit.findAll(com.github.javaparser.ast.body.EnumDeclaration.class)
            .stream()
            .findAny()
            .isPresent();
        
        if (hasEnum && classes.size() == 1) {
            return ClassType.ENUM;
        }
        
        // 检查是否是注解
        boolean hasAnnotation = compilationUnit.findAll(com.github.javaparser.ast.body.AnnotationDeclaration.class)
            .stream()
            .findAny()
            .isPresent();
        
        if (hasAnnotation && classes.size() == 1) {
            return ClassType.ANNOTATION;
        }

        return ClassType.CLASS;
    }
    
    /**
     * 内部方法：提取依赖
     */
    private List<BaseDependencyInfo> extractDependenciesInternal(Path filePath, AnalysisConfig config) {
        List<BaseDependencyInfo> allDependencies = new ArrayList<>();
        
        // 使用所有注册的scenario提取器
        for (ScenarioDependencyExtractor extractor : scenarioExtractors) {
            try {
                log.debug("Running scenario extractor: {}", extractor.getClass().getSimpleName());
                List<BaseDependencyInfo> dependencies = extractor.extract(filePath, config);
                
                // 验证依赖
                dependencies = dependencies.stream().filter(extractor::validate).collect(Collectors.toList());
                
                // 后处理
                dependencies = extractor.postprocess(dependencies);
                
                // 设置通用信息
                dependencies.forEach(dep -> {
                    dep.setFilePath(filePath.toString());
                    dep.setExtractorVersion(extractor.getClass().getSimpleName());
                });
                
                allDependencies.addAll(dependencies);
                log.debug("Extractor {} found {} dependencies", 
                         extractor.getClass().getSimpleName(), dependencies.size());
                
            } catch (Exception e) {
                log.error("Error in scenario extractor: {}", extractor.getClass().getSimpleName(), e);
                // 继续处理其他提取器，不中断整个流程
            }
        }
        
        return allDependencies;
    }
}
