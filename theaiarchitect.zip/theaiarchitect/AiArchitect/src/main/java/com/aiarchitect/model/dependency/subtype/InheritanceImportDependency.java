package com.aiarchitect.model.dependency.subtype;

import com.aiarchitect.model.dependency.BaseDependencyInfo;
import com.aiarchitect.model.dependency.DelayProcess;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 需要等所有类都解析完成后，再进行处理。
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class InheritanceImportDependency extends BaseDependencyInfo implements DelayProcess {
    private boolean processed;
    
    @Override
    public boolean processed() {
        return processed;
    }
    
    @Override
    public String getDependencySubType() {
        return "INHERITANCE_IMPORT";
    }
}