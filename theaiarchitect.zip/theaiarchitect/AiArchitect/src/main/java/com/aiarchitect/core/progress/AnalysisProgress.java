package com.aiarchitect.core.progress;

import lombok.Data;

@Data
public class AnalysisProgress {
    private String analysisId;
    private AnalysisStatus status;
    private int totalFiles;
    private int processedFiles;
    private double progressPercentage;
    private String currentFile;
    private String message;
    private long startTime;
    private long estimatedRemainingTime;
}