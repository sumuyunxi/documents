package com.aiarchitect.mapper;

import com.aiarchitect.model.analysis.FileAnalysisResult;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface FileAnalysisResultMapper {
    
    int insert(FileAnalysisResult fileAnalysisResult);
    
    FileAnalysisResult findById(Long id);
    
    FileAnalysisResult findByFilePathAndProject(@Param("filePath") String filePath, 
                                               @Param("projectKey") String projectKey, 
                                               @Param("branch") String branch);
    
    List<FileAnalysisResult> findByProjectAndBranch(@Param("projectKey") String projectKey, 
                                                   @Param("branch") String branch);
    
    int update(FileAnalysisResult fileAnalysisResult);
    
    int deleteById(Long id);
    
    int deleteByProjectAndBranch(@Param("projectKey") String projectKey, @Param("branch") String branch);
}