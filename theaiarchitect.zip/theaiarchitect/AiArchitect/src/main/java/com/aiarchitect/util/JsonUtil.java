package com.aiarchitect.util;

import com.alibaba.fastjson2.JSON;
import java.util.Set;
import java.util.HashSet;

public class JsonUtil {
    
    public static String toJson(Object obj) {
        if (obj == null) {
            return null;
        }
        return JSON.toJSONString(obj);
    }
    
    public static <T> T fromJson(String json, Class<T> clazz) {
        if (json == null || json.trim().isEmpty()) {
            return null;
        }
        return JSON.parseObject(json, clazz);
    }
    
    public static Set<String> parseStringSet(String json) {
        if (json == null || json.trim().isEmpty()) {
            return new HashSet<>();
        }
        return new HashSet<>(JSON.parseArray(json, String.class));
    }
    
    public static String toJsonStringSet(Set<String> set) {
        if (set == null) {
            return null;
        }
        return JSON.toJSONString(set);
    }
}