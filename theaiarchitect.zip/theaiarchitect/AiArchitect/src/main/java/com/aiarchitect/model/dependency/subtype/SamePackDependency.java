package com.aiarchitect.model.dependency.subtype;

import com.aiarchitect.model.dependency.BaseDependencyInfo;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class SamePackDependency extends BaseDependencyInfo {
    
    @Override
    public String getDependencySubType() {
        return "SAME_PACK";
    }
}