package com.aiarchitect.model.dependency.subtype;

import com.aiarchitect.model.dependency.BaseDependencyInfo;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class ReflectionDependency extends BaseDependencyInfo {
    private String methodName;                      // 反射方法名
    private String targetExpression;                // 目标表达式
    private ReflectionType reflectionType;          // 反射类型
    private String stringLiteral;                   // 字符串字面量
    
    public enum ReflectionType {
        CLASS_FOR_NAME,
        CLASS_LOADER_LOAD_CLASS,
        SERVICE_LOADER_LOAD,
        BUNDLE_LOAD_CLASS,
        OTHER
    }
    
    @Override
    public String getDependencySubType() {
        return "REFLECTION";
    }
}