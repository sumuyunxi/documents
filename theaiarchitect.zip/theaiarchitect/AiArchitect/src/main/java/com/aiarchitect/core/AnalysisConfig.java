package com.aiarchitect.core;

import com.aiarchitect.model.dependency.DependencyType;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.*;

@Data
@ConfigurationProperties(prefix = "analysis")
@Component
public class AnalysisConfig {
    // 包过滤配置
    private PackageFilterConfig packageFilter = new PackageFilterConfig();
    
    // 依赖类型开关
    private Set<DependencyType> enabledTypes = EnumSet.allOf(DependencyType.class);
    
    // 性能配置
    private PerformanceConfig performance = new PerformanceConfig();
    
    // Lombok配置
    private Map<String, LombokMapping> lombokMappings = new HashMap<>();
    
    // 第三方库配置  
    private List<String> thirdPartyPatterns = new ArrayList<>();
    
    // 高级选项
    private boolean incrementalEnabled = false;
    private boolean parallelEnabled = false;
    private boolean cacheEnabled = false;
    private boolean strictMode = false;
    
    // 输出配置
    private OutputConfig output = new OutputConfig();
    
    @Data
    public static class PackageFilterConfig {
        private final List<String> officialPackages = Arrays.asList("java.*", "javax.*", "jdk.*","org.springframework.*","lombok.*");
        private final List<String> excludePatterns = new ArrayList<>();
        private final List<String> forceIncludePatterns = new ArrayList<>(); // 在排除的之外强制需要保留的
        {
            excludePatterns.addAll(officialPackages);
        }

        public void addExcludePattern(String pattern) {
            excludePatterns.add(pattern);
        }

        public void addForceIncludePattern(String pattern) {
            forceIncludePatterns.add(pattern);
        }
    }
    
    @Data
    public static class PerformanceConfig {
        private int threadPoolSize = Runtime.getRuntime().availableProcessors();
        private int maxFileSize = 10 * 1024 * 1024; // 10MB
        private int batchSize = 100;
        private long timeoutSeconds = 300;
        private boolean memoryOptimized = true;
    }
    
    @Data
    public static class OutputConfig {
        private boolean includeSourceLocation = true;
        private boolean includeConfidence = true;
        private boolean includeMetrics = false;
        private int maxErrorsPerFile = 100;
    }

    @Data
    public static class LombokMapping {
        private List<String> generates;
        private List<String> implicitImports;
    }
}