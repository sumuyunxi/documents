package com.aiarchitect.mapper;

import com.aiarchitect.model.dependency.BaseDependencyInfo;
import com.aiarchitect.model.dependency.subtype.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface BaseDependencyInfoMapper {
    
    int insert(BaseDependencyInfo baseDependencyInfo);
    
    BaseDependencyInfo findById(Long id);
    
    List<BaseDependencyInfo> findByFileAnalysisId(Long fileAnalysisId);
    
    List<BaseDependencyInfo> findByProjectAndBranch(@Param("projectKey") String projectKey, 
                                                   @Param("branch") String branch);
    
    List<BaseDependencyInfo> findByFileAnalysisIdAndSubType(@Param("fileAnalysisId") Long fileAnalysisId, 
                                                           @Param("subType") String subType);
    
    int update(BaseDependencyInfo baseDependencyInfo);
    
    int deleteById(Long id);
    
    int deleteByFileAnalysisId(Long fileAnalysisId);
    
    int deleteByProjectAndBranch(@Param("projectKey") String projectKey, @Param("branch") String branch);
}