package com.aiarchitect.llm;

public class LlmProxy {
}
