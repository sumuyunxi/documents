package com.aiarchitect.model.dependency.subtype;

import com.aiarchitect.model.dependency.BaseDependencyInfo;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = true)
public class GenericDependency extends BaseDependencyInfo {
    private String containerType;                   // 容器类型
    private Integer nestedLevel;                    // 嵌套层级
    private String wildcardBound;                   // 通配符边界
    private List<String> typeParameters;           // 类型参数列表
    
    @Override
    public String getDependencySubType() {
        return "GENERIC";
    }
}