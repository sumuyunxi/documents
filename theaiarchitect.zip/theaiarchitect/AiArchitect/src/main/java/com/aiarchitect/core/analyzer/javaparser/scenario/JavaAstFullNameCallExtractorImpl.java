package com.aiarchitect.core.analyzer.javaparser.scenario;

import com.aiarchitect.core.AnalysisConfig;
import com.aiarchitect.core.ScenarioDependencyExtractor;
import com.aiarchitect.model.dependency.BaseDependencyInfo;
import com.aiarchitect.model.dependency.DependencyType;
import com.aiarchitect.model.dependency.subtype.FullNameCallDependency;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import lombok.extern.slf4j.Slf4j;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Pattern;

/**
 * 完成对全名调用的解析。
 * packageName = String.join(".", java.util.Arrays.copyOfRange(parts, 0, parts.length - 1));
 * 里面需要解析出来 java.util.Arrays
 * public class ImportTestClass extends Exception implements Runnable, java.io.Serializable {
 * 里面需要解析出来 java.io.Serializable
 */
@Slf4j
public class JavaAstFullNameCallExtractorImpl implements ScenarioDependencyExtractor {

    @Override
    public List<BaseDependencyInfo> extract(Path filePath, AnalysisConfig config) {
        log.debug("开始提取全名调用依赖: {}", filePath);
        
        List<BaseDependencyInfo> dependencies = new ArrayList<>();
        
        try {
            // 验证文件存在且可读
            if (!Files.exists(filePath)) {
                log.warn("文件不存在: {}", filePath);
                return dependencies;
            }
            
            // 使用JavaParser解析文件
            JavaParser parser = new JavaParser();
            ParseResult<CompilationUnit> parseResult = parser.parse(filePath);
            if (!parseResult.isSuccessful()) {
                log.warn("解析失败: {}", filePath);
                return dependencies;
            }
            
            CompilationUnit compilationUnit = parseResult.getResult()
                .orElseGet(() -> {
                    log.warn("无法获取编译单元: {}", filePath);
                    return null;
                });
            
            if (compilationUnit == null) {
                return dependencies;
            }
            
            // 提取方法调用中的全限定名
            extractMethodCallFullNames(compilationUnit, filePath, dependencies);
            
            // 提取继承和实现中的全限定名
            extractInheritanceFullNames(compilationUnit, filePath, dependencies);
            
            // 提取对象创建中的全限定名
            extractObjectCreationFullNames(compilationUnit, filePath, dependencies);
            
            // 提取字段声明中的全限定名
            extractFieldDeclarationFullNames(compilationUnit, filePath, dependencies);
            
            log.debug("提取完成，找到{}个全名调用依赖", dependencies.size());
            return dependencies;
            
        } catch (Exception e) {
            log.error("文件解析错误: {}", filePath, e);
            return dependencies;
        }
    }

    /**
     * 提取方法调用中的全限定名
     */
    private void extractMethodCallFullNames(CompilationUnit compilationUnit, Path filePath, List<BaseDependencyInfo> dependencies) {
        // 查找所有方法调用表达式
        compilationUnit.findAll(MethodCallExpr.class).forEach(methodCall -> {
            try {
                // 检查方法调用的作用域是否为全限定名
                methodCall.getScope().ifPresent(scope -> {
                    String scopeStr = scope.toString();
                    if (isFullyQualifiedName(scopeStr)) {
                        FullNameCallDependency dependency = createFullNameCallDependency(
                            scopeStr, filePath, "method call", methodCall.getBegin().map(pos -> pos.line).orElse(0));
                        if (dependency != null) {
                            dependencies.add(dependency);
                        }
                    }
                });
            } catch (Exception e) {
                log.error("提取方法调用全名时出错", e);
            }
        });
        
        // 查找所有名称表达式
        compilationUnit.findAll(NameExpr.class).forEach(nameExpr -> {
            try {
                String nameStr = nameExpr.toString();
                if (isFullyQualifiedName(nameStr)) {
                    FullNameCallDependency dependency = createFullNameCallDependency(
                        nameStr, filePath, "name reference", nameExpr.getBegin().map(pos -> pos.line).orElse(0));
                    if (dependency != null) {
                        dependencies.add(dependency);
                    }
                }
            } catch (Exception e) {
                log.error("提取名称表达式全名时出错", e);
            }
        });
    }

    /**
     * 提取继承和实现中的全限定名
     */
    private void extractInheritanceFullNames(CompilationUnit compilationUnit, Path filePath, List<BaseDependencyInfo> dependencies) {
        compilationUnit.findAll(ClassOrInterfaceDeclaration.class).forEach(classDecl -> {
            try {
                // 提取继承的类
                classDecl.getExtendedTypes().forEach(extendedType -> {
                    String typeName = extendedType.toString();
                    if (isFullyQualifiedName(typeName)) {
                        FullNameCallDependency dependency = createFullNameCallDependency(
                            typeName, filePath, "extends relationship", 
                            extendedType.getBegin().map(pos -> pos.line).orElse(0));
                        if (dependency != null) {
                            dependencies.add(dependency);
                        }
                    }
                });
                
                // 提取实现的接口
                classDecl.getImplementedTypes().forEach(implementedType -> {
                    String typeName = implementedType.toString();
                    if (isFullyQualifiedName(typeName)) {
                        FullNameCallDependency dependency = createFullNameCallDependency(
                            typeName, filePath, "implements relationship", 
                            implementedType.getBegin().map(pos -> pos.line).orElse(0));
                        if (dependency != null) {
                            dependencies.add(dependency);
                        }
                    }
                });
                
            } catch (Exception e) {
                log.error("提取继承关系全名时出错", e);
            }
        });
    }

    /**
     * 提取对象创建中的全限定名
     */
    private void extractObjectCreationFullNames(CompilationUnit compilationUnit, Path filePath, List<BaseDependencyInfo> dependencies) {
        compilationUnit.findAll(ObjectCreationExpr.class).forEach(objCreation -> {
            try {
                String typeName = objCreation.getType().toString();
                if (isFullyQualifiedName(typeName)) {
                    FullNameCallDependency dependency = createFullNameCallDependency(
                        typeName, filePath, "object creation", 
                        objCreation.getBegin().map(pos -> pos.line).orElse(0));
                    if (dependency != null) {
                        dependencies.add(dependency);
                    }
                }
            } catch (Exception e) {
                log.error("提取对象创建全名时出错", e);
            }
        });
    }

    /**
     * 提取字段声明中的全限定名
     */
    private void extractFieldDeclarationFullNames(CompilationUnit compilationUnit, Path filePath, List<BaseDependencyInfo> dependencies) {
        compilationUnit.findAll(ClassOrInterfaceType.class).forEach(type -> {
            try {
                String typeName = type.toString();
                if (isFullyQualifiedName(typeName)) {
                    FullNameCallDependency dependency = createFullNameCallDependency(
                        typeName, filePath, "type reference", 
                        type.getBegin().map(pos -> pos.line).orElse(0));
                    if (dependency != null) {
                        dependencies.add(dependency);
                    }
                }
            } catch (Exception e) {
                log.error("提取字段声明全名时出错", e);
            }
        });
    }

    /**
     * 判断是否为全限定名
     */
    private boolean isFullyQualifiedName(String name) {
        if (name == null || name.isEmpty()) {
            return false;
        }
        
        // 检查是否包含至少一个点，且符合Java包名和类名的格式
        String[] parts = name.split("\\.");
        if (parts.length < 2) {
            return false;
        }
        
        // 检查每个部分是否符合Java标识符规范
        Pattern identifierPattern = Pattern.compile("^[a-zA-Z_$][a-zA-Z0-9_$]*$");
        
        for (String part : parts) {
            if (!identifierPattern.matcher(part).matches()) {
                return false;
            }
        }
        
        // 检查最后一部分是否以大写字母开头（类名）
        String lastPart = parts[parts.length - 1];
        return Character.isUpperCase(lastPart.charAt(0));
    }

    /**
     * 创建全名调用依赖对象
     */
    private FullNameCallDependency createFullNameCallDependency(String fullName, Path filePath, String context, int lineNumber) {
        try {
            FullNameCallDependency dependency = new FullNameCallDependency();
            
            // 解析类名和包名
            String[] parts = fullName.split("\\.");
            if (parts.length < 2) {
                return null;
            }
            
            String className = parts[parts.length - 1];
            String packageName = String.join(".", Arrays.copyOfRange(parts, 0, parts.length - 1));
            
            dependency.setClassName(className);
            dependency.setPackageName(packageName);
            dependency.setFullyQualifiedName(fullName);
            
            // 设置依赖类型
            dependency.setDependencyType(DependencyType.FULLY_QUALIFIED_NAME);
            
            // 设置位置和上下文
            dependency.setFilePath(filePath.toString());
            dependency.setStartLine(lineNumber);
            dependency.setEndLine(lineNumber);
            dependency.setUsageContext("Full qualified name usage: " + context);
            dependency.setResolvedFrom("Java AST full name extraction");
            dependency.setConfidence(1.0); // AST解析的置信度为100%
            dependency.setExtractorVersion("1.0.0");
            
            return dependency;
            
        } catch (Exception e) {
            log.error("创建全名调用依赖时出错", e);
            return null;
        }
    }

    @Override
    public Set<String> getSupportedDependencyTypes() {
        return Set.of("FULLY_QUALIFIED_NAME");
    }

    @Override
    public int getPriority() {
        return 3; // 全名调用提取优先级高于继承和import提取
    }

    @Override
    public boolean validate(BaseDependencyInfo dependencyInfo) {
        if (!(dependencyInfo instanceof FullNameCallDependency)) {
            log.warn("不是FullNameCallDependency类型");
            return false;
        }
        
        FullNameCallDependency fullNameDep = (FullNameCallDependency) dependencyInfo;
        
        // 验证必填字段
        if (fullNameDep.getClassName() == null || fullNameDep.getClassName().isEmpty()) {
            log.warn("类名不能为空");
            return false;
        }
        
        if (fullNameDep.getFullyQualifiedName() == null || fullNameDep.getFullyQualifiedName().isEmpty()) {
            log.warn("完全限定名不能为空");
            return false;
        }
        
        // 验证包名格式
        String packageName = fullNameDep.getPackageName();
        if (packageName != null && !packageName.isEmpty()) {
            // 支持多段包名格式
            if (!packageName.matches("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)*$")) {
                log.warn(packageName + " 包名格式不合法");
                return false;
            }
        }
        
        return true;
    }

    @Override
    public List<BaseDependencyInfo> postprocess(List<BaseDependencyInfo> dependencies) {
        log.debug("开始全名调用依赖后处理");
        
        // 过滤重复依赖
        Set<String> uniqueFullNames = new HashSet<>();
        List<BaseDependencyInfo> processed = new ArrayList<>();
        
        for (BaseDependencyInfo dep : dependencies) {
            String key = dep.getFullyQualifiedName() + "@" + dep.getUsageContext();
            
            if (!uniqueFullNames.contains(key)) {
                uniqueFullNames.add(key);
                processed.add(dep);
            } else {
                log.debug("跳过重复全名调用: {}", key);
            }
        }
        
        // 按包名和类名排序
        processed.sort((a, b) -> {
            String aFullName = a.getFullyQualifiedName();
            String bFullName = b.getFullyQualifiedName();
            return aFullName.compareTo(bFullName);
        });
        
        log.debug("后处理完成，保留{}个唯一全名调用依赖", processed.size());
        return processed;
    }
}