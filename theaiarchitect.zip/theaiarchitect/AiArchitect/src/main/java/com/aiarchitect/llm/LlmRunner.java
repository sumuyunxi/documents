package com.aiarchitect.llm;

public interface LlmRunner {
}
