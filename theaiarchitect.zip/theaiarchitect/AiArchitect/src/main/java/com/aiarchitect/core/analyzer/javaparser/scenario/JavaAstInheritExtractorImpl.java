package com.aiarchitect.core.analyzer.javaparser.scenario;

import com.aiarchitect.core.AnalysisConfig;
import com.aiarchitect.core.ScenarioDependencyExtractor;
import com.aiarchitect.model.dependency.BaseDependencyInfo;
import com.aiarchitect.model.dependency.DependencyType;
import com.aiarchitect.model.dependency.subtype.InheritanceImportDependency;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import lombok.extern.slf4j.Slf4j;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;


/**
 * 基于Java AST的简单import语句提取器实现。
 * public class WildcardImportDependency extends BaseDependencyInfo implements DelayProcess, DemoService {
 * 类似这样的，需要能解析出对基类和接口的依赖。
 * 如果在IMPORT中没有找到对应的引入信息，那可能有三种情况
 * 1：Java的官方库、2：同一个包的其他类、3：IMPORT中星号覆盖到的。
 *
 */
@Slf4j
public class JavaAstInheritExtractorImpl implements ScenarioDependencyExtractor {

    @Override
    public List<BaseDependencyInfo> extract(Path filePath, AnalysisConfig config) {
        log.debug("开始提取继承关系依赖: {}", filePath);
        
        List<BaseDependencyInfo> dependencies = new ArrayList<>();
        
        try {
            // 验证文件存在且可读
            if (!Files.exists(filePath)) {
                log.warn("文件不存在: {}", filePath);
                return dependencies;
            }
            
            // 使用JavaParser解析文件
            JavaParser parser = new JavaParser();
            ParseResult<CompilationUnit> parseResult = parser.parse(filePath);
            if (!parseResult.isSuccessful()) {
                log.warn("解析失败: {}", filePath);
                return dependencies;
            }
            
            CompilationUnit compilationUnit = parseResult.getResult()
                .orElseGet(() -> {
                    log.warn("无法获取编译单元: {}", filePath);
                    return null;
                });
            
            if (compilationUnit == null) {
                return dependencies;
            }
            
            // 提取所有类或接口声明
            compilationUnit.findAll(ClassOrInterfaceDeclaration.class).forEach(classDecl -> {
                try {
                    // 提取继承的类
                    classDecl.getExtendedTypes().forEach(extendedType -> {
                        InheritanceImportDependency dependency = createInheritanceDependency(
                            extendedType, classDecl, filePath, "extends");
                        if (dependency != null) {
                            dependencies.add(dependency);
                        }
                    });
                    
                    // 提取实现的接口
                    classDecl.getImplementedTypes().forEach(implementedType -> {
                        InheritanceImportDependency dependency = createInheritanceDependency(
                            implementedType, classDecl, filePath, "implements");
                        if (dependency != null) {
                            dependencies.add(dependency);
                        }
                    });
                    
                } catch (Exception e) {
                    log.error("提取继承关系依赖时出错", e);
                }
            });
            
            log.debug("提取完成，找到{}个继承关系依赖", dependencies.size());
            return dependencies;
            
        } catch (Exception e) {
            log.error("文件解析错误: {}", filePath, e);
            return dependencies;
        }
    }

    /**
     * 创建继承关系依赖对象
     */
    private InheritanceImportDependency createInheritanceDependency(
            ClassOrInterfaceType type, 
            ClassOrInterfaceDeclaration classDecl, 
            Path filePath,
            String relationshipType) {
        
        try {
            InheritanceImportDependency dependency = new InheritanceImportDependency();
            
            // 获取完全限定名
            String fullyQualifiedName = type.getNameAsString();
            
            // 解析类名和包名
            String className;
            String packageName;
            
            String[] parts = fullyQualifiedName.split("\\.");
            if (parts.length > 1) {
                // 有包名的情况
                className = parts[parts.length - 1];
                packageName = String.join(".", java.util.Arrays.copyOfRange(parts, 0, parts.length - 1));
            } else {
                // 没有包名的情况（可能是同包类或java.lang包）
                className = fullyQualifiedName;
                packageName = "";
            }
            
            dependency.setClassName(className);
            dependency.setPackageName(packageName);
            dependency.setFullyQualifiedName(fullyQualifiedName);
            
            // 设置依赖类型
            dependency.setDependencyType(DependencyType.INHERITANCE);
            
            // 设置位置和上下文
            dependency.setFilePath(filePath.toString());
            if (type.getBegin().isPresent()) {
                dependency.setStartLine(type.getBegin().get().line);
            }
            if (type.getEnd().isPresent()) {
                dependency.setEndLine(type.getEnd().get().line);
            }
            
            dependency.setUsageContext(relationshipType + " relationship: " + classDecl.getNameAsString() + " " + 
                                     relationshipType + " " + fullyQualifiedName);
            dependency.setResolvedFrom("Java AST inheritance extraction");
            dependency.setConfidence(1.0); // AST解析的置信度为100%
            dependency.setExtractorVersion("1.0.0");
            
            return dependency;
            
        } catch (Exception e) {
            log.error("创建继承关系依赖时出错", e);
            return null;
        }
    }

    @Override
    public Set<String> getSupportedDependencyTypes() {
        return Set.of("INHERITANCE");
    }

    @Override
    public int getPriority() {
        return 2; // 继承关系提取优先级高于import提取
    }

    @Override
    public boolean validate(BaseDependencyInfo dependencyInfo) {
        if (!(dependencyInfo instanceof InheritanceImportDependency)) {
            log.warn("不是InheritanceImportDependency类型");
            return false;
        }
        
        InheritanceImportDependency inheritanceDep = (InheritanceImportDependency) dependencyInfo;
        
        // 验证必填字段
        if (inheritanceDep.getClassName() == null || inheritanceDep.getClassName().isEmpty()) {
            log.warn("类名不能为空");
            return false;
        }
        
        if (inheritanceDep.getFullyQualifiedName() == null || inheritanceDep.getFullyQualifiedName().isEmpty()) {
            log.warn("完全限定名不能为空");
            return false;
        }
        
        return true;
    }

    @Override
    public List<BaseDependencyInfo> postprocess(List<BaseDependencyInfo> dependencies) {
        log.debug("开始继承关系依赖后处理");
        
        // 过滤重复依赖
        Set<String> uniqueInheritances = java.util.HashSet.newHashSet(dependencies.size());
        List<BaseDependencyInfo> processed = new ArrayList<>();
        
        for (BaseDependencyInfo dep : dependencies) {
            String key = dep.getFullyQualifiedName() + "@" + dep.getUsageContext();
            
            if (!uniqueInheritances.contains(key)) {
                uniqueInheritances.add(key);
                processed.add(dep);
            } else {
                log.debug("跳过重复继承关系: {}", key);
            }
        }
        
        // 按类名排序
        processed.sort((a, b) -> {
            String aClass = a.getClassName();
            String bClass = b.getClassName();
            return aClass.compareTo(bClass);
        });
        
        log.debug("后处理完成，保留{}个唯一继承关系依赖", processed.size());
        return processed;
    }
}