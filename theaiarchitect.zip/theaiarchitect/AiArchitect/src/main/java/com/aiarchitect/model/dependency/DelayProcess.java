package com.aiarchitect.model.dependency;


public interface DelayProcess {
    boolean processed();
}