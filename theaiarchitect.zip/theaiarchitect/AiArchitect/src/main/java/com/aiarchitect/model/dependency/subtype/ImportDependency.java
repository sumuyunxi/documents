package com.aiarchitect.model.dependency.subtype;

import com.aiarchitect.model.dependency.BaseDependencyInfo;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class ImportDependency extends BaseDependencyInfo {
    private boolean isStatic;
    private boolean isSamePackage;
    
    @Override
    public String getDependencySubType() {
        return "IMPORT";
    }
}