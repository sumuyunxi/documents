package com.aiarchitect.core.progress;

public enum AnalysisStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    FAILED,
    CANCELLED
}