# 项目分析功能 (ProjectAnalysisService)

## 概述

ProjectAnalysisService 是一个新增的服务，用于递归扫描项目目录并对每个Java源码文件进行分析和存储。它基于现有的 FileAnalysisService，提供了批量分析整个项目的能力。

## 主要功能

### 1. 项目扫描
- 递归扫描指定项目目录
- 自动识别Java源码文件（.java）
- 智能跳过非源码目录（target、build、.git等）
- 支持自定义文件过滤规则

### 2. 批量分析
- 同步分析：顺序处理所有文件
- 异步分析：并行处理，提高效率
- 进度跟踪：实时报告分析进度
- 错误处理：记录失败文件和错误信息

### 3. 结果管理
- 项目级别统计信息汇总
- 数据库持久化存储
- 历史记录查询
- 结果导出功能

## 核心组件

### 1. ProjectAnalysisService
主要的项目分析服务类，提供以下方法：

```java
// 同步分析项目
ProjectAnalysisResult analyzeProject(String projectPath, String projectKey, String branch)

// 异步分析项目
String analyzeProjectAsync(String projectPath, String projectKey, String branch)

// 获取任务状态
ProjectAnalysisResult getProjectTaskStatus(String taskId)

// 取消分析任务
boolean cancelProjectTask(String taskId)
```

### 2. ProjectAnalysisResult
项目分析结果模型，包含：

- **基础信息**：项目路径、标识、分支
- **统计数据**：文件数量、依赖数量、错误数量等
- **性能指标**：分析耗时、内存使用、分析速度
- **状态管理**：进度百分比、当前分析文件、错误信息

### 3. ProjectAnalysisController
REST API控制器，提供以下端点：

```
POST /api/project-analysis/analyze          # 同步分析
POST /api/project-analysis/analyze-async    # 异步分析
GET  /api/project-analysis/progress/{taskId} # 查询进度
POST /api/project-analysis/cancel/{taskId}   # 取消任务
GET  /api/project-analysis/tasks            # 获取所有任务
GET  /api/project-analysis/history          # 获取分析历史
```

## 使用方式

### 1. Web界面
访问 `project-analysis.html` 页面：

1. 输入项目根路径
2. 设置项目标识和分支名称
3. 选择同步或异步分析
4. 查看实时进度和结果

### 2. API调用

#### 同步分析
```bash
curl -X POST http://localhost:8080/api/project-analysis/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "projectPath": "/path/to/your/project",
    "projectKey": "my-project",
    "branch": "main"
  }'
```

#### 异步分析
```bash
# 提交任务
curl -X POST http://localhost:8080/api/project-analysis/analyze-async \
  -H "Content-Type: application/json" \
  -d '{
    "projectPath": "/path/to/your/project",
    "projectKey": "my-project",
    "branch": "main"
  }'

# 查询进度
curl http://localhost:8080/api/project-analysis/progress/{taskId}
```

## 配置选项

### 线程池配置
默认使用 `Runtime.getRuntime().availableProcessors()` 个线程进行并行分析。

### 目录过滤
默认跳过以下目录：
- target
- build
- .git
- .idea
- node_modules
- 以 . 开头的隐藏目录

### 数据库存储
项目分析结果会自动保存到数据库，包括：
- 项目级别的统计信息
- 分析性能指标
- 错误信息汇总

## 性能特性

### 1. 并行处理
- 使用 Java 8 并行流进行文件分析
- 充分利用多核CPU资源
- 自动负载均衡

### 2. 内存管理
- 流式处理，避免一次性加载所有文件
- 及时释放已处理文件的内存
- 监控峰值内存使用

### 3. 进度跟踪
- 实时更新分析进度
- 线程安全的状态管理
- 详细的性能指标收集

## 错误处理

### 1. 文件级错误
- 单个文件分析失败不影响整体进度
- 详细记录错误信息和堆栈
- 支持错误文件重试

### 2. 项目级错误
- 路径验证和权限检查
- 优雅的异常处理和恢复
- 完整的错误日志记录

### 3. 系统级错误
- 数据库连接异常处理
- 内存不足保护机制
- 任务超时和取消机制

## 扩展性

### 1. 自定义分析器
可以通过实现 `CodeFileAnalyzer` 接口来支持其他编程语言。

### 2. 结果处理器
可以添加自定义的结果处理逻辑，如：
- 代码质量评估
- 安全漏洞扫描
- 性能优化建议

### 3. 通知机制
可以集成邮件、消息队列等通知方式，在分析完成时发送通知。

## 监控和运维

### 1. 健康检查
```bash
curl http://localhost:8080/api/project-analysis/health
```

### 2. 任务管理
```bash
# 获取所有任务
curl http://localhost:8080/api/project-analysis/tasks

# 清理完成的任务
curl -X POST http://localhost:8080/api/project-analysis/cleanup
```

### 3. 数据清理
```bash
# 清理30天前的分析结果
curl -X POST http://localhost:8080/api/project-analysis/cleanup-old?daysToKeep=30
```

## 最佳实践

### 1. 项目准备
- 确保项目路径可读
- 清理不必要的临时文件
- 检查磁盘空间充足

### 2. 性能优化
- 对于大型项目，建议使用异步分析
- 合理设置线程池大小
- 定期清理历史分析结果

### 3. 错误排查
- 查看详细的错误日志
- 检查文件权限和编码
- 验证Java文件语法正确性

## 未来规划

1. **增量分析**：只分析变更的文件
2. **分布式分析**：支持多机器并行分析
3. **可视化报告**：生成图表和报告
4. **CI/CD集成**：与构建流水线集成
5. **代码质量评估**：集成静态代码分析工具
